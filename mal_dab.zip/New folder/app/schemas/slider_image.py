from pydantic import BaseModel

class SliderImageBase(BaseModel):
    image_url: str
    order: int = 0

class SliderImageCreate(SliderImageBase):
    pass

class SliderImageOut(SliderImageBase):
    id: int
    class Config:
        orm_mode = True 