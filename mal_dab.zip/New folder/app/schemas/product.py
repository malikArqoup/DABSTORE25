from pydantic import BaseModel, computed_field
from typing import Optional
from datetime import datetime

class ProductBase(BaseModel):
    name: str
    description: Optional[str] = None
    price: float
    category: Optional[str] = None
    image_url: Optional[str] = None
    stock_quantity: int = 0
    discount_percent: float = 0  # نسبة الخصم

class ProductCreate(ProductBase):
    pass

class ProductUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    price: Optional[float] = None
    category: Optional[str] = None
    image_url: Optional[str] = None
    stock_quantity: Optional[int] = None
    discount_percent: Optional[float] = None  # نسبة الخصم

class Product(ProductBase):
    id: int
    created_at: datetime
    updated_at: Optional[datetime] = None

    @computed_field
    @property
    def discounted_price(self) -> float:
        """حساب السعر بعد الخصم"""
        if self.discount_percent <= 0:
            return self.price
        discount_amount = self.price * (self.discount_percent / 100)
        return round(self.price - discount_amount, 2)

    @computed_field
    @property
    def has_discount(self) -> bool:
        """هل المنتج يحتوي على خصم؟"""
        return self.discount_percent > 0

    class Config:
        from_attributes = True 