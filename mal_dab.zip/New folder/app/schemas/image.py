from pydantic import BaseModel
from typing import Optional, Dict
from datetime import datetime

class ImageBase(BaseModel):
    is_primary: bool = False

class ImageCreate(ImageBase):
    pass

class ImageUpdate(BaseModel):
    is_primary: Optional[bool] = None

class Image(ImageBase):
    id: int
    product_id: int
    filename: str
    original_filename: str
    file_path: str
    file_size: int
    mime_type: str
    width: Optional[int] = None
    height: Optional[int] = None
    created_at: datetime
    url: Optional[str] = None  # Legacy field for backward compatibility
    urls: Optional[Dict[str, str]] = None  # Multiple URL variants

    class Config:
        from_attributes = True

class ImageUploadResponse(BaseModel):
    message: str
    image: Image 