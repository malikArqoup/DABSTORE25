from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime
from app.models.order import OrderStatus

# OrderItem schemas
class OrderItemBase(BaseModel):
    product_id: int
    quantity: int

class OrderItemCreate(OrderItemBase):
    pass

class OrderItem(OrderItemBase):
    id: int
    order_id: int
    unit_price: float
    total_price: float
    product_name: Optional[str] = None

    class Config:
        from_attributes = True

# Order schemas
class OrderBase(BaseModel):
    shipping_address: str
    phone_number: str
    notes: Optional[str] = None

class OrderCreate(OrderBase):
    items: List[OrderItemCreate]

class OrderUpdate(BaseModel):
    status: Optional[OrderStatus] = None
    shipping_address: Optional[str] = None
    phone_number: Optional[str] = None
    notes: Optional[str] = None

class Order(OrderBase):
    id: int
    user_id: int
    order_number: str
    status: OrderStatus
    total_amount: float
    created_at: datetime
    updated_at: Optional[datetime] = None
    items: List[OrderItem] = []

    class Config:
        from_attributes = True

# Order summary for lists
class OrderSummary(BaseModel):
    id: int
    order_number: str
    status: OrderStatus
    total_amount: float
    created_at: datetime
    items_count: int
    username: str
    email: str
    phone_number: str
    shipping_address: str

    class Config:
        from_attributes = True 