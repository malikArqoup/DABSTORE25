from pydantic_settings import BaseSettings
import os

class Settings(BaseSettings):
    # Database Configuration
    # For production, use environment variable DATABASE_URL
    # Examples:
    # MySQL: mysql+pymysql://username:password@host:port/database
    # PostgreSQL: postgresql://username:password@host:port/database
    # SQLite (development): sqlite:///./furniture.db
    
    database_url: str = os.getenv(
        "DATABASE_URL", 
        "sqlite:///./furniture.db"  # Default for development
    )
    
    # Security
    secret_key: str = os.getenv("SECRET_KEY", "your-secret-key-here-change-in-production")
    algorithm: str = "HS256"
    access_token_expire_minutes: int = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "30"))

    # Email Configuration
    smtp_server: str = os.getenv("SMTP_SERVER", "smtp.gmail.com")
    smtp_port: int = int(os.getenv("SMTP_PORT", "587"))
    smtp_username: str = os.getenv("SMTP_USERNAME", "your_gmail@gmail.com")
    smtp_password: str = os.getenv("SMTP_PASSWORD", "your_app_password")
    email_from: str = os.getenv("EMAIL_FROM", "your_gmail@gmail.com")
    email_from_name: str = os.getenv("EMAIL_FROM_NAME", "DAB Store")

    # CORS Configuration
    cors_origins: str = os.getenv("CORS_ORIGINS", "*")  # For production, specify your frontend URL

    class Config:
        env_file = ".env"

settings = Settings() 