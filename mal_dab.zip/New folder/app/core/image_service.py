import os
import uuid
import shutil
from pathlib import Path
from typing import Tuple, Optional
from PIL import Image as PILImage
from fastapi import UploadFile, HTTPException
import mimetypes

class ImageService:
    # Configuration
    UPLOAD_DIR = os.path.abspath("uploads")
    ALLOWED_EXTENSIONS = {".jpg", ".jpeg", ".png", ".gif", ".webp"}
    MAX_FILE_SIZE = 10 * 1024 * 1024  # 10MB
    THUMBNAIL_SIZE = (300, 300)
    MEDIUM_SIZE = (800, 800)
    LARGE_SIZE = (1200, 1200)

    @classmethod
    def setup_upload_directory(cls):
        """Create upload directory if it doesn't exist"""
        upload_path = Path(cls.UPLOAD_DIR)
        upload_path.mkdir(exist_ok=True)
        
        # Create subdirectories
        (upload_path / "products").mkdir(exist_ok=True)
        (upload_path / "thumbnails").mkdir(exist_ok=True)
        (upload_path / "medium").mkdir(exist_ok=True)
        (upload_path / "large").mkdir(exist_ok=True)

    @classmethod
    def validate_image_file(cls, file: UploadFile) -> bool:
        """Validate uploaded image file"""
        # Check file extension
        if not file.filename:
            return False
        file_extension = Path(file.filename).suffix.lower()
        if file_extension not in cls.ALLOWED_EXTENSIONS:
            return False
        
        # Check MIME type
        mime_type, _ = mimetypes.guess_type(file.filename or "")
        if not mime_type or not mime_type.startswith('image/'):
            return False
        
        return True

    @classmethod
    def generate_unique_filename(cls, original_filename: str) -> str:
        """Generate unique filename for uploaded image"""
        if not original_filename:
            original_filename = "image"
        file_extension = Path(original_filename).suffix.lower()
        unique_id = str(uuid.uuid4())
        return f"{unique_id}{file_extension}"

    @classmethod
    def get_image_dimensions(cls, image_path: str) -> Tuple[int, int]:
        """Get image dimensions"""
        try:
            with PILImage.open(image_path) as img:
                return img.size
        except Exception:
            return (0, 0)

    @classmethod
    def resize_image(cls, input_path: str, output_path: str, size: Tuple[int, int], quality: int = 85):
        """Resize image to specified size"""
        try:
            with PILImage.open(input_path) as img:
                # Convert to RGB if necessary
                if img.mode in ('RGBA', 'LA', 'P'):
                    img = img.convert('RGB')
                
                # Resize image maintaining aspect ratio
                img.thumbnail(size, PILImage.Resampling.LANCZOS)
                
                # Save resized image
                img.save(output_path, quality=quality, optimize=True)
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Error processing image: {str(e)}")

    @classmethod
    def save_uploaded_image(cls, file: UploadFile, product_id: int) -> dict:
        """Save uploaded image and create different sizes"""
        # Setup directories
        cls.setup_upload_directory()
        
        # Validate file
        if not cls.validate_image_file(file):
            raise HTTPException(status_code=400, detail="Invalid image file")
        
        # Check file size
        file.file.seek(0, 2)  # Seek to end
        file_size = file.file.tell()
        file.file.seek(0)  # Reset to beginning
        
        if file_size > cls.MAX_FILE_SIZE:
            raise HTTPException(status_code=400, detail="File too large. Maximum size is 10MB")
        
        # Generate unique filename
        original_filename = file.filename or "image"
        unique_filename = cls.generate_unique_filename(original_filename)
        
        # Create product directory
        product_dir = Path(cls.UPLOAD_DIR) / "products" / str(product_id)
        product_dir.mkdir(exist_ok=True)
        
        # Save original image
        original_path = product_dir / unique_filename
        with open(original_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
        
        # Get image dimensions
        width, height = cls.get_image_dimensions(str(original_path))
        
        # Create different sizes
        thumbnail_path = product_dir / f"thumb_{unique_filename}"
        medium_path = product_dir / f"medium_{unique_filename}"
        large_path = product_dir / f"large_{unique_filename}"
        
        cls.resize_image(str(original_path), str(thumbnail_path), cls.THUMBNAIL_SIZE)
        cls.resize_image(str(original_path), str(medium_path), cls.MEDIUM_SIZE)
        cls.resize_image(str(original_path), str(large_path), cls.LARGE_SIZE)
        
        return {
            "filename": unique_filename,
            "original_filename": original_filename,
            "file_path": str(original_path),
            "file_size": file_size,
            "mime_type": file.content_type or "image/jpeg",
            "width": width,
            "height": height
        }

    @classmethod
    def delete_image_files(cls, image_data: dict):
        """Delete image files from disk"""
        try:
            product_id = image_data.get("product_id")
            filename = image_data.get("filename")
            
            if product_id and filename:
                product_dir = Path(cls.UPLOAD_DIR) / "products" / str(product_id)
                
                # Delete all versions of the image
                files_to_delete = [
                    product_dir / filename,
                    product_dir / f"thumb_{filename}",
                    product_dir / f"medium_{filename}",
                    product_dir / f"large_{filename}"
                ]
                
                for file_path in files_to_delete:
                    if file_path.exists():
                        file_path.unlink()
                        
        except Exception as e:
            print(f"Error deleting image files: {e}")

    @classmethod
    def get_image_url(cls, filename: str, product_id: int, size: str = "original") -> str:
        """Generate URL for image access"""
        base_url = "/images"
        
        if size == "thumbnail":
            return f"{base_url}/products/{product_id}/thumb_{filename}"
        elif size == "medium":
            return f"{base_url}/products/{product_id}/medium_{filename}"
        elif size == "large":
            return f"{base_url}/products/{product_id}/large_{filename}"
        else:
            return f"{base_url}/products/{product_id}/{filename}"

async def save_product_image(file: UploadFile, product_id: int) -> str:
    """Save product image and return the image filename only (not the full URL)"""
    image_data = ImageService.save_uploaded_image(file, product_id)
    return image_data["filename"] 