from sqlalchemy import Column, Integer, String
from app.db.base import Base

class SliderImage(Base):
    __tablename__ = "slider_images"
    id = Column(Integer, primary_key=True, index=True)
    image_url = Column(String, nullable=False)
    order = Column(Integer, default=0) 