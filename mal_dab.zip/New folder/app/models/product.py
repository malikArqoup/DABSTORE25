from sqlalchemy import Column, Integer, String, Float, Text, DateTime
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.db.base import Base

class Product(Base):
    __tablename__ = "products"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False, index=True)
    description = Column(Text)
    price = Column(Float, nullable=False)
    category = Column(String(50), index=True)
    image_url = Column(String(255))
    stock_quantity = Column(Integer, default=0)
    discount_percent = Column(Float, default=0)  # نسبة الخصم
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    # Relationships
    # images = relationship("Image", back_populates="product", cascade="all, delete-orphan")  # Remove from here

# Late import to avoid circular dependency
from .image import Image  # noqa: E402
Product.images = relationship("Image", back_populates="product", cascade="all, delete-orphan") 