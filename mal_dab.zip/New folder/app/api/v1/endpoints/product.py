from fastapi import APIRouter, Depends, HTTPException, status, Query, UploadFile, File, Form
from sqlalchemy.orm import Session
from typing import List, Optional
from app.db.base import get_database
from app.models.admin import Admin
from app.models.product import Product
from app.schemas.product import ProductCreate, ProductUpdate, Product as ProductSchema
from app.crud.product import ProductCRUD
from app.core.security import get_current_admin
from app.core.image_service import save_product_image

router = APIRouter(prefix="/products", tags=["products"])

@router.post("/", response_model=ProductSchema)
async def create_product(
    name: str = Form(...),
    description: str = Form(...),
    price: float = Form(...),
    category: Optional[str] = Form(None),
    stock_quantity: int = Form(0),
    image: Optional[UploadFile] = File(None),
    database: Session = Depends(get_database),
    current_admin: Admin = Depends(get_current_admin)
):
    # Create product data
    product_data = ProductCreate(
        name=name,
        description=description,
        price=price,
        category=category,
        stock_quantity=stock_quantity,
        image_url=None
    )
    
    # Save product first
    product = ProductCRUD.create(database=database, product=product_data)
    
    # Handle image upload if provided
    if image:
        try:
            image_url = await save_product_image(image, product.id)
            # Update product with image URL
            product_update = ProductUpdate(image_url=image_url)
            product = ProductCRUD.update(database=database, product_id=product.id, product=product_update)
        except Exception as e:
            # If image upload fails, still return the product without image
            pass
    
    return product

@router.get("/", response_model=List[ProductSchema])
def read_products(
    skip: int = 0,
    limit: int = 100,
    database: Session = Depends(get_database)
):
    products = ProductCRUD.get_all(database, skip=skip, limit=limit)
    return products

@router.get("/{product_id}", response_model=ProductSchema)
def read_product(product_id: int, database: Session = Depends(get_database)):
    product = ProductCRUD.get_by_id(database, product_id=product_id)
    if product is None:
        raise HTTPException(status_code=404, detail="Product not found")
    return product

@router.put("/{product_id}", response_model=ProductSchema)
async def update_product(
    product_id: int,
    name: Optional[str] = Form(None),
    description: Optional[str] = Form(None),
    price: Optional[float] = Form(None),
    category: Optional[str] = Form(None),
    stock_quantity: Optional[int] = Form(None),
    image: Optional[UploadFile] = File(None),
    database: Session = Depends(get_database),
    current_admin: Admin = Depends(get_current_admin)
):
    # Get existing product
    db_product = ProductCRUD.get_by_id(database, product_id=product_id)
    if db_product is None:
        raise HTTPException(status_code=404, detail="Product not found")
    
    # Create update data
    update_data = {}
    if name is not None:
        update_data["name"] = name
    if description is not None:
        update_data["description"] = description
    if price is not None:
        update_data["price"] = price
    if category is not None:
        update_data["category"] = category
    if stock_quantity is not None:
        update_data["stock_quantity"] = stock_quantity
    
    # Update product
    product_update = ProductUpdate(**update_data)
    db_product = ProductCRUD.update(database=database, product_id=product_id, product=product_update)
    
    # Handle image upload if provided
    if image:
        try:
            image_url = await save_product_image(image, product_id)
            # Update product with new image URL
            image_update = ProductUpdate(image_url=image_url)
            db_product = ProductCRUD.update(database=database, product_id=product_id, product=image_update)
        except Exception as e:
            # If image upload fails, still return the updated product
            pass
    
    return db_product

@router.delete("/{product_id}")
def delete_product(
    product_id: int,
    database: Session = Depends(get_database),
    current_admin: Admin = Depends(get_current_admin)
):
    product = ProductCRUD.delete(database=database, product_id=product_id)
    if product is None:
        raise HTTPException(status_code=404, detail="Product not found")
    return {"message": "Product deleted successfully"}

@router.get("/search/name", response_model=List[ProductSchema])
def search_products_by_name(
    name: str = Query(..., description="Product name to search for"),
    database: Session = Depends(get_database)
):
    products = ProductCRUD.search_by_name(database=database, name=name)
    return products

@router.get("/filter/category", response_model=List[ProductSchema])
def filter_products_by_category(
    category: str = Query(..., description="Product category to filter by"),
    database: Session = Depends(get_database)
):
    products = ProductCRUD.filter_by_category(database=database, category=category)
    return products

@router.get("/filter/price", response_model=List[ProductSchema])
def filter_products_by_price_range(
    min_price: float = Query(..., description="Minimum price"),
    max_price: float = Query(..., description="Maximum price"),
    database: Session = Depends(get_database)
):
    products = ProductCRUD.filter_by_price_range(
        database=database, min_price=min_price, max_price=max_price
    )
    return products

# New discount management endpoints
@router.get("/discounts/all", response_model=List[ProductSchema])
def get_products_with_discounts(
    skip: int = 0,
    limit: int = 100,
    database: Session = Depends(get_database)
):
    """Get all products that have discounts"""
    products = ProductCRUD.get_products_with_discount(database, skip=skip, limit=limit)
    return products

@router.put("/{product_id}/discount", response_model=ProductSchema)
def set_product_discount(
    product_id: int,
    discount_percent: float = Query(..., ge=0, le=100, description="Discount percentage (0-100)"),
    database: Session = Depends(get_database),
    current_admin: Admin = Depends(get_current_admin)
):
    """Set discount percentage for a product"""
    if discount_percent < 0 or discount_percent > 100:
        raise HTTPException(status_code=400, detail="Discount percentage must be between 0 and 100")
    
    product = ProductCRUD.set_discount(database, product_id, discount_percent)
    if product is None:
        raise HTTPException(status_code=404, detail="Product not found")
    
    return product

@router.delete("/{product_id}/discount", response_model=ProductSchema)
def remove_product_discount(
    product_id: int,
    database: Session = Depends(get_database),
    current_admin: Admin = Depends(get_current_admin)
):
    """Remove discount from a product"""
    product = ProductCRUD.remove_discount(database, product_id)
    if product is None:
        raise HTTPException(status_code=404, detail="Product not found")
    
    return product

@router.get("/discounts/range", response_model=List[ProductSchema])
def get_products_by_discount_range(
    min_discount: float = Query(..., ge=0, description="Minimum discount percentage"),
    max_discount: float = Query(..., le=100, description="Maximum discount percentage"),
    database: Session = Depends(get_database)
):
    """Get products within a specific discount range"""
    if min_discount > max_discount:
        raise HTTPException(status_code=400, detail="Minimum discount cannot be greater than maximum discount")
    
    products = ProductCRUD.get_products_by_discount_range(database, min_discount, max_discount)
    return products 