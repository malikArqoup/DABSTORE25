from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.db.base import get_database
from app.models.admin import Admin
from app.schemas.admin import AdminCreate, AdminLogin, Admin as AdminSchema, Token, AdminUpdate
from app.crud.admin import AdminCRUD
from app.core.security import get_current_admin, create_access_token, verify_password
from datetime import timedelta
from app.core.config import settings
from typing import List

router = APIRouter(prefix="/admin", tags=["admin"])

@router.post("/login", response_model=Token)
def admin_login(admin_login: AdminLogin, database: Session = Depends(get_database)):
    admin = AdminCRUD.get_by_username(database, admin_login.username)
    if not admin or not verify_password(admin_login.password, admin.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    access_token_expires = timedelta(minutes=settings.access_token_expire_minutes)
    access_token = create_access_token(
        data={"sub": admin.username}, expires_delta=access_token_expires
    )
    return {"access_token": access_token, "token_type": "bearer"}

@router.get("/me", response_model=AdminSchema)
def read_admin_me(current_admin: Admin = Depends(get_current_admin)):
    return current_admin

@router.post("/register", response_model=AdminSchema)
def create_admin(admin: AdminCreate, database: Session = Depends(get_database)):
    db_admin = AdminCRUD.get_by_username(database, admin.username)
    if db_admin:
        raise HTTPException(status_code=400, detail="Username already registered")
    
    db_admin = AdminCRUD.get_by_email(database, admin.email)
    if db_admin:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    return AdminCRUD.create(database=database, admin=admin)

@router.get("/", response_model=List[AdminSchema])
def get_all_admins(database: Session = Depends(get_database), current_admin: Admin = Depends(get_current_admin)):
    return AdminCRUD.get_all(database)

@router.put("/{admin_id}", response_model=AdminSchema)
def update_admin(admin_id: int, admin_update: AdminUpdate, database: Session = Depends(get_database), current_admin: Admin = Depends(get_current_admin)):
    admin = database.query(Admin).filter(Admin.id == admin_id).first()
    if not admin:
        raise HTTPException(status_code=404, detail="Admin not found")
    if admin_update.username:
        admin.username = admin_update.username
    if admin_update.email:
        admin.email = admin_update.email
    if admin_update.is_active is not None:
        admin.is_active = admin_update.is_active
    database.commit()
    database.refresh(admin)
    return admin

@router.delete("/{admin_id}", status_code=204)
def delete_admin(admin_id: int, database: Session = Depends(get_database), current_admin: Admin = Depends(get_current_admin)):
    if admin_id == current_admin.id:
        raise HTTPException(status_code=400, detail="لا يمكنك حذف حسابك الحالي.")
    admin = database.query(Admin).filter(Admin.id == admin_id).first()
    if not admin:
        raise HTTPException(status_code=404, detail="Admin not found")
    database.delete(admin)
    database.commit()
    return 