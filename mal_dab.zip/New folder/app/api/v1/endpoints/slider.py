from fastapi import APIRouter, Depends, UploadFile, File, HTTPException
from sqlalchemy.orm import Session
from app.db.base import get_db
from app.schemas.slider_image import SliderImageOut
from app.crud import slider_image as crud_slider
import shutil
import os

router = APIRouter(prefix="/slider-images", tags=["slider"])

UPLOAD_DIR = "uploads/slider"

@router.get("/", response_model=list[SliderImageOut])
def get_slider_images(db: Session = Depends(get_db)):
    return crud_slider.get_slider_images(db)

@router.post("/", response_model=SliderImageOut)
def upload_slider_image(file: UploadFile = File(...), db: Session = Depends(get_db)):
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    file_path = os.path.join(UPLOAD_DIR, file.filename)
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    image_url = f"/{UPLOAD_DIR}/{file.filename}"
    return crud_slider.create_slider_image(db, image_url=image_url)

@router.delete("/{image_id}", response_model=SliderImageOut)
def delete_slider_image(image_id: int, db: Session = Depends(get_db)):
    image = crud_slider.delete_slider_image(db, image_id)
    if not image:
        raise HTTPException(status_code=404, detail="Image not found")
    return image 