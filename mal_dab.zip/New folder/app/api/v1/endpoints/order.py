from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from typing import List
from app.db.base import get_database
from app.models.admin import Admin
from app.models.user import User
from app.models.order import OrderStatus
from app.schemas.order import OrderCreate, OrderUpdate, Order as OrderSchema, OrderSummary
from app.crud.order import OrderCRUD
from app.core.security import get_current_user, get_current_admin
from app.core.email_service import EmailService

router = APIRouter(prefix="/orders", tags=["orders"])

# User endpoints (require user authentication)
@router.post("/", response_model=OrderSchema)
def create_order(
    order: OrderCreate,
    database: Session = Depends(get_database),
    current_user: User = Depends(get_current_user)
):
    """Create a new order"""
    try:
        created_order = OrderCRUD.create_order(database=database, order=order, user_id=current_user.id)
        
        # Send order confirmation email
        try:
            order_subject = f"تأكيد طلبك - متجر الأثاث (طلب رقم: {created_order.order_number})"
            order_body = f"""
            <html>
            <body>
                <h2>تم استلام طلبك بنجاح!</h2>
                <p>مرحباً {current_user.username}،</p>
                <p>شكراً لك على طلبك. سنقوم بمعالجته في أقرب وقت ممكن.</p>
                <p>تفاصيل الطلب:</p>
                <ul>
                    <li>رقم الطلب: #{created_order.order_number}</li>
                    <li>التاريخ: {created_order.created_at.strftime('%Y-%m-%d %H:%M')}</li>
                    <li>المجموع: {created_order.total_amount} ريال</li>
                    <li>الحالة: {created_order.status.value}</li>
                </ul>
                <p>سنرسل لك تحديثات حول حالة طلبك عبر البريد الإلكتروني.</p>
                <br>
                <p>مع تحيات،</p>
                <p>فريق متجر الأثاث</p>
            </body>
            </html>
            """
            
            EmailService.send_email(
                to_email=current_user.email,
                subject=order_subject,
                body=order_body,
                html=True
            )
        except Exception as e:
            print(f"⚠️ Failed to send order confirmation email: {e}")
            # Don't fail the order creation if email fails
        
        return created_order
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/my-orders", response_model=List[OrderSummary])
def get_my_orders(
    skip: int = 0,
    limit: int = 100,
    database: Session = Depends(get_database),
    current_user: User = Depends(get_current_user)
):
    """Get current user's orders"""
    orders = OrderCRUD.get_user_orders(database=database, user_id=current_user.id, skip=skip, limit=limit)
    return [
        OrderSummary(
            id=order.id,
            order_number=order.order_number,
            status=order.status,
            total_amount=order.total_amount,
            created_at=order.created_at,
            items_count=len(order.items),
            username=order.user.username if order.user else "-",
            email=order.user.email if order.user else "-",
            phone_number=order.phone_number,
            shipping_address=order.shipping_address
        ) for order in orders
    ]

@router.get("/my-orders/{order_id}", response_model=OrderSchema)
def get_my_order(
    order_id: int,
    database: Session = Depends(get_database),
    current_user: User = Depends(get_current_user)
):
    """Get specific order for current user"""
    order = OrderCRUD.get_order_by_id(database=database, order_id=order_id, user_id=current_user.id)
    if order is None:
        raise HTTPException(status_code=404, detail="Order not found")
    return order

@router.get("/my-orders/number/{order_number}", response_model=OrderSchema)
def get_my_order_by_number(
    order_number: str,
    database: Session = Depends(get_database),
    current_user: User = Depends(get_current_user)
):
    """Get specific order by order number for current user"""
    order = OrderCRUD.get_order_by_number(database=database, order_number=order_number, user_id=current_user.id)
    if order is None:
        raise HTTPException(status_code=404, detail="Order not found")
    return order

@router.post("/my-orders/{order_id}/cancel", response_model=OrderSchema)
def cancel_my_order(
    order_id: int,
    database: Session = Depends(get_database),
    current_user: User = Depends(get_current_user)
):
    """Cancel user's own order"""
    order = OrderCRUD.cancel_order(database=database, order_id=order_id, user_id=current_user.id)
    if order is None:
        raise HTTPException(status_code=404, detail="Order not found or cannot be cancelled")
    return order

# Admin endpoints (require admin authentication)
@router.get("/", response_model=List[OrderSummary])
def get_all_orders(
    skip: int = 0,
    limit: int = 100,
    database: Session = Depends(get_database),
    current_admin: Admin = Depends(get_current_admin)
):
    """Get all orders (admin only)"""
    orders = OrderCRUD.get_all_orders(database=database, skip=skip, limit=limit)
    return [
        OrderSummary(
            id=order.id,
            order_number=order.order_number,
            status=order.status,
            total_amount=order.total_amount,
            created_at=order.created_at,
            items_count=len(order.items),
            username=order.user.username if order.user else "-",
            email=order.user.email if order.user else "-",
            phone_number=order.phone_number,
            shipping_address=order.shipping_address
        ) for order in orders
    ]

@router.get("/{order_id}", response_model=OrderSchema)
def get_order(
    order_id: int,
    database: Session = Depends(get_database),
    current_admin: Admin = Depends(get_current_admin)
):
    """Get specific order (admin only)"""
    order = OrderCRUD.get_order_by_id(database=database, order_id=order_id)
    if order is None:
        raise HTTPException(status_code=404, detail="Order not found")
    return order

@router.get("/number/{order_number}", response_model=OrderSchema)
def get_order_by_number(
    order_number: str,
    database: Session = Depends(get_database),
    current_admin: Admin = Depends(get_current_admin)
):
    """Get specific order by order number (admin only)"""
    order = OrderCRUD.get_order_by_number(database=database, order_number=order_number)
    if order is None:
        raise HTTPException(status_code=404, detail="Order not found")
    return order

@router.put("/{order_id}/status")
def update_order_status(
    order_id: int,
    status: OrderStatus,
    database: Session = Depends(get_database),
    current_admin: Admin = Depends(get_current_admin)
):
    """Update order status (admin only)"""
    order = OrderCRUD.update_order_status(database=database, order_id=order_id, status=status)
    if order is None:
        raise HTTPException(status_code=404, detail="Order not found")
    
    # Send status update email to user
    try:
        if order.user and order.user.email:
            status_subject = f"تحديث حالة طلبك - متجر الأثاث (طلب رقم: {order.order_number})"
            status_body = f"""
            <html>
            <body>
                <h2>تم تحديث حالة طلبك</h2>
                <p>مرحباً {order.user.username}،</p>
                <p>تم تحديث حالة طلبك إلى: <strong>{status.value}</strong></p>
                <p>تفاصيل الطلب:</p>
                <ul>
                    <li>رقم الطلب: #{order.order_number}</li>
                    <li>الحالة الجديدة: {status.value}</li>
                    <li>المجموع: {order.total_amount} ريال</li>
                </ul>
                <p>سنواصل إرسال تحديثات لك حول حالة طلبك.</p>
                <br>
                <p>مع تحيات،</p>
                <p>فريق متجر الأثاث</p>
            </body>
            </html>
            """
            
            EmailService.send_email(
                to_email=order.user.email,
                subject=status_subject,
                body=status_body,
                html=True
            )
    except Exception as e:
        print(f"⚠️ Failed to send status update email: {e}")
    
    return {"message": f"Order status updated to {status}", "order_id": order_id}

@router.put("/{order_id}", response_model=OrderSchema)
def update_order(
    order_id: int,
    order_update: OrderUpdate,
    database: Session = Depends(get_database),
    current_admin: Admin = Depends(get_current_admin)
):
    """Update order details (admin only)"""
    order = OrderCRUD.update_order(database=database, order_id=order_id, order_update=order_update)
    if order is None:
        raise HTTPException(status_code=404, detail="Order not found")
    return order

@router.get("/status/{status}", response_model=List[OrderSummary])
def get_orders_by_status(
    status: OrderStatus,
    skip: int = 0,
    limit: int = 100,
    database: Session = Depends(get_database),
    current_admin: Admin = Depends(get_current_admin)
):
    """Get orders by status (admin only)"""
    orders = OrderCRUD.get_orders_by_status(database=database, status=status, skip=skip, limit=limit)
    return [
        OrderSummary(
            id=order.id,
            order_number=order.order_number,
            status=order.status,
            total_amount=order.total_amount,
            created_at=order.created_at,
            items_count=len(order.items),
            username=order.user.username if order.user else "-",
            email=order.user.email if order.user else "-",
            phone_number=order.phone_number,
            shipping_address=order.shipping_address
        ) for order in orders
    ]

@router.get("/statistics/dashboard")
def get_order_statistics(
    database: Session = Depends(get_database),
    current_admin: Admin = Depends(get_current_admin)
):
    """Get order statistics for admin dashboard"""
    return OrderCRUD.get_order_statistics(database=database)

@router.delete("/all", status_code=200, response_model=dict)
def delete_all_orders(
    database: Session = Depends(get_database),
    current_admin: Admin = Depends(get_current_admin)
):
    """Delete all orders permanently (admin only)"""
    deleted = OrderCRUD.delete_all_orders(database=database)
    return {"message": f"Deleted {deleted} orders successfully"}

@router.delete("/{order_id}")
def delete_order(
    order_id: int,
    database: Session = Depends(get_database),
    current_admin: Admin = Depends(get_current_admin)
):
    """Delete order permanently (admin only)"""
    success = OrderCRUD.delete_order(database=database, order_id=order_id)
    if not success:
        raise HTTPException(status_code=404, detail="Order not found")
    return {"message": "Order deleted successfully"} 