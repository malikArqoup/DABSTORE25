from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.db.base import get_database
from app.models.user import User
from app.schemas.user import UserCreate, UserLogin, User as UserSchema, UserUpdate
from app.crud.user import UserCRUD
from app.core.security import get_current_user, get_current_admin
from app.core.email_service import EmailService
from typing import List

router = APIRouter(prefix="/user", tags=["user"])

@router.post("/register", response_model=UserSchema)
def create_user(user: UserCreate, database: Session = Depends(get_database)):
    db_user = UserCRUD.get_by_username(database, user.username)
    if db_user:
        raise HTTPException(status_code=400, detail="Username already registered")
    
    db_user = UserCRUD.get_by_email(database, user.email)
    if db_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    # Create the user
    created_user = UserCRUD.create(database=database, user=user)
    
    # Send welcome email
    try:
        welcome_subject = "مرحباً بك في متجر الأثاث!"
        welcome_body = f"""
        <html>
        <body>
            <h2>أهلاً وسهلاً بك {created_user.username}!</h2>
            <p>شكراً لك على التسجيل في متجر الأثاث.</p>
            <p>يمكنك الآن:</p>
            <ul>
                <li>تصفح منتجاتنا المميزة</li>
                <li>إضافة المنتجات إلى سلة التسوق</li>
                <li>إتمام عملية الشراء</li>
            </ul>
            <p>إذا كان لديك أي استفسار، لا تتردد في التواصل معنا.</p>
            <br>
            <p>مع تحيات،</p>
            <p>فريق متجر الأثاث</p>
        </body>
        </html>
        """
        
        EmailService.send_email(
            to_email=created_user.email,
            subject=welcome_subject,
            body=welcome_body,
            html=True
        )
    except Exception as e:
        print(f"⚠️ Failed to send welcome email: {e}")
        # Don't fail the registration if email fails
    
    return created_user

@router.post("/login")
def user_login(user_login: UserLogin, database: Session = Depends(get_database)):
    user = UserCRUD.get_by_username(database, user_login.username)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Basic"},
        )
    from app.core.security import verify_password, create_access_token
    if not verify_password(user_login.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Basic"},
        )
    # إنشاء توكن JWT
    access_token = create_access_token({"sub": user.username})
    return {"access_token": access_token, "token_type": "bearer", "user_id": user.id, "username": user.username}

@router.get("/me", response_model=UserSchema)
def read_user_me(current_user: User = Depends(get_current_user)):
    return current_user

@router.get("/", response_model=List[UserSchema])
def get_all_users(database: Session = Depends(get_database), current_admin = Depends(get_current_admin)):
    users = UserCRUD.get_all(database)
    return users 

@router.put("/{user_id}", response_model=UserSchema)
def update_user(user_id: int, update: UserUpdate, database: Session = Depends(get_database), current_admin = Depends(get_current_admin)):
    user = database.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    # تحقق من عدم تكرار الإيميل أو الاسم
    if update.username and update.username != user.username:
        if UserCRUD.get_by_username(database, update.username):
            raise HTTPException(status_code=400, detail="Username already exists")
    if update.email and update.email != user.email:
        if UserCRUD.get_by_email(database, update.email):
            raise HTTPException(status_code=400, detail="Email already exists")
    updated_user = UserCRUD.update(database, user, update.dict(exclude_unset=True))
    return updated_user

@router.delete("/{user_id}", status_code=204)
def delete_user(user_id: int, database: Session = Depends(get_database), current_admin = Depends(get_current_admin)):
    user = database.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    database.delete(user)
    database.commit()
    return