from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File, Form
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from typing import List
from pathlib import Path
from app.db.base import get_database
from app.models.admin import Admin
from app.models.product import Product
from app.schemas.image import Image as ImageSchema, ImageUploadResponse
from app.crud.image import ImageCRUD
from app.crud.product import ProductCRUD
from app.core.image_service import ImageService
from app.core.security import get_current_admin

router = APIRouter(prefix="/images", tags=["images"])

# Admin endpoints for image management
@router.post("/upload/{product_id}", response_model=ImageUploadResponse)
async def upload_product_image(
    product_id: int,
    file: UploadFile = File(...),
    is_primary: bool = Form(False),
    database: Session = Depends(get_database),
    current_admin: Admin = Depends(get_current_admin)
):
    """Upload image for a product (admin only)"""
    # Check if product exists
    product = ProductCRUD.get_by_id(database, product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    
    try:
        # Save image file and create different sizes
        image_data = ImageService.save_uploaded_image(file, product_id)
        
        # Create image record in database
        image = ImageCRUD.create_image(
            database=database,
            image_data=image_data,
            product_id=product_id,
            is_primary=is_primary
        )
        
        # Get image with URLs
        image_with_urls = ImageCRUD.get_image_with_url(database, image)
        
        return ImageUploadResponse(
            message="Image uploaded successfully",
            image=ImageSchema(**image_with_urls)
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error uploading image: {str(e)}")

@router.get("/product/{product_id}", response_model=List[ImageSchema])
def get_product_images(
    product_id: int,
    database: Session = Depends(get_database)
):
    """Get all images for a product"""
    # Check if product exists
    product = ProductCRUD.get_by_id(database, product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    
    images = ImageCRUD.get_product_images(database, product_id)
    return [ImageSchema(**ImageCRUD.get_image_with_url(database, img)) for img in images]

@router.get("/product/{product_id}/primary")
def get_product_primary_image(
    product_id: int,
    database: Session = Depends(get_database)
):
    """Get primary image for a product"""
    # Check if product exists
    product = ProductCRUD.get_by_id(database, product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    
    image = ImageCRUD.get_primary_image(database, product_id)
    if not image:
        raise HTTPException(status_code=404, detail="No primary image found")
    
    return ImageSchema(**ImageCRUD.get_image_with_url(database, image))

@router.put("/{image_id}/primary")
def set_primary_image(
    image_id: int,
    database: Session = Depends(get_database),
    current_admin: Admin = Depends(get_current_admin)
):
    """Set an image as primary (admin only)"""
    image = ImageCRUD.get_image_by_id(database, image_id)
    if not image:
        raise HTTPException(status_code=404, detail="Image not found")
    
    updated_image = ImageCRUD.set_primary_image(database, image_id, image.product_id)
    if not updated_image:
        raise HTTPException(status_code=400, detail="Failed to set primary image")
    
    return {"message": "Primary image updated successfully", "image_id": image_id}

@router.delete("/{image_id}")
def delete_image(
    image_id: int,
    database: Session = Depends(get_database),
    current_admin: Admin = Depends(get_current_admin)
):
    """Delete an image (admin only)"""
    image = ImageCRUD.get_image_by_id(database, image_id)
    if not image:
        raise HTTPException(status_code=404, detail="Image not found")
    
    success = ImageCRUD.delete_image(database, image_id)
    if not success:
        raise HTTPException(status_code=500, detail="Failed to delete image")
    
    return {"message": "Image deleted successfully"}

# Static file serving for images
@router.get("/products/{product_id}/{filename}")
async def serve_product_image(
    product_id: int,
    filename: str,
    database: Session = Depends(get_database)
):
    """Serve product image files"""
    # Check if product exists
    product = ProductCRUD.get_by_id(database, product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    
    # Construct file path
    file_path = Path(ImageService.UPLOAD_DIR) / "products" / str(product_id) / filename
    
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="Image not found")
    
    # Determine content type
    content_type = "image/jpeg"  # default
    if filename.lower().endswith(".png"):
        content_type = "image/png"
    elif filename.lower().endswith(".gif"):
        content_type = "image/gif"
    elif filename.lower().endswith(".webp"):
        content_type = "image/webp"
    
    return FileResponse(
        path=str(file_path),
        media_type=content_type,
        headers={"Cache-Control": "public, max-age=31536000"}  # Cache for 1 year
    ) 