# Endpoints package initialization 
from .slider import router as slider_router

routers = [
    # ... existing routers ...
    slider_router,
] 