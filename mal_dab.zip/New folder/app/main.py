from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import os
from app.core.config import settings
from app.api.v1.endpoints.admin import router as admin_router
from app.api.v1.endpoints.user import router as user_router
from app.api.v1.endpoints.product import router as product_router
from app.api.v1.endpoints.order import router as order_router
from app.api.v1.endpoints.image import router as image_router
from app.api.v1.endpoints.slider import router as slider_router

app = FastAPI(
    title="DAB Store API",
    description="API for DAB Store - Furniture and Accessories E-commerce",
    version="1.0.0"
)

# خدمة static files لمجلد uploads
os.makedirs("uploads", exist_ok=True)
app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")

# CORS Configuration
cors_origins = settings.cors_origins.split(",") if "," in settings.cors_origins else [settings.cors_origins]

app.add_middleware(
    CORSMiddleware,
    allow_origins=cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(admin_router, prefix="/api/v1")
app.include_router(user_router, prefix="/api/v1")
app.include_router(product_router, prefix="/api/v1")
app.include_router(order_router, prefix="/api/v1")
app.include_router(image_router, prefix="/api/v1")
app.include_router(slider_router, prefix="/api/v1")

@app.get("/")
def root():
    return {
        "message": "DAB Store API is running",
        "version": "1.0.0",
        "docs": "/docs"
    }

@app.get("/health")
def health_check():
    return {"status": "healthy"} 