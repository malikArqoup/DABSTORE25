from sqlalchemy.orm import Session
from app.models.admin import Admin
from app.schemas.admin import AdminCreate
from app.core.security import hash_password

class AdminCRUD:
    @staticmethod
    def get_by_username(database: Session, username: str):
        return database.query(Admin).filter(Admin.username == username).first()
    
    @staticmethod
    def get_by_email(database: Session, email: str):
        return database.query(Admin).filter(Admin.email == email).first()
    
    @staticmethod
    def create(database: Session, admin: AdminCreate):
        hashed_password = hash_password(admin.password)
        db_admin = Admin(
            username=admin.username,
            email=admin.email,
            hashed_password=hashed_password
        )
        database.add(db_admin)
        database.commit()
        database.refresh(db_admin)
        return db_admin
    
    @staticmethod
    def get_all(database: Session):
        return database.query(Admin).all() 