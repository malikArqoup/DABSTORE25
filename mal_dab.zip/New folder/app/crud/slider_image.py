from sqlalchemy.orm import Session
from app.models.slider_image import SliderImage
from app.schemas.slider_image import SliderImageCreate

def get_slider_images(db: Session):
    return db.query(SliderImage).order_by(SliderImage.order).all()

def create_slider_image(db: Session, image_url: str, order: int = 0):
    db_image = SliderImage(image_url=image_url, order=order)
    db.add(db_image)
    db.commit()
    db.refresh(db_image)
    return db_image

def delete_slider_image(db: Session, image_id: int):
    db_image = db.query(SliderImage).filter(SliderImage.id == image_id).first()
    if db_image:
        db.delete(db_image)
        db.commit()
    return db_image 