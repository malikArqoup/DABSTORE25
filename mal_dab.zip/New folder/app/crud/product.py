from sqlalchemy.orm import Session
from app.models.product import Product
from app.schemas.product import ProductCreate, ProductUpdate

class ProductCRUD:
    @staticmethod
    def create(database: Session, product: ProductCreate):
        db_product = Product(**product.model_dump())
        database.add(db_product)
        database.commit()
        database.refresh(db_product)
        return db_product
    
    @staticmethod
    def get_by_id(database: Session, product_id: int):
        return database.query(Product).filter(Product.id == product_id).first()
    
    @staticmethod
    def get_all(database: Session, skip: int = 0, limit: int = 100):
        return database.query(Product).offset(skip).limit(limit).all()
    
    @staticmethod
    def update(database: Session, product_id: int, product: ProductUpdate):
        db_product = database.query(Product).filter(Product.id == product_id).first()
        if db_product:
            update_data = product.model_dump(exclude_unset=True)
            for field, value in update_data.items():
                setattr(db_product, field, value)
            database.commit()
            database.refresh(db_product)
        return db_product
    
    @staticmethod
    def delete(database: Session, product_id: int):
        db_product = database.query(Product).filter(Product.id == product_id).first()
        if db_product:
            database.delete(db_product)
            database.commit()
        return db_product
    
    @staticmethod
    def search_by_name(database: Session, name: str):
        return database.query(Product).filter(Product.name.contains(name)).all()
    
    @staticmethod
    def filter_by_category(database: Session, category: str):
        return database.query(Product).filter(Product.category == category).all()
    
    @staticmethod
    def filter_by_price_range(database: Session, min_price: float, max_price: float):
        return database.query(Product).filter(
            Product.price >= min_price,
            Product.price <= max_price
        ).all()
    
    # New methods for discount management
    @staticmethod
    def get_products_with_discount(database: Session, skip: int = 0, limit: int = 100):
        """Get all products that have discounts"""
        return database.query(Product).filter(
            Product.discount_percent > 0
        ).offset(skip).limit(limit).all()
    
    @staticmethod
    def set_discount(database: Session, product_id: int, discount_percent: float):
        """Set discount percentage for a product"""
        db_product = database.query(Product).filter(Product.id == product_id).first()
        if db_product:
            db_product.discount_percent = discount_percent
            database.commit()
            database.refresh(db_product)
        return db_product
    
    @staticmethod
    def remove_discount(database: Session, product_id: int):
        """Remove discount from a product (set to 0)"""
        return ProductCRUD.set_discount(database, product_id, 0)
    
    @staticmethod
    def get_products_by_discount_range(database: Session, min_discount: float, max_discount: float):
        """Get products within a specific discount range"""
        return database.query(Product).filter(
            Product.discount_percent >= min_discount,
            Product.discount_percent <= max_discount
        ).all() 