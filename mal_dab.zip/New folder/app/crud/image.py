from sqlalchemy.orm import Session
from app.models.image import Image
from app.models.product import Product
from app.schemas.image import ImageCreate, ImageUpdate
from app.core.image_service import ImageService
from typing import List, Optional

class ImageCRUD:
    @staticmethod
    def create_image(database: Session, image_data: dict, product_id: int, is_primary: bool = False) -> Image:
        """Create a new image record"""
        # If this is primary image, unset other primary images for this product
        if is_primary:
            database.query(Image).filter(
                Image.product_id == product_id,
                Image.is_primary == True
            ).update({"is_primary": False})
        
        db_image = Image(
            product_id=product_id,
            filename=image_data["filename"],
            original_filename=image_data["original_filename"],
            file_path=image_data["file_path"],
            file_size=image_data["file_size"],
            mime_type=image_data["mime_type"],
            width=image_data["width"],
            height=image_data["height"],
            is_primary=is_primary
        )
        
        database.add(db_image)
        database.commit()
        database.refresh(db_image)
        return db_image

    @staticmethod
    def get_image_by_id(database: Session, image_id: int) -> Optional[Image]:
        """Get image by ID"""
        return database.query(Image).filter(Image.id == image_id).first()

    @staticmethod
    def get_product_images(database: Session, product_id: int) -> List[Image]:
        """Get all images for a product"""
        return database.query(Image).filter(Image.product_id == product_id).order_by(Image.is_primary.desc(), Image.created_at.desc()).all()

    @staticmethod
    def get_primary_image(database: Session, product_id: int) -> Optional[Image]:
        """Get primary image for a product"""
        return database.query(Image).filter(
            Image.product_id == product_id,
            Image.is_primary == True
        ).first()

    @staticmethod
    def update_image(database: Session, image_id: int, image_update: ImageUpdate) -> Optional[Image]:
        """Update image details"""
        image = database.query(Image).filter(Image.id == image_id).first()
        if image:
            update_data = image_update.model_dump(exclude_unset=True)
            
            # Handle primary image update
            if update_data.get("is_primary"):
                # Unset other primary images for this product
                database.query(Image).filter(
                    Image.product_id == image.product_id,
                    Image.is_primary == True,
                    Image.id != image_id
                ).update({"is_primary": False})
            
            for field, value in update_data.items():
                setattr(image, field, value)
            
            database.commit()
            database.refresh(image)
        return image

    @staticmethod
    def delete_image(database: Session, image_id: int) -> bool:
        """Delete image and its files"""
        image = database.query(Image).filter(Image.id == image_id).first()
        if image:
            # Delete files from disk
            image_data = {
                "product_id": image.product_id,
                "filename": image.filename
            }
            ImageService.delete_image_files(image_data)
            
            # Delete from database
            database.delete(image)
            database.commit()
            return True
        return False

    @staticmethod
    def set_primary_image(database: Session, image_id: int, product_id: int) -> Optional[Image]:
        """Set an image as primary for a product"""
        # Unset current primary image
        database.query(Image).filter(
            Image.product_id == product_id,
            Image.is_primary == True
        ).update({"is_primary": False})
        
        # Set new primary image
        image = database.query(Image).filter(Image.id == image_id).first()
        if image:
            image.is_primary = True
            database.commit()
            database.refresh(image)
        
        return image

    @staticmethod
    def get_image_with_url(database: Session, image: Image, base_url: str = "") -> dict:
        """Get image data with full URLs"""
        urls = {
            "original": f"{base_url}/images/products/{image.product_id}/{image.filename}",
            "thumbnail": f"{base_url}/images/products/{image.product_id}/thumb_{image.filename}",
            "medium": f"{base_url}/images/products/{image.product_id}/medium_{image.filename}",
            "large": f"{base_url}/images/products/{image.product_id}/large_{image.filename}"
        }
        
        image_dict = {
            "id": image.id,
            "product_id": image.product_id,
            "filename": image.filename,
            "original_filename": image.original_filename,
            "file_path": image.file_path,
            "file_size": image.file_size,
            "mime_type": image.mime_type,
            "width": image.width,
            "height": image.height,
            "is_primary": image.is_primary,
            "created_at": image.created_at,
            "url": urls["original"],  # Legacy field - use original as default
            "urls": urls  # Multiple URL variants
        }
        return image_dict 