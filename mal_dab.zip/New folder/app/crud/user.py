from sqlalchemy.orm import Session
from app.models.user import User
from app.schemas.user import UserCreate
from app.core.security import hash_password

class UserCRUD:
    @staticmethod
    def get_by_username(database: Session, username: str):
        return database.query(User).filter(User.username == username).first()
    
    @staticmethod
    def get_by_email(database: Session, email: str):
        return database.query(User).filter(User.email == email).first()
    
    @staticmethod
    def create(database: Session, user: UserCreate):
        hashed_password = hash_password(user.password)
        db_user = User(
            username=user.username,
            email=user.email,
            hashed_password=hashed_password
        )
        database.add(db_user)
        database.commit()
        database.refresh(db_user)
        return db_user
    
    @staticmethod
    def get_all(database: Session, skip: int = 0, limit: int = 100):
        return database.query(User).offset(skip).limit(limit).all() 
    
    @staticmethod
    def update(database: Session, user: User, update_data: dict):
        for field, value in update_data.items():
            if hasattr(user, field) and value is not None:
                setattr(user, field, value)
        database.commit()
        database.refresh(user)
        return user