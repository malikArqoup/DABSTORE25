from sqlalchemy.orm import Session
from sqlalchemy import func
from app.models.order import Order, OrderItem, OrderStatus
from app.models.product import Product
from app.schemas.order import OrderCreate, OrderUpdate
import uuid
from datetime import datetime

class OrderCRUD:
    @staticmethod
    def generate_order_number() -> str:
        """Generate unique order number"""
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        unique_id = str(uuid.uuid4())[:8]
        return f"ORD-{timestamp}-{unique_id}"

    @staticmethod
    def create_order(database: Session, order: OrderCreate, user_id: int) -> Order:
        """Create a new order with items"""
        # Generate order number
        order_number = OrderCRUD.generate_order_number()
        
        # Calculate total amount
        total_amount = 0.0
        
        # Create order
        db_order = Order(
            user_id=user_id,
            order_number=order_number,
            shipping_address=order.shipping_address,
            phone_number=order.phone_number,
            notes=order.notes,
            total_amount=0.0  # Will be calculated after items
        )
        
        database.add(db_order)
        database.flush()  # Get the order ID
        
        # Create order items
        for item in order.items:
            # Get product details
            product = database.query(Product).filter(Product.id == item.product_id).first()
            if not product:
                raise ValueError(f"Product with id {item.product_id} not found")
            
            # Check stock
            if product.stock_quantity < item.quantity:
                raise ValueError(f"Insufficient stock for product {product.name}")
            
            # Calculate prices
            unit_price = product.price
            total_price = unit_price * item.quantity
            total_amount += total_price
            
            # Create order item
            order_item = OrderItem(
                order_id=db_order.id,
                product_id=item.product_id,
                quantity=item.quantity,
                unit_price=unit_price,
                total_price=total_price
            )
            
            database.add(order_item)
            
            # Update product stock
            product.stock_quantity -= item.quantity
        
        # Update order total
        db_order.total_amount = total_amount
        
        database.commit()
        database.refresh(db_order)
        return db_order

    @staticmethod
    def get_order_by_id(database: Session, order_id: int, user_id: int = None) -> Order:
        """Get order by ID with optional user filter"""
        query = database.query(Order).filter(Order.id == order_id)
        if user_id:
            query = query.filter(Order.user_id == user_id)
        return query.first()

    @staticmethod
    def get_order_by_number(database: Session, order_number: str, user_id: int = None) -> Order:
        """Get order by order number with optional user filter"""
        query = database.query(Order).filter(Order.order_number == order_number)
        if user_id:
            query = query.filter(Order.user_id == user_id)
        return query.first()

    @staticmethod
    def get_user_orders(database: Session, user_id: int, skip: int = 0, limit: int = 100):
        """Get all orders for a specific user"""
        return database.query(Order).filter(Order.user_id == user_id)\
            .order_by(Order.created_at.desc())\
            .offset(skip).limit(limit).all()

    @staticmethod
    def get_all_orders(database: Session, skip: int = 0, limit: int = 100):
        """Get all orders (admin only)"""
        return database.query(Order)\
            .order_by(Order.created_at.desc())\
            .offset(skip).limit(limit).all()

    @staticmethod
    def update_order_status(database: Session, order_id: int, status: OrderStatus) -> Order:
        """Update order status (admin only)"""
        order = database.query(Order).filter(Order.id == order_id).first()
        if order:
            order.status = status
            database.commit()
            database.refresh(order)
        return order

    @staticmethod
    def update_order(database: Session, order_id: int, order_update: OrderUpdate) -> Order:
        """Update order details"""
        order = database.query(Order).filter(Order.id == order_id).first()
        if order:
            update_data = order_update.dict(exclude_unset=True)
            for field, value in update_data.items():
                setattr(order, field, value)
            database.commit()
            database.refresh(order)
        return order

    @staticmethod
    def cancel_order(database: Session, order_id: int, user_id: int = None) -> Order:
        """Cancel an order and restore stock"""
        query = database.query(Order).filter(Order.id == order_id)
        if user_id:
            query = query.filter(Order.user_id == user_id)
        
        order = query.first()
        if order and order.status == OrderStatus.PENDING:
            # Restore product stock
            for item in order.items:
                product = database.query(Product).filter(Product.id == item.product_id).first()
                if product:
                    product.stock_quantity += item.quantity
            
            order.status = OrderStatus.CANCELLED
            database.commit()
            database.refresh(order)
        
        return order

    @staticmethod
    def get_orders_by_status(database: Session, status: OrderStatus, skip: int = 0, limit: int = 100):
        """Get orders by status"""
        return database.query(Order).filter(Order.status == status)\
            .order_by(Order.created_at.desc())\
            .offset(skip).limit(limit).all()

    @staticmethod
    def get_order_statistics(database: Session):
        """Get order statistics for admin dashboard"""
        total_orders = database.query(func.count(Order.id)).scalar()
        total_revenue = database.query(func.sum(Order.total_amount)).filter(
            Order.status.in_([OrderStatus.CONFIRMED, OrderStatus.SHIPPED, OrderStatus.DELIVERED])
        ).scalar() or 0.0
        pending_orders = database.query(func.count(Order.id)).filter(
            Order.status == OrderStatus.PENDING
        ).scalar()
        completed_orders = database.query(func.count(Order.id)).filter(
            Order.status.in_([OrderStatus.CONFIRMED, OrderStatus.SHIPPED, OrderStatus.DELIVERED])
        ).scalar()
        cancelled_orders = database.query(func.count(Order.id)).filter(
            Order.status == OrderStatus.CANCELLED
        ).scalar()
        average_order_value = 0.0
        if completed_orders > 0:
            average_order_value = total_revenue / completed_orders
        return {
            "total_orders": total_orders,
            "total_revenue": total_revenue,
            "pending_orders": pending_orders,
            "completed_orders": completed_orders,
            "cancelled_orders": cancelled_orders,
            "average_order_value": average_order_value
        }

    @staticmethod
    def delete_order(database: Session, order_id: int) -> bool:
        """Delete order and its items permanently"""
        order = database.query(Order).filter(Order.id == order_id).first()
        if order:
            database.delete(order)
            database.commit()
            return True
        return False

    @staticmethod
    def delete_all_orders(database: Session) -> int:
        """Delete all orders and their items permanently"""
        deleted = database.query(Order).delete()
        database.commit()
        return deleted 