# DAB Store - متجر الساعات والإكسسوارات

متجر إلكتروني متخصص في بيع الساعات والإكسسوارات العصرية بجودة عالية وأسعار منافسة.

## المميزات

- 🛍️ **إدارة المنتجات**: إضافة، تعديل، وحذف المنتجات
- 👥 **نظام المستخدمين**: تسجيل دخول وإنشاء حسابات
- 🛒 **سلة التسوق**: إضافة المنتجات وإدارة الكميات
- 📦 **إدارة الطلبات**: تتبع حالة الطلبات وإدارتها
- 🎯 **نظام الخصومات**: تطبيق خصومات على المنتجات
- 📧 **إشعارات البريد**: إرسال تأكيدات الطلبات
- 📱 **واجهة متجاوبة**: تعمل على جميع الأجهزة

## التقنيات المستخدمة

### Backend
- **FastAPI** - إطار عمل Python سريع
- **SQLAlchemy** - ORM لقواعد البيانات
- **JWT** - مصادقة المستخدمين
- **Pillow** - معالجة الصور
- **SQLite/MySQL/PostgreSQL** - قواعد البيانات

### Frontend
- **React** - مكتبة JavaScript
- **TypeScript** - لغة البرمجة
- **Vite** - أداة البناء
- **Axios** - طلبات HTTP
- **React Router** - التنقل بين الصفحات

## التثبيت والتشغيل

### المتطلبات
- Python 3.8+
- Node.js 16+
- npm أو yarn

### التطوير المحلي

1. **استنساخ المشروع**
```bash
git clone <repository-url>
cd test2
```

2. **إعداد البيئة**
```bash
# نسخ ملف البيئة
cp env.example .env
# تعديل المتغيرات في .env
```

3. **تثبيت المتطلبات**
```bash
# Backend
pip install -r requirements.txt

# Frontend
cd furniture-frontend
npm install
cd ..
```

4. **تشغيل قاعدة البيانات**
```bash
python init_db.py
```

5. **تشغيل التطبيق**
```bash
# Backend (Terminal 1)
uvicorn app.main:app --reload

# Frontend (Terminal 2)
cd furniture-frontend
npm run dev
```

### النشر على السيرفر

#### الخيار الأول: Docker (موصى به)

1. **تعديل الإعدادات**
```bash
# تعديل docker-compose.yml
# تعديل متغيرات البيئة
```

2. **تشغيل التطبيق**
```bash
docker-compose up -d
```

#### الخيار الثاني: النشر المباشر

1. **إعداد السيرفر**
```bash
# تثبيت Python, Node.js, MySQL
sudo apt update
sudo apt install python3 python3-pip nodejs npm mysql-server
```

2. **رفع الكود**
```bash
git clone <repository-url>
cd test2
```

3. **إعداد قاعدة البيانات**
```sql
CREATE DATABASE dab_store;
CREATE USER 'dab_user'@'localhost' IDENTIFIED BY 'your_password';
GRANT ALL PRIVILEGES ON dab_store.* TO 'dab_user'@'localhost';
FLUSH PRIVILEGES;
```

4. **تعديل الإعدادات**
```bash
cp env.example .env
# تعديل DATABASE_URL, SECRET_KEY, إلخ
```

5. **تشغيل التطبيق**
```bash
# تشغيل سكريبت النشر
chmod +x deploy.sh
./deploy.sh production
```

#### الخيار الثالث: خدمات النشر السحابية

**Railway (مجاني)**
1. رفع الكود إلى GitHub
2. ربط المشروع بـ Railway
3. إعداد متغيرات البيئة
4. النشر التلقائي

**Render (مجاني)**
1. رفع الكود إلى GitHub
2. إنشاء Web Service في Render
3. إعداد Build Command: `pip install -r requirements.txt`
4. إعداد Start Command: `gunicorn app.main:app -c gunicorn.conf.py`

**Vercel (للويب)**
1. رفع مجلد `furniture-frontend` إلى Vercel
2. إعداد Environment Variables
3. النشر التلقائي

## متغيرات البيئة

```bash
# قاعدة البيانات
DATABASE_URL=mysql+pymysql://user:password@host/database

# الأمان
SECRET_KEY=your-super-secret-key

# البريد الإلكتروني
SMTP_USERNAME=your_gmail@gmail.com
SMTP_PASSWORD=your_app_password
EMAIL_FROM=your_gmail@gmail.com

# CORS
CORS_ORIGINS=https://yourdomain.com
```

## API Documentation

بعد تشغيل الخادم، يمكن الوصول إلى وثائق API على:
- Swagger UI: `http://localhost:8000/docs`
- ReDoc: `http://localhost:8000/redoc`

## المساهمة

1. Fork المشروع
2. إنشاء branch جديد (`git checkout -b feature/AmazingFeature`)
3. Commit التغييرات (`git commit -m 'Add some AmazingFeature'`)
4. Push إلى Branch (`git push origin feature/AmazingFeature`)
5. فتح Pull Request

## الترخيص

هذا المشروع مرخص تحت رخصة MIT.

## الدعم

للدعم والمساعدة، يرجى التواصل عبر:
- 📧 البريد الإلكتروني: support@dabstore.com
- 💬 GitHub Issues 