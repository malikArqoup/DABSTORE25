import React from 'react';
import { Link } from 'react-router-dom';
import './PublicNavbar.css';

const username = localStorage.getItem('username') || 'زائر';

const PublicNavbar = () => (
  <nav className="wp-navbar">
    <div className="wp-logo">
      <span>Welcome, {username}</span>
    </div>
    <div className="wp-spacer"></div>
    <div className="wp-navlinks">
      <Link to="/">الرئيسية</Link>
      <Link to="/products-public">جميع المنتجات</Link>
      <Link to="/my-cart">منتجاتي</Link>
    </div>
  </nav>
);

export default PublicNavbar; 