import React, { useState } from "react";
import "./ProductForm.css";

/**
 * Reusable ProductForm component for adding/editing products.
 * Props:
 * - initialValues: { name, description, price, category, image }
 * - onSubmit: function to handle form submission
 * - fixedCategory: if set, category is fixed and field is disabled/hidden
 * - submitLabel: button label
 * - loading: loading state for submit
 */
const ProductForm = ({ initialValues, onSubmit, fixedCategory, submitLabel, loading }) => {
  const [form, setForm] = useState({
    name: initialValues.name || "",
    description: initialValues.description || "",
    price: initialValues.price || "",
    category: initialValues.category || "",
    image: null,
    categoryCustom: "",
    stock_quantity: initialValues.stock_quantity || 0,
    discount_percent: initialValues.discount_percent || 0,
  });
  const [error, setError] = useState("");

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      setForm((prev) => ({ ...prev, image: e.target.files[0] }));
    }
  };

  const handleSelectChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value, categoryCustom: value === "أخرى" ? prev.categoryCustom : "" }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setError("");
    // Validate required fields
    if (!form.name || !form.price || (!fixedCategory && !form.category && !form.categoryCustom)) {
      setError("يرجى تعبئة جميع الحقول المطلوبة.");
      return;
    }
    // Compose form data
    const formData = new FormData();
    formData.append("name", form.name);
    formData.append("description", form.description);
    formData.append("price", form.price);
    formData.append(
      "category",
      fixedCategory ? fixedCategory : (form.category === "أخرى" ? form.categoryCustom : form.category)
    );
    formData.append("stock_quantity", form.stock_quantity);
    formData.append("discount_percent", form.discount_percent);
    if (form.image) formData.append("image", form.image);
    onSubmit(formData);
  };

  return (
    <form className="product-form" onSubmit={handleSubmit}>
      <div className="form-group">
        <label>اسم المنتج *</label>
        <input
          type="text"
          name="name"
          value={form.name}
          onChange={handleChange}
          required
          className="form-input"
        />
      </div>
      <div className="form-group">
        <label>الوصف</label>
        <textarea
          name="description"
          value={form.description}
          onChange={handleChange}
          className="form-input"
        />
      </div>
      <div className="form-group">
        <label>السعر *</label>
        <input
          type="number"
          name="price"
          value={form.price}
          onChange={handleChange}
          required
          step="0.01"
          className="form-input"
        />
      </div>
      {/* Category field: hidden/disabled if fixedCategory is set */}
      {!fixedCategory && (
        <div className="form-group">
          <label>الفئة *</label>
          <select
            name="category"
            value={form.category}
            onChange={handleSelectChange}
            required
            className="form-input"
          >
            <option value="">اختر الفئة</option>
            <option value="رجالي">رجالي</option>
            <option value="نسائي">نسائي</option>
            <option value="أخرى">أخرى</option>
          </select>
          {form.category === "أخرى" && (
            <input
              type="text"
              name="categoryCustom"
              placeholder="اكتب الفئة..."
              value={form.categoryCustom || ""}
              onChange={e => setForm(prev => ({ ...prev, categoryCustom: e.target.value }))}
              className="form-input"
              style={{ marginTop: 8 }}
            />
          )}
        </div>
      )}
      {fixedCategory && (
        <input type="hidden" name="category" value={fixedCategory} />
      )}
      <div className="form-group">
        <label>الصورة</label>
        <input
          type="file"
          name="image"
          accept="image/*"
          onChange={handleFileChange}
          className="form-input"
        />
      </div>
      <div className="form-group">
        <label>الكمية المتوفرة *</label>
        <input
          type="number"
          name="stock_quantity"
          value={form.stock_quantity}
          onChange={handleChange}
          min="0"
          required
          className="form-input"
        />
      </div>
      <div className="form-group">
        <label>الخصم (%)</label>
        <input
          type="number"
          name="discount_percent"
          value={form.discount_percent}
          onChange={handleChange}
          min="0"
          max="100"
          className="form-input"
        />
      </div>
      {error && <div className="form-error">{error}</div>}
      <button
        type="submit"
        className="form-submit-btn"
        disabled={loading}
      >
        {loading ? "جاري الإضافة..." : submitLabel || "إضافة المنتج"}
      </button>
    </form>
  );
};

export default ProductForm; 