import React from 'react';
import './PublicFilter.css';

const PublicFilter = ({
  search, setSearch,
  minPrice, setMinPrice,
  maxPrice, setMaxPrice,
  category, setCategory,
  categories = [],
  discountOnly, setDiscountOnly,
  showCategory = true
}) => (
  <div className="wp-filters">
    <input type="text" placeholder="بحث بالاسم..." value={search} onChange={e => setSearch(e.target.value)} />
    <input type="number" placeholder="أقل سعر" value={minPrice} onChange={e => setMinPrice(e.target.value)} />
    <input type="number" placeholder="أعلى سعر" value={maxPrice} onChange={e => setMaxPrice(e.target.value)} />
    {showCategory && (
      <select value={category} onChange={e => setCategory(e.target.value)}>
        <option value="">كل الفئات</option>
        {categories.map(cat => <option key={cat} value={cat}>{cat}</option>)}
      </select>
    )}
    <label><input type="checkbox" checked={discountOnly} onChange={e => setDiscountOnly(e.target.checked)} /> خصومات فقط</label>
  </div>
);

export default PublicFilter; 