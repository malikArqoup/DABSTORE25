import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { authAPI, User, Admin } from '../services/api';

interface AuthContextType {
  user: User | Admin | null;
  isAdmin: boolean;
  isLoading: boolean;
  login: (username: string, password: string, isAdmin: boolean) => Promise<void>;
  logout: () => void;
  register: (username: string, email: string, password: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | Admin | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const initializeAuth = async () => {
      const token = localStorage.getItem('token');
      const userType = localStorage.getItem('userType');
      
      if (token && userType) {
        try {
          if (userType === 'admin') {
            const response = await authAPI.getAdminMe();
            setUser(response.data);
            setIsAdmin(true);
          } else {
            const response = await authAPI.getUserMe();
            setUser(response.data);
            setIsAdmin(false);
          }
        } catch (error) {
          console.error('Failed to get user info:', error);
          localStorage.removeItem('token');
          localStorage.removeItem('userType');
        }
      }
      setIsLoading(false);
    };

    initializeAuth();
  }, []);

  const login = async (username: string, password: string, isAdminLogin: boolean) => {
    try {
      if (isAdminLogin) {
        const response = await authAPI.adminLogin({ username, password });
        localStorage.setItem('token', response.data.access_token);
        localStorage.setItem('userType', 'admin');
        try {
          const adminResponse = await authAPI.getAdminMe();
          setUser(adminResponse.data);
          setIsAdmin(true);
        } catch (error) {
          setUser(null);
          setIsAdmin(false);
        }
      } else {
        const response = await authAPI.userLogin({ username, password });
        localStorage.setItem('token', response.data.access_token);
        localStorage.setItem('userType', 'user');
        try {
          const userResponse = await authAPI.getUserMe();
          setUser(userResponse.data);
          setIsAdmin(false);
        } catch (error) {
          setUser(null);
          setIsAdmin(false);
        }
      }
    } catch (error) {
      console.error('Login failed:', error);
      throw error;
    }
  };

  const register = async (username: string, email: string, password: string) => {
    try {
      const response = await authAPI.userRegister({ username, email, password });
      setUser(response.data);
      setIsAdmin(false);
    } catch (error) {
      console.error('Registration failed:', error);
      throw error;
    }
  };

  const logout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('userType');
    localStorage.removeItem('userUsername');
    localStorage.removeItem('userPassword');
    setUser(null);
    setIsAdmin(false);
    window.location.href = '/login';
  };

  const value: AuthContextType = {
    user,
    isAdmin,
    isLoading,
    login,
    logout,
    register,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}; 