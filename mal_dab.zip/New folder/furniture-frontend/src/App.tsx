import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import ProtectedRoute from './components/ProtectedRoute';

// Pages
import Home from './pages/Home';
import UserLogin from './pages/UserLogin';
import AdminLogin from './pages/AdminLogin';
import AdminDashboard from './pages/AdminDashboard';
import AdminRegister from './pages/AdminRegister';
import AddProduct from './pages/AddProduct';
import ProductsList from './pages/ProductsList';
import EditProduct from './pages/EditProduct';
import OrdersList from './pages/OrdersList';
import UsersList from './pages/UsersList';
import CustomerHome from './pages/CustomerHome';
import Login from './pages/Login';
import Cart from './pages/Cart';
import MyOrders from './pages/MyOrders';
import AddProductWomen from './pages/AddProductWomen';
import AddProductMen from './pages/AddProductMen';
import ProductsListMen from './pages/ProductsListMen';
import ProductsListWomen from './pages/ProductsListWomen';
import WomenProductsPublic from './pages/WomenProductsPublic';
import MenProductsPublic from './pages/MenProductsPublic';
import WomenProducts from './pages/WomenProducts';
import MyCart from './pages/MyCart';
import ProductsPublic from './pages/ProductsPublic';
import AdminSlider from './pages/AdminSlider';

function App() {
  return (
    <Router>
      <AuthProvider>
        <Routes>
          <Route path="/" element={<CustomerHome />} />
          <Route path="/login" element={<Login />} />
          <Route path="/admin/login" element={<Login />} />
          <Route path="/admin/register" element={<AdminRegister />} />
          <Route path="/admin/dashboard" element={<AdminDashboard />} />
          <Route path="/admin/products" element={<ProtectedRoute><ProductsList /></ProtectedRoute>} />
          <Route path="/admin/orders" element={<ProtectedRoute><OrdersList /></ProtectedRoute>} />
          <Route path="/admin/users" element={<ProtectedRoute><UsersList /></ProtectedRoute>} />
          <Route path="/edit-product/:productId" element={<ProtectedRoute><EditProduct /></ProtectedRoute>} />
          <Route path="/add-product" element={<ProtectedRoute><AddProduct /></ProtectedRoute>} />
          <Route path="/add-women-product" element={<ProtectedRoute><AddProductWomen /></ProtectedRoute>} />
          <Route path="/add-men-product" element={<ProtectedRoute><AddProductMen /></ProtectedRoute>} />
          <Route path="/products" element={<ProtectedRoute><ProductsList /></ProtectedRoute>} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/my-orders" element={<MyOrders />} />
          <Route path="/men-products" element={<ProtectedRoute><ProductsListMen /></ProtectedRoute>} />
          <Route path="/women-products" element={<WomenProductsPublic />} />
          <Route path="/women-products-public" element={<WomenProductsPublic />} />
          <Route path="/men-products-public" element={<MenProductsPublic />} />
          <Route path="/my-cart" element={<MyCart />} />
          <Route path="/products-public" element={<ProductsPublic />} />
          <Route path="/admin/slider" element={<ProtectedRoute requireAdmin={true}><AdminSlider /></ProtectedRoute>} />
          <Route path="/admin/men-products" element={<ProtectedRoute><ProductsListMen /></ProtectedRoute>} />
          <Route path="/admin/women-products" element={<ProtectedRoute><ProductsListWomen /></ProtectedRoute>} />
          <Route path="*" element={<CustomerHome />} />
        </Routes>
      </AuthProvider>
    </Router>
  );
}

export default App; 