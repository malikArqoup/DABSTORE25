import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { productsAPI, Product } from '../services/api';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Navigation, Autoplay } from 'swiper/modules';
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/autoplay';

const CustomerHome: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const [sliderImages, setSliderImages] = useState<string[]>([]);
  const [isMobile, setIsMobile] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth <= 768);
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);

    // Trigger animation after component mounts
    setTimeout(() => {
      setIsLoaded(true);
    }, 100);

    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await productsAPI.getAll();
        setProducts(response.data);
      } catch (err) {
        setError('فشل في تحميل المنتجات');
      } finally {
        setLoading(false);
      }
    };
    fetchProducts();
    fetchSliderImages();
  }, []);

  const fetchSliderImages = async () => {
    try {
      const response = await fetch('http://localhost:8000/api/v1/slider-images/');
      if (response.ok) {
        const data = await response.json();
        const imageUrls = data.map((item: any) => `http://localhost:8000${item.image_url}`);
        setSliderImages(imageUrls);
      }
    } catch (error) {
      console.error('Error fetching slider images:', error);
      // Fallback images
      setSliderImages([
        '/men-watch.jpg',
        '/women-watch.jpg'
      ]);
    }
  };

  const handleAddToCart = (product: Product) => {
    let cart = JSON.parse(localStorage.getItem('cart') || '[]');
    const existing = cart.find((item: any) => item.id === product.id);
    if (existing) {
      existing.quantity += 1;
    } else {
      cart.push({ ...product, quantity: 1 });
    }
    localStorage.setItem('cart', JSON.stringify(cart));
    alert(`تمت إضافة ${product.name} للسلة! يرجى تأكيد الطلب من صفحة السلة.`);
  };

  const containerStyle = {
    opacity: isLoaded ? 1 : 0,
    transform: isLoaded ? 'translateY(0)' : 'translateY(20px)',
    transition: 'opacity 1.2s ease-out, transform 1.2s ease-out'
  };

  const navStyle = {
    opacity: isLoaded ? 1 : 0,
    transform: isLoaded ? 'translateY(0)' : 'translateY(-20px)',
    transition: 'opacity 1s ease-out 0.3s, transform 1s ease-out 0.3s'
  };

  const heroStyle = {
    opacity: isLoaded ? 1 : 0,
    transform: isLoaded ? 'translateY(0)' : 'translateY(30px)',
    transition: 'opacity 1.2s ease-out 0.6s, transform 1.2s ease-out 0.6s'
  };

  const aboutStyle = {
    opacity: isLoaded ? 1 : 0,
    transform: isLoaded ? 'translateY(0)' : 'translateY(30px)',
    transition: 'opacity 1.2s ease-out 1s, transform 1.2s ease-out 1s'
  };

  const categoriesStyle = {
    opacity: isLoaded ? 1 : 0,
    transform: isLoaded ? 'translateY(0)' : 'translateY(30px)',
    transition: 'opacity 1.2s ease-out 1.4s, transform 1.2s ease-out 1.4s'
  };

  return (
    <div style={{ minHeight: '100vh', background: '#f5f7fa', overflowX: 'hidden' }}>
      <nav
        style={{
          background: 'linear-gradient(90deg, #232526 0%, #414345 100%)',
          boxShadow: '0 4px 24px 0 #00000018',
          padding: isMobile ? '0 4px' : '0 40px',
          display: 'flex',
          flexDirection: isMobile ? 'column' : 'row',
          alignItems: isMobile ? 'center' : 'center',
          justifyContent: isMobile ? 'center' : 'flex-start',
          height: isMobile ? 'auto' : '70px',
          position: 'sticky',
          top: 0,
          zIndex: 100,
          flexWrap: isMobile ? 'wrap' : 'nowrap',
          ...navStyle
        }}
      >
        <div style={{
          fontWeight: 'bold',
          fontSize: isMobile ? '1.2rem' : '2rem',
          color: '#fff',
          letterSpacing: '2px',
          margin: isMobile ? '8px 0 4px 0' : 0,
          minWidth: 90,
          textAlign: isMobile ? 'center' : 'left',
          width: isMobile ? '100%' : 'auto',
          display: 'flex',
          alignItems: 'center',
          justifyContent: isMobile ? 'center' : 'flex-start',
          gap: 8
        }}>
          {/* أيقونة ساعة */}
          <svg xmlns="http://www.w3.org/2000/svg" width={isMobile ? 22 : 28} height={isMobile ? 22 : 28} fill="none" viewBox="0 0 24 24" stroke="#fff" strokeWidth="2.2" style={{marginLeft: 4}}>
            <circle cx="12" cy="12" r="9" stroke="#fff" strokeWidth="2.2" fill="none"/>
            <path d="M12 7v5l3 3" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          <span style={{ color: '#fff', background: '#232526', borderRadius: '6px', padding: isMobile ? '2px 10px' : '2px 8px', marginRight: 4 }}>DAB</span>
          <span style={{ color: '#fff' }}>STORE</span>
        </div>
        <div style={{ display: 'flex', gap: isMobile ? '4px' : '32px', alignItems: 'center', marginLeft: isMobile ? 0 : 32, flexWrap: isMobile ? 'wrap' : 'nowrap', justifyContent: isMobile ? 'center' : 'flex-start', width: isMobile ? '100%' : 'auto' }}>
          <Link
            to="/"
            style={{
              color: '#fff',
              textDecoration: 'none',
              fontWeight: 500,
              fontSize: isMobile ? '0.85rem' : '1.1rem',
              padding: isMobile ? '4px 8px' : '6px 16px',
              borderRadius: '6px',
              transition: 'all 0.3s ease',
              textAlign: 'center',
              minWidth: 60,
              position: 'relative',
              overflow: 'hidden'
            }}
            onMouseOver={e => {
              e.currentTarget.style.background = 'rgba(255,255,255,0.15)';
              e.currentTarget.style.transform = 'translateY(-2px)';
              e.currentTarget.style.boxShadow = '0 4px 12px rgba(0,0,0,0.2)';
            }}
            onMouseOut={e => {
              e.currentTarget.style.background = 'transparent';
              e.currentTarget.style.transform = 'translateY(0)';
              e.currentTarget.style.boxShadow = 'none';
            }}
          >
            الرئيسية
          </Link>
          <Link
            to="/products"
            style={{
              color: '#fff',
              textDecoration: 'none',
              fontWeight: 500,
              fontSize: isMobile ? '0.85rem' : '1.1rem',
              padding: isMobile ? '4px 8px' : '6px 16px',
              borderRadius: '6px',
              transition: 'all 0.3s ease',
              textAlign: 'center',
              minWidth: 90,
              position: 'relative',
              overflow: 'hidden'
            }}
            onMouseOver={e => {
              e.currentTarget.style.background = 'rgba(255,255,255,0.15)';
              e.currentTarget.style.transform = 'translateY(-2px)';
              e.currentTarget.style.boxShadow = '0 4px 12px rgba(0,0,0,0.2)';
            }}
            onMouseOut={e => {
              e.currentTarget.style.background = 'transparent';
              e.currentTarget.style.transform = 'translateY(0)';
              e.currentTarget.style.boxShadow = 'none';
            }}
          >
            جميع المنتجات
          </Link>
          <Link
            to="/cart"
            style={{
              color: '#fff',
              textDecoration: 'none',
              fontWeight: 500,
              fontSize: isMobile ? '0.85rem' : '1.1rem',
              padding: isMobile ? '4px 8px' : '6px 16px',
              borderRadius: '6px',
              transition: 'all 0.3s ease',
              textAlign: 'center',
              minWidth: 60,
              position: 'relative',
              overflow: 'hidden'
            }}
            onMouseOver={e => {
              e.currentTarget.style.background = 'rgba(255,255,255,0.15)';
              e.currentTarget.style.transform = 'translateY(-2px)';
              e.currentTarget.style.boxShadow = '0 4px 12px rgba(0,0,0,0.2)';
            }}
            onMouseOut={e => {
              e.currentTarget.style.background = 'transparent';
              e.currentTarget.style.transform = 'translateY(0)';
              e.currentTarget.style.boxShadow = 'none';
            }}
          >
            السلة
          </Link>
          <Link
            to="/login"
            style={{
              background: 'linear-gradient(90deg, #232526 0%, #414345 100%)',
              color: '#fff',
              textDecoration: 'none',
              fontWeight: 600,
              fontSize: isMobile ? '0.85rem' : '1.1rem',
              padding: isMobile ? '4px 12px' : '8px 24px',
              borderRadius: '8px',
              boxShadow: '0 2px 8px #23252633',
              transition: 'all 0.3s ease',
              marginLeft: isMobile ? 0 : '12px',
              textAlign: 'center',
              minWidth: 80,
              position: 'relative',
              overflow: 'hidden'
            }}
            onMouseOver={e => {
              e.currentTarget.style.background = 'linear-gradient(90deg, #414345 0%, #232526 100%)';
              e.currentTarget.style.transform = 'translateY(-3px)';
              e.currentTarget.style.boxShadow = '0 6px 20px rgba(35,37,38,0.4)';
            }}
            onMouseOut={e => {
              e.currentTarget.style.background = 'linear-gradient(90deg, #232526 0%, #414345 100%)';
              e.currentTarget.style.transform = 'translateY(0)';
              e.currentTarget.style.boxShadow = '0 2px 8px #23252633';
            }}
          >
            تسجيل الدخول
          </Link>
        </div>
      </nav>

      {/* Hero Image مع خلفية ديناميكية كسلايدر واحد فقط باستخدام Swiper */}
      {sliderImages.length > 0 ? (
        <div style={{maxWidth:'100vw', overflow:'hidden', marginBottom:isMobile ? 16 : 32}}>
          <Swiper
            modules={[Autoplay]}
            autoplay={{ delay: 3500, disableOnInteraction: false }}
            loop={sliderImages.length > 1}
            speed={800}
            style={{ borderRadius: isMobile ? 0 : '0 0 18px 18px' }}
          >
            {sliderImages.slice(0, 3).map((imageUrl, index) => (
              <SwiperSlide key={index}>
                <div style={{
                  width: '100%',
                  minHeight: isMobile ? '220px' : '420px',
                  height: isMobile ? '220px' : '420px',
                  background: `linear-gradient(rgba(245,247,250,0.55), rgba(245,247,250,0.55)), url(${imageUrl}) center/cover no-repeat`,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  position: 'relative',
                  ...heroStyle
                }}>
                  <div style={{maxWidth:isMobile ? '100%' : '900px', width:'100%', display:'flex', flexDirection:'column', alignItems:'center', textAlign:'center', gap:'20px', zIndex:2}}>
                    <h1 style={{fontSize:isMobile ? '1.3rem' : '2.5rem', fontWeight:'bold', color:'#22223b', marginBottom:isMobile ? '10px' : '18px'}}>أضف لمسة فخامة إلى إطلالتك مع أفضل الساعات والإكسسوارات</h1>
                    <p style={{fontSize:isMobile ? '1rem' : '1.2rem', color:'#444', marginBottom:isMobile ? '10px' : '18px'}}>تسوق الآن من <bdi>DAB STORE</bdi> وتمتع بجودة مضمونة، تصاميم عصرية، وخدمة توصيل سريعة.</p>
                    <button
                      style={{
                        padding: isMobile ? '8px 18px' : '12px 32px',
                        background: '#2563eb',
                        color: '#fff',
                        border: 'none',
                        borderRadius: '8px',
                        fontSize: isMobile ? '1rem' : '1.1rem',
                        fontWeight: 'bold',
                        cursor: 'pointer',
                        boxShadow: '0 2px 8px #e0eaff',
                        transition: 'background 0.2s'
                      }}
                      onClick={() => navigate('/products')}
                    >
                      تصفح المنتجات
                    </button>
                  </div>
                </div>
              </SwiperSlide>
            ))}
          </Swiper>
        </div>
      ) : (
        <div style={{
          width: '100%',
          minHeight: '260px',
          background: `linear-gradient(rgba(245,247,250,0.55), rgba(245,247,250,0.55)), url('https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1200&q=80') center/cover no-repeat`,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          padding: '48px 0 32px 0',
          marginBottom: 32,
          borderRadius: '0 0 18px 18px',
          ...heroStyle
        }}>
          <div style={{maxWidth:'900px', width:'100%', display:'flex', flexDirection:'column', alignItems:'center', textAlign:'center', gap:'20px'}}>
            <h1 style={{fontSize:'2.5rem', fontWeight:'bold', color:'#22223b', marginBottom:'18px'}}>أضف لمسة فخامة إلى إطلالتك مع أفضل الساعات والإكسسوارات</h1>
            <p style={{fontSize:'1.2rem', color:'#444', marginBottom:'18px'}}>تسوق الآن من <bdi>DAB STORE</bdi> وتمتع بجودة مضمونة، تصاميم عصرية، وخدمة توصيل سريعة.</p>
            <button
              style={{
                padding: isMobile ? '8px 18px' : '12px 32px',
                background: '#2563eb',
                color: '#fff',
                border: 'none',
                borderRadius: '8px',
                fontSize: isMobile ? '1rem' : '1.1rem',
                fontWeight: 'bold',
                cursor: 'pointer',
                boxShadow: '0 2px 8px #e0eaff',
                transition: 'background 0.2s'
              }}
              onClick={() => navigate('/products')}
            >
              تصفح المنتجات
            </button>
          </div>
        </div>
      )}

      {/* قسم التصنيفات */}
      <div style={{
        display:'flex',
        flexDirection: isMobile ? 'column' : 'row',
        justifyContent:'center',
        gap:isMobile ? '24px' : '48px',
        marginTop:isMobile ? '40px' : '90px',
        marginBottom:isMobile ? '24px' : '48px',
        alignItems: isMobile ? 'center' : 'unset',
        width: '100%',
        maxWidth: '100vw',
        padding: isMobile ? '0 8px' : 0,
        ...categoriesStyle
      }}>
        {/* بطاقة نسائي */}
        <div
          style={{
            background: '#f5f7fa',
            borderRadius: '18px',
            boxShadow: '0 6px 32px 0 rgba(37, 99, 235, 0.13)',
            width: isMobile ? '100%' : '420px',
            height: isMobile ? '180px' : '240px',
            display: 'flex',
            flexDirection: isMobile ? 'row' : 'unset',
            alignItems: 'center',
            position: 'relative',
            overflow: 'hidden',
            transition: 'all 0.4s cubic-bezier(.4,2,.3,1)',
            transform: 'translateY(0)',
            cursor: 'pointer',
            minWidth: isMobile ? '0' : 'unset',
            maxWidth: isMobile ? '400px' : 'unset',
            border: '1.5px solid #e0eaff',
            margin: '0 0 24px 0',
            backgroundImage: 'linear-gradient(120deg, #f5f7fa 60%, #e0eaff 100%)'
          }}
          onMouseOver={e => {
            e.currentTarget.style.transform = 'translateY(-8px) scale(1.03)';
            e.currentTarget.style.boxShadow = '0 16px 48px rgba(37,99,235,0.18)';
          }}
          onMouseOut={e => {
            e.currentTarget.style.transform = 'translateY(0) scale(1)';
            e.currentTarget.style.boxShadow = '0 6px 32px 0 rgba(37, 99, 235, 0.13)';
          }}
          onClick={() => navigate('/women-products')}
        >
          <img 
            src="/women-watch.jpg" 
            alt="ساعات نسائية" 
            style={{
              width: isMobile ? '40%' : '55%', 
              height: '100%', 
              objectFit: 'cover', 
              borderRadius: '18px 0 0 18px',
              filter: 'brightness(0.93)'
            }} 
          />
          <div style={{
            padding: isMobile ? '16px' : '32px', 
            flex: '1', 
            display: 'flex', 
            flexDirection: 'column', 
            justifyContent: 'center', 
            alignItems: 'flex-end'
          }}>
            <div style={{
              fontSize: isMobile ? '1.2rem' : '2rem', 
              fontWeight: 'bold', 
              color: '#232526', 
              marginBottom: isMobile ? '8px' : '16px',
              letterSpacing: '1px',
              textShadow: '0 2px 8px #e0eaff'
            }}>
              ساعات نسائية
            </div>
            <button 
              className="main-btn" 
              style={{
                fontSize: isMobile ? '1.08rem' : '1.13rem',
                padding: isMobile ? '10px 22px' : '13px 32px',
                borderRadius: '30px',
                background: 'linear-gradient(90deg, #2563eb 0%, #1746a0 100%)',
                color: '#fff',
                fontWeight: 700,
                boxShadow: '0 2px 12px #2563eb33',
                border: 'none',
                display: 'flex',
                alignItems: 'center',
                gap: 10,
                cursor: 'pointer',
                transition: 'all 0.25s cubic-bezier(.4,2,.3,1)',
                marginTop: 8
              }} 
              onMouseOver={e => {
                e.currentTarget.style.background = 'linear-gradient(90deg, #1746a0 0%, #2563eb 100%)';
                e.currentTarget.style.transform = 'scale(1.07)';
                e.currentTarget.style.boxShadow = '0 8px 32px #2563eb33';
              }}
              onMouseOut={e => {
                e.currentTarget.style.background = 'linear-gradient(90deg, #2563eb 0%, #1746a0 100%)';
                e.currentTarget.style.transform = 'scale(1)';
                e.currentTarget.style.boxShadow = '0 2px 12px #2563eb33';
              }}
            >
              اكتشف المزيد
              <span style={{display:'inline-flex',alignItems:'center',marginRight:4}}>
                <svg width="22" height="22" fill="none" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" viewBox="0 0 24 24"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
              </span>
            </button>
          </div>
        </div>

        {/* بطاقة رجالي */}
        <div
          style={{
            background: '#f5f7fa',
            borderRadius: '18px',
            boxShadow: '0 6px 32px 0 rgba(235, 100, 37, 0.13)',
            width: isMobile ? '100%' : '420px',
            height: isMobile ? '180px' : '240px',
            display: 'flex',
            flexDirection: isMobile ? 'row' : 'unset',
            alignItems: 'center',
            position: 'relative',
            overflow: 'hidden',
            transition: 'all 0.4s cubic-bezier(.4,2,.3,1)',
            transform: 'translateY(0)',
            cursor: 'pointer',
            minWidth: isMobile ? '0' : 'unset',
            maxWidth: isMobile ? '400px' : 'unset',
            border: '1.5px solid #fbe4d6',
            margin: '0 0 24px 0',
            backgroundImage: 'linear-gradient(120deg, #f5f7fa 60%, #fbe4d6 100%)'
          }}
          onMouseOver={e => {
            e.currentTarget.style.transform = 'translateY(-8px) scale(1.03)';
            e.currentTarget.style.boxShadow = '0 16px 48px rgba(235, 100, 37, 0.18)';
          }}
          onMouseOut={e => {
            e.currentTarget.style.transform = 'translateY(0) scale(1)';
            e.currentTarget.style.boxShadow = '0 6px 32px 0 rgba(235, 100, 37, 0.13)';
          }}
          onClick={() => navigate('/men-products-public')}
        >
          <img 
            src="/men-watch.jpg" 
            alt="ساعات رجالية" 
            style={{
              width: isMobile ? '40%' : '55%', 
              height: '100%', 
              objectFit: 'cover', 
              borderRadius: '18px 0 0 18px',
              filter: 'brightness(0.93)'
            }} 
          />
          <div style={{
            padding: isMobile ? '16px' : '32px', 
            flex: '1', 
            display: 'flex', 
            flexDirection: 'column', 
            justifyContent: 'center', 
            alignItems: 'flex-end'
          }}>
            <div style={{
              fontSize: isMobile ? '1.2rem' : '2rem', 
              fontWeight: 'bold', 
              color: '#222', 
              marginBottom: isMobile ? '8px' : '16px',
              letterSpacing: '1px',
              textShadow: '0 2px 8px #fbe4d6'
            }}>
              ساعات رجالية
            </div>
            <button 
              className="main-btn" 
              style={{
                fontSize: isMobile ? '1.08rem' : '1.13rem',
                padding: isMobile ? '10px 22px' : '13px 32px',
                borderRadius: '30px',
                background: 'linear-gradient(90deg, #eb6425 0%, #a03c17 100%)',
                color: '#fff',
                fontWeight: 700,
                boxShadow: '0 2px 12px #eb642533',
                border: 'none',
                display: 'flex',
                alignItems: 'center',
                gap: 10,
                cursor: 'pointer',
                transition: 'all 0.25s cubic-bezier(.4,2,.3,1)',
                marginTop: 8
              }} 
              onMouseOver={e => {
                e.currentTarget.style.background = 'linear-gradient(90deg, #a03c17 0%, #eb6425 100%)';
                e.currentTarget.style.transform = 'scale(1.07)';
                e.currentTarget.style.boxShadow = '0 8px 32px #eb642533';
              }}
              onMouseOut={e => {
                e.currentTarget.style.background = 'linear-gradient(90deg, #eb6425 0%, #a03c17 100%)';
                e.currentTarget.style.transform = 'scale(1)';
                e.currentTarget.style.boxShadow = '0 2px 12px #eb642533';
              }}
            >
              اكتشف المزيد
              <span style={{display:'inline-flex',alignItems:'center',marginRight:4}}>
                <svg width="22" height="22" fill="none" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" viewBox="0 0 24 24"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* Products Slider */}
      <div
        style={{
          width: isMobile
            ? '100vw'
            : products.length < 3
            ? products.length === 2
              ? 700
              : 350
            : '1200px',
          margin: '0 auto',
          padding: isMobile ? '18px 2vw' : '32px 16px',
          background: 'transparent',
          transition: 'width 0.3s',
          maxWidth: '100vw',
          boxSizing: 'border-box',
        }}
      >
        <h2
          style={{
            fontSize: isMobile ? '1.2rem' : '2rem',
            fontWeight: 'bold',
            color: '#222',
            marginBottom: isMobile ? '16px' : '24px',
            textAlign: 'center',
          }}
        >
          منتجاتنا المميزة
        </h2>
        {loading ? (
          <div style={{textAlign:'center', color:'#888'}}>جاري التحميل...</div>
        ) : error ? (
          <div style={{textAlign:'center', color:'red'}}>{error}</div>
        ) : (
          <>
            <Swiper
              modules={[Autoplay]}
              autoplay={{ delay: 3500, disableOnInteraction: false }}
              slidesPerView={isMobile ? 1 : products.length >= 3 ? 3 : products.length}
              spaceBetween={isMobile ? 8 : 18}
              loop={products.length > 3}
              speed={600}
              centeredSlides={false}
              style={{ direction: 'ltr', padding: isMobile ? '0 0px' : '0 0px' }}
              breakpoints={{
                900: { slidesPerView: 2 },
                600: { slidesPerView: 1 },
              }}
            >
              {products.slice(0, 6).map(product => {
                let imageUrl = 'https://via.placeholder.com/220x160?text=No+Image';
                if (product.image_url) {
                  if (product.image_url.startsWith('http')) {
                    imageUrl = product.image_url;
                  } else if (product.image_url.startsWith('/')) {
                    imageUrl = `http://127.0.0.1:8000${product.image_url}`;
                  } else {
                    imageUrl = `http://127.0.0.1:8000/api/v1/images/products/${product.id}/${product.image_url}`;
                  }
                }
                return (
                  <SwiperSlide key={product.id}>
                    <div style={{display:'flex',justifyContent:'center'}}>
                      <div style={{
                        background: '#f5f7fa',
                        borderRadius: isMobile ? '14px' : '22px',
                        boxShadow: '0 15px 32px 10 rgba(202, 247, 5, 0.22), 0 2px 8px 0 rgba(0,0,0,0.10)',
                        padding: isMobile ? '14px 8px 12px 8px' : '24px 20px 20px 20px',
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        width: isMobile ? '92vw' : 320,
                        minHeight: isMobile ? 270 : 390,
                        margin: isMobile ? '0 2vw' : '0 16px',
                        position: 'relative',
                        transition: 'box-shadow 0.22s, transform 0.22s',
                        overflow: 'hidden',
                        fontFamily: 'Tajawal, Arial, sans-serif',
                        zIndex: 3
                      }}
                      onMouseOver={e => {
                        e.currentTarget.style.transform = 'translateY(-10px) scale(1.035)';
                        e.currentTarget.style.boxShadow = '0 16px 48px 0 rgba(37,99,235,0.18)';
                      }}
                      onMouseOut={e => {
                        e.currentTarget.style.transform = 'translateY(0) scale(1)';
                        e.currentTarget.style.boxShadow = '0 6px 32px 0 rgba(37, 99, 235, 0.13)';
                      }}
                      >
                        {/* شارة مميز */}
                        <span style={{
                          position: 'absolute',
                          top: isMobile ? -12 : -18,
                          left: isMobile ? 8 : 18,
                          background: 'linear-gradient(90deg, #2563eb 0%, #22c55e 100%)',
                          color: '#fff',
                          fontWeight: 700,
                          fontSize: isMobile ? 11 : 13,
                          padding: isMobile ? '2px 10px' : '4px 18px',
                          borderRadius: '16px',
                          boxShadow: '0 2px 8px #2563eb33',
                          letterSpacing: 1
                        }}>مميز</span>
                        {/* صورة المنتج مع حركة */}
                        <div style={{width:'100%',height:isMobile?110:180,overflow:'hidden',borderRadius:isMobile?'10px':'16px',marginBottom:isMobile?10:16,boxShadow:'0 2px 12px #e0eaff',background:'#f5f7fa',display:'flex',alignItems:'center',justifyContent:'center'}}>
                          <img 
                            src={imageUrl} 
                            alt={product.name} 
                            style={{
                              width: '100%',
                              height: '100%',
                              objectFit: 'cover',
                              borderRadius: isMobile ? '10px' : '16px',
                              transition: 'transform 0.35s cubic-bezier(.4,2,.3,1)',
                            }}
                            onMouseOver={e => e.currentTarget.style.transform = 'scale(1.08)'}
                            onMouseOut={e => e.currentTarget.style.transform = 'scale(1)'}
                          />
                        </div>
                        {/* اسم المنتج */}
                        <h3 style={{
                          fontSize: isMobile ? '1rem' : '1.18rem',
                          fontWeight: 800,
                          color: '#232526',
                          marginBottom: isMobile ? 5 : 7,
                          textAlign: 'center',
                          letterSpacing: 0.5
                        }}>{product.name}</h3>
                        {/* السعر */}
                        <div style={{
                          color: '#2563eb',
                          fontWeight: 700,
                          fontSize: isMobile ? '1rem' : '1.13rem',
                          marginBottom: isMobile ? 8 : 13,
                          fontFamily: 'inherit',
                          textShadow: '0 1px 0 #fff'
                        }}>{product.price} شيقل</div>
                        {/* زر السلة مع تأثير */}
                        <button 
                          onClick={() => handleAddToCart(product)} 
                          style={{
                            padding: isMobile ? '9px 0' : '12px 0',
                            background: 'linear-gradient(135deg, #22c55e 0%, #16a34a 100%)',
                            color: '#fff',
                            border: 'none',
                            borderRadius: isMobile ? 10 : 14,
                            fontWeight: 800,
                            cursor: 'pointer',
                            fontSize: isMobile ? '0.98rem' : '1.09rem',
                            width: '100%',
                            marginTop: isMobile ? 6 : 8,
                            boxShadow: '0 2px 8px #22c55e33',
                            transition: 'all 0.22s',
                            letterSpacing: 1
                          }}
                          onMouseDown={e => {
                            e.currentTarget.style.background = 'linear-gradient(135deg, #16a34a 0%, #22c55e 100%)';
                            e.currentTarget.style.transform = 'scale(0.97)';
                          }}
                          onMouseUp={e => {
                            e.currentTarget.style.background = 'linear-gradient(135deg, #22c55e 0%, #16a34a 100%)';
                            e.currentTarget.style.transform = 'scale(1)';
                          }}
                          onMouseOver={e => {
                            e.currentTarget.style.background = 'linear-gradient(135deg, #16a34a 0%, #22c55e 100%)';
                            e.currentTarget.style.transform = 'scale(1.04)';
                          }}
                          onMouseOut={e => {
                            e.currentTarget.style.background = 'linear-gradient(135deg, #22c55e 0%, #16a34a 100%)';
                            e.currentTarget.style.transform = 'scale(1)';
                          }}
                        >
                          أضف للسلة
                        </button>
                      </div>
                    </div>
                  </SwiperSlide>
                );
              })}
            </Swiper>
            <div style={{textAlign:'center', marginTop:'24px'}}>
              <button
                className="main-btn"
                onClick={()=>navigate('/products-public')}
                style={{
                  fontSize: isMobile ? '1.13rem' : '1.22rem',
                  padding: isMobile ? '12px 32px' : '16px 48px',
                  borderRadius: '30px',
                  background: 'linear-gradient(90deg, #2563eb 0%, #1746a0 100%)',
                  color: '#fff',
                  fontWeight: 700,
                  boxShadow: '0 2px 12px #2563eb33',
                  border: 'none',
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: 10,
                  cursor: 'pointer',
                  transition: 'all 0.25s cubic-bezier(.4,2,.3,1)',
                  letterSpacing: 1,
                  margin: '0 auto',
                  marginTop: 8
                }}
                onMouseOver={e => {
                  e.currentTarget.style.background = 'linear-gradient(90deg, #1746a0 0%, #2563eb 100%)';
                  e.currentTarget.style.transform = 'scale(1.07)';
                  e.currentTarget.style.boxShadow = '0 8px 32px #2563eb33';
                }}
                onMouseOut={e => {
                  e.currentTarget.style.background = 'linear-gradient(90deg, #2563eb 0%, #1746a0 100%)';
                  e.currentTarget.style.transform = 'scale(1)';
                  e.currentTarget.style.boxShadow = '0 2px 12px #2563eb33';
                }}
              >
                رؤية جميع المنتجات
                <span style={{display:'inline-flex',alignItems:'center',marginRight:4}}>
                  <svg width="22" height="22" fill="none" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" viewBox="0 0 24 24"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
                </span>
              </button>
            </div>
          </>
        )}
      </div>
      {/* قسم من نحن */}
      <div
        style={{
          background: '#d7deea',
          borderRadius: '16px',
          boxShadow: '0 2px 12px #eee',
          maxWidth: isMobile ? '98vw' : '900px',
          margin: isMobile ? '24px auto 0 auto' : '40px auto 0 auto',
          padding: isMobile ? '24px 8px 18px 8px' : '40px 36px 36px 36px',
          direction: 'rtl',
          ...aboutStyle
        }}
      >
        <div style={{ fontWeight: 'bold', fontSize: isMobile ? '1.5rem' : '2.3rem', color: '#232526', marginBottom: isMobile ? '12px' : '18px', letterSpacing: '1px', textAlign: 'center' }}>
          DAB STORE
        </div>
        <div style={{ fontSize: isMobile ? '1rem' : '1.15rem', color: '#444', lineHeight: 1.9, maxWidth: 800, textAlign: 'left', margin: '0 auto' }}>
          DAB STORE هو متجر إلكتروني متخصص في بيع الساعات والإكسسوارات العصرية بجودة عالية وأسعار منافسة.<br/>
          نؤمن بأن الأناقة تبدأ من التفاصيل، ونحرص على تقديم أفضل المنتجات وخدمة عملاء مميزة وتجربة تسوق سهلة وآمنة للجميع.
        </div>
      </div>
    </div>
  );
};

export default CustomerHome; 