import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ordersAPI } from '../services/api';
import './MyCart.css';

interface CartItem {
  id: number;
  name: string;
  price: number;
  quantity: number;
  image?: string;
}

const username = localStorage.getItem('username');

const Cart = () => {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const navigate = useNavigate();
  const [address, setAddress] = useState('');
  const [phone, setPhone] = useState('');
  const [notes, setNotes] = useState('');

  useEffect(() => {
    const stored = JSON.parse(localStorage.getItem('cart') || '[]');
    setCart(stored);
  }, []);

  const updateQuantity = (id, qty) => {
    const updated = cart.map(item => item.id === id ? { ...item, quantity: Math.max(1, qty) } : item);
    setCart(updated);
    localStorage.setItem('cart', JSON.stringify(updated));
  };

  const handleQtyChange = (id, qty) => {
    updateQuantity(id, Number(qty));
  };

  const handleQtyPlus = (id) => {
    const item = cart.find(i => i.id === id);
    if (item) updateQuantity(id, item.quantity + 1);
  };
  const handleQtyMinus = (id) => {
    const item = cart.find(i => i.id === id);
    if (item && item.quantity > 1) updateQuantity(id, item.quantity - 1);
  };

  const removeItem = (id) => {
    const updated = cart.filter(item => item.id !== id);
    setCart(updated);
    localStorage.setItem('cart', JSON.stringify(updated));
  };

  const handleOrder = async () => {
    if (cart.length === 0) return;
    if (!address.trim() || !phone.trim()) {
      setMessage('يرجى إدخال عنوان الشحن ورقم الهاتف.');
      return;
    }
    setLoading(true);
    setMessage('');
    try {
      const items = cart.map(item => ({ product_id: item.id, quantity: item.quantity }));
      await ordersAPI.create({
        shipping_address: address,
        phone_number: phone,
        notes,
        items
      });
      setMessage('تم إرسال الطلب بنجاح!');
      setCart([]);
      localStorage.removeItem('cart');
      setTimeout(() => navigate('/'), 1500);
    } catch (err) {
      setMessage('حدث خطأ أثناء إرسال الطلب.');
    } finally {
      setLoading(false);
    }
  };

  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  return (
    <div className="cart-bg">
      <div className="cart-container">
        <button onClick={()=>navigate(-1)} className="cart-back-btn">رجوع</button>
        <h2 className="cart-title">سلة المشتريات</h2>
        {username && <div className="cart-welcome">مرحباً <bdi>{username}</bdi> 👋</div>}
        {cart.length === 0 ? (
          <div className="cart-center">السلة فارغة</div>
        ) : (
          <>
            <div className="cart-list">
              {cart.map(item => (
                <div className="cart-card" key={item.id}>
                  {item.image && <img src={item.image} alt={item.name} className="cart-img" />}
                  <div className="cart-info">
                    <div className="cart-prod-name">{item.name}</div>
                    <div className="cart-prod-price">{item.price} شيقل</div>
                    <div className="cart-qty-row">
                      <button type="button" className="cart-qty-btn" onClick={()=>handleQtyMinus(item.id)} disabled={item.quantity<=1}>-</button>
                      <input type="number" min={1} value={item.quantity} onChange={e=>handleQtyChange(item.id, e.target.value)} className="cart-qty-input" />
                      <button type="button" className="cart-qty-btn" onClick={()=>handleQtyPlus(item.id)}>+</button>
                    </div>
                    <div className="cart-prod-total">الإجمالي: <b>{item.price * item.quantity} شيقل</b></div>
                  </div>
                  <button onClick={()=>removeItem(item.id)} className="cart-remove-btn">حذف</button>
                </div>
              ))}
            </div>
            <div className="cart-summary-card">
              <span>المجموع الكلي:</span>
              <span className="cart-summary-total">{total} شيقل</span>
            </div>
            <form className="cart-form" onSubmit={e=>{e.preventDefault();handleOrder();}}>
              <div className="cart-input-row">
                <span className="cart-input-icon">🏠</span>
                <input type="text" placeholder="عنوان الشحن" value={address} onChange={e=>setAddress(e.target.value)} required className="cart-input" />
              </div>
              <div className="cart-input-row">
                <span className="cart-input-icon">📱</span>
                <input type="text" placeholder="رقم الهاتف" value={phone} onChange={e=>setPhone(e.target.value)} required className="cart-input" />
              </div>
              <div className="cart-input-row">
                <span className="cart-input-icon">📝</span>
                <textarea placeholder="ملاحظات إضافية (اختياري)" value={notes} onChange={e=>setNotes(e.target.value)} className="cart-textarea" />
              </div>
              {message && <div className={message.includes('نجاح') ? 'cart-success' : 'cart-error'}>{message}</div>}
              <button type="submit" className="cart-submit-btn" disabled={loading}>{loading ? 'جاري الإرسال...' : 'تأكيد الطلب'}</button>
            </form>
          </>
        )}
      </div>
    </div>
  );
};

export default Cart; 