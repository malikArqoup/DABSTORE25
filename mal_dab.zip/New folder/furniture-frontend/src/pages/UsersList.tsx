import React, { useEffect, useState } from 'react';
import { authAPI } from '../services/api';

interface User {
  id: number;
  username: string;
  email: string;
  is_active: boolean;
}

const UsersList: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [editId, setEditId] = useState<number|null>(null);
  const [editData, setEditData] = useState<{username:string,email:string,is_active:boolean}>({username:'',email:'',is_active:true});
  const [editMsg, setEditMsg] = useState('');
  const [editLoading, setEditLoading] = useState(false);

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://127.0.0.1:8000/api/v1/user/', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      if (!response.ok) throw new Error('فشل في جلب المستخدمين');
      const data = await response.json();
      setUsers(data);
    } catch (err) {
      setError('فشل في جلب المستخدمين');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (userId: number) => {
    if (!window.confirm('هل أنت متأكد من حذف هذا المستخدم؟')) return;
    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`http://127.0.0.1:8000/api/v1/user/${userId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      if (!response.ok) throw new Error('فشل في حذف المستخدم');
      setUsers(users.filter(u => u.id !== userId));
      alert('تم حذف المستخدم بنجاح');
    } catch (err) {
      alert('فشل في حذف المستخدم');
    }
  };

  const startEdit = (user: User) => {
    setEditId(user.id);
    setEditData({username: user.username, email: user.email, is_active: user.is_active});
    setEditMsg('');
  };
  const cancelEdit = () => {
    setEditId(null);
    setEditMsg('');
  };
  const handleEditSave = async (userId: number) => {
    setEditLoading(true);
    setEditMsg('');
    try {
      await authAPI.updateUser(userId, editData);
      setEditMsg('تم التعديل بنجاح!');
      setEditId(null);
      fetchUsers();
    } catch {
      setEditMsg('فشل في التعديل. ربما الإيميل أو الاسم مستخدم بالفعل.');
    } finally {
      setEditLoading(false);
    }
  };

  if (loading) return <div>جاري التحميل...</div>;
  if (error) return <div style={{color:'red'}}>{error}</div>;

  return (
    <div style={{padding:'30px'}}>
      <h2 style={{textAlign:'center', marginBottom:'24px', fontWeight:'bold', fontSize:'2rem', letterSpacing:'1px'}}>جميع المستخدمين</h2>
      <div style={{overflowX:'auto', borderRadius:'12px', boxShadow:'0 2px 8px #eee', background:'#fff'}}>
        <table style={{width:'100%',borderCollapse:'separate', borderSpacing:0, minWidth:'700px'}}>
          <thead style={{position:'sticky', top:0, zIndex:2, background:'#f0f4f8'}}>
            <tr>
              <th style={{padding:'12px',borderBottom:'2px solid #e0e0e0'}}>اسم المستخدم</th>
              <th style={{padding:'12px',borderBottom:'2px solid #e0e0e0'}}>البريد الإلكتروني</th>
              <th style={{padding:'12px',borderBottom:'2px solid #e0e0e0'}}>الحالة</th>
              <th style={{padding:'12px',borderBottom:'2px solid #e0e0e0'}}>إجراءات</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user, idx) => (
              <tr key={user.id} style={{background: idx%2===0 ? '#fafbfc' : '#f5f7fa', transition:'background 0.2s'}}>
                {editId === user.id ? (
                  <>
                    <td style={{padding:'10px 8px',borderBottom:'1px solid #f0f0f0', textAlign:'center'}}>
                      <input value={editData.username} onChange={e=>setEditData(d=>({...d,username:e.target.value}))} style={{padding:6,borderRadius:5,border:'1px solid #ddd',width:'90%'}} />
                    </td>
                    <td style={{padding:'10px 8px',borderBottom:'1px solid #f0f0f0', textAlign:'center'}}>
                      <input value={editData.email} onChange={e=>setEditData(d=>({...d,email:e.target.value}))} style={{padding:6,borderRadius:5,border:'1px solid #ddd',width:'90%'}} />
                    </td>
                    <td style={{padding:'10px 8px',borderBottom:'1px solid #f0f0f0', textAlign:'center'}}>
                      <select value={editData.is_active ? '1' : '0'} onChange={e=>setEditData(d=>({...d,is_active:e.target.value==='1'}))} style={{padding:6,borderRadius:5,border:'1px solid #ddd'}}>
                        <option value="1">نشط</option>
                        <option value="0">غير نشط</option>
                      </select>
                    </td>
                    <td style={{padding:'10px 8px',borderBottom:'1px solid #f0f0f0', textAlign:'center'}}>
                      <button onClick={()=>handleEditSave(user.id)} disabled={editLoading} style={{background:'#22c55e',color:'#fff',border:'none',borderRadius:6,padding:'6px 14px',fontWeight:600,marginRight:6,cursor:'pointer'}}>حفظ</button>
                      <button onClick={cancelEdit} style={{background:'#eee',color:'#222',border:'none',borderRadius:6,padding:'6px 14px',fontWeight:600,cursor:'pointer'}}>إلغاء</button>
                    </td>
                  </>
                ) : (
                  <>
                    <td style={{padding:'10px 8px',borderBottom:'1px solid #f0f0f0', textAlign:'center'}}>{user.username}</td>
                    <td style={{padding:'10px 8px',borderBottom:'1px solid #f0f0f0', textAlign:'center'}}>{user.email}</td>
                    <td style={{padding:'10px 8px',borderBottom:'1px solid #f0f0f0', textAlign:'center'}}>
                      {user.is_active ? <span title="نشط" style={{color:'#22c55e'}}>●</span> : <span title="غير نشط" style={{color:'#e53e3e'}}>●</span>}
                      <span style={{marginRight:'6px'}}>{user.is_active ? 'نشط' : 'غير نشط'}</span>
                    </td>
                    <td style={{padding:'10px 8px',borderBottom:'1px solid #f0f0f0', textAlign:'center'}}>
                      <button onClick={() => startEdit(user)} style={{marginRight:'8px', background:'#4f8cff', color:'#fff', border:'none', borderRadius:'4px', padding:'6px 12px', cursor:'pointer'}}>تعديل</button>
                      <button onClick={() => handleDelete(user.id)} style={{background:'#e53e3e', color:'#fff', border:'none', borderRadius:'4px', padding:'6px 12px', cursor:'pointer'}}>حذف</button>
                    </td>
                  </>
                )}
              </tr>
            ))}
            {editMsg && <tr><td colSpan={4} style={{color:editMsg.includes('نجاح')?'#22c55e':'#e11d48',fontWeight:700,textAlign:'center',padding:'8px'}}>{editMsg}</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default UsersList; 