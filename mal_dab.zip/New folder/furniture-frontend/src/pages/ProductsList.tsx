import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { productsAPI } from '../services/api';
import { Product } from '../services/api';
import './AdminDashboard.css';

const ProductsList: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const location = useLocation();

  useEffect(() => {
    fetchProducts();
    // eslint-disable-next-line
  }, [location.search]);

  const fetchProducts = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams(location.search);
      const category = params.get('category');
      let response;
      if (category) {
        response = await productsAPI.filterByCategory(category);
      } else {
        response = await productsAPI.getAll();
      }
      setProducts(response.data);
    } catch (err: any) {
      setError('فشل في تحميل المنتجات');
      console.error('Error fetching products:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteProduct = async (productId: number) => {
    if (window.confirm('هل أنت متأكد من حذف هذا المنتج؟')) {
      try {
        await productsAPI.delete(productId);
        setProducts(products.filter(p => p.id !== productId));
        alert('تم حذف المنتج بنجاح');
      } catch (err: any) {
        alert('فشل في حذف المنتج');
        console.error('Error deleting product:', err);
      }
    }
  };

  const handleOrder = async (productId: number) => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://127.0.0.1:8000/api/v1/orders/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'Authorization': `Bearer ${token}` } : {})
        },
        body: JSON.stringify({
          product_id: productId,
          quantity: 1
        }),
      });
      if (response.ok) {
        alert('تم إنشاء الطلب بنجاح!');
      } else {
        alert('فشل في إنشاء الطلب');
      }
    } catch (error) {
      alert('حدث خطأ أثناء إنشاء الطلب');
    }
  };

  const formatPrice = (price: number) => {
    return `$${price.toFixed(2)}`;
  };

  if (loading) {
    return (
      <div className="admin-dashboard-bg" style={{display:'flex',alignItems:'center',justifyContent:'center',minHeight:'100vh'}}>
        <div className="admin-card" style={{fontSize:'1.2rem'}}>جاري التحميل...</div>
      </div>
    );
  }

  return (
    <div className="admin-dashboard-bg">
      {/* Header */}
      <header className="admin-header">
        <div className="admin-header-content">
          <div>
            <h1 className="admin-header-title">إدارة المنتجات</h1>
            <p className="admin-header-welcome">عرض وتعديل وحذف المنتجات</p>
          </div>
          <Link to="/add-product" className="admin-logout-btn" style={{textDecoration:'none',color:'white'}}>
            إضافة منتج جديد
          </Link>
        </div>
      </header>

      {/* Navigation */}
      <nav className="admin-nav">
        <div className="admin-nav-content">
          <Link to="/admin/dashboard" className="admin-nav-link">Dashboard</Link>
          <Link to="/admin/products" className="admin-nav-link active">المنتجات</Link>
          <Link to="/admin/orders" className="admin-nav-link">الطلبات</Link>
          <Link to="/admin/users" className="admin-nav-link">المستخدمين</Link>
        </div>
      </nav>

      {/* Main Content */}
      <main className="admin-main">
        {error && (
          <div style={{background:'#fee',color:'#c33',padding:'12px',borderRadius:'8px',marginBottom:'20px'}}>
            {error}
          </div>
        )}

        <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:'20px'}}>
          <h2 style={{margin:0}}>جميع المنتجات ({products.length})</h2>
          <Link to="/add-product" style={{
            background:'#4f8cff',
            color:'white',
            padding:'10px 20px',
            borderRadius:'6px',
            textDecoration:'none',
            fontSize:'14px'
          }}>
            ➕ إضافة منتج جديد
          </Link>
        </div>

        {products.length === 0 ? (
          <div style={{
            background:'white',
            padding:'40px',
            borderRadius:'8px',
            textAlign:'center',
            color:'#666'
          }}>
            <div style={{fontSize:'3rem',marginBottom:'10px'}}>📦</div>
            <h3>لا توجد منتجات</h3>
            <p>ابدأ بإضافة منتج جديد</p>
            <Link to="/add-product" style={{
              background:'#4f8cff',
              color:'white',
              padding:'10px 20px',
              borderRadius:'6px',
              textDecoration:'none',
              display:'inline-block',
              marginTop:'10px'
            }}>
              إضافة منتج جديد
            </Link>
          </div>
        ) : (
          <div style={{display:'grid',gap:'20px',gridTemplateColumns:'repeat(auto-fill, minmax(300px, 1fr))'}}>
            {products.map((product) => (
              <div key={product.id} style={{
                background:'white',
                borderRadius:'8px',
                padding:'20px',
                boxShadow:'0 2px 4px rgba(0,0,0,0.1)',
                border:'1px solid #eee'
              }}>
                {/* Product Image */}
                <div style={{
                  width:'100%',
                  height:'200px',
                  background:'#f5f5f5',
                  borderRadius:'6px',
                  marginBottom:'15px',
                  display:'flex',
                  alignItems:'center',
                  justifyContent:'center',
                  overflow:'hidden'
                }}>
                  {product.image_url ? (
                    (() => {
                      let imageUrl = 'https://via.placeholder.com/220x160?text=No+Image';
                      if (product.image_url) {
                        if (product.image_url.startsWith('http')) {
                          imageUrl = product.image_url;
                        } else if (product.image_url.startsWith('/')) {
                          imageUrl = `http://127.0.0.1:8000${product.image_url}`;
                        } else {
                          imageUrl = `http://127.0.0.1:8000/api/v1/images/products/${product.id}/${product.image_url}`;
                        }
                      }
                      return (
                        <img 
                          src={imageUrl} 
                          alt={product.name}
                          style={{
                            width:'100%',
                            height:'100%',
                            objectFit:'cover'
                          }}
                        />
                      );
                    })()
                  ) : (
                    <div style={{color:'#999',fontSize:'3rem'}}>🖼️</div>
                  )}
                </div>

                {/* Product Info */}
                <h3 style={{margin:'0 0 10px 0',fontSize:'1.2rem',color:'#333'}}>
                  {product.name}
                </h3>
                
                <p style={{
                  margin:'0 0 15px 0',
                  color:'#666',
                  fontSize:'0.9rem',
                  lineHeight:'1.4',
                  display:'-webkit-box',
                  WebkitLineClamp:2,
                  WebkitBoxOrient:'vertical',
                  overflow:'hidden'
                }}>
                  {product.description || 'لا يوجد وصف'}
                </p>

                {/* Price and Discount */}
                <div style={{marginBottom:'15px'}}>
                  {product.has_discount ? (
                    <div>
                      <span style={{
                        textDecoration:'line-through',
                        color:'#999',
                        fontSize:'0.9rem'
                      }}>
                        {formatPrice(product.price)}
                      </span>
                      <span style={{
                        color:'#e53e3e',
                        fontWeight:'bold',
                        marginLeft:'8px',
                        fontSize:'1.1rem'
                      }}>
                        {formatPrice(product.discounted_price)}
                      </span>
                      <span style={{
                        background:'#e53e3e',
                        color:'white',
                        padding:'2px 6px',
                        borderRadius:'4px',
                        fontSize:'0.8rem',
                        marginLeft:'8px'
                      }}>
                        -{product.discount_percent}%
                      </span>
                    </div>
                  ) : (
                    <span style={{
                      color:'#333',
                      fontWeight:'bold',
                      fontSize:'1.1rem'
                    }}>
                      {formatPrice(product.price)}
                    </span>
                  )}
                </div>

                {/* Product Details */}
                <div style={{
                  display:'grid',
                  gridTemplateColumns:'1fr 1fr',
                  gap:'10px',
                  marginBottom:'15px',
                  fontSize:'0.85rem',
                  color:'#666'
                }}>
                  <div>
                    <strong>الفئة:</strong> {product.category || 'غير محدد'}
                  </div>
                  <div>
                    <strong>المخزون:</strong> {product.stock_quantity}
                  </div>
                  <div>
                    <strong>تاريخ الإنشاء:</strong> {new Date(product.created_at).toLocaleDateString('ar-SA')}
                  </div>
                  <div>
                    <strong>آخر تحديث:</strong> {product.updated_at ? new Date(product.updated_at).toLocaleDateString('ar-SA') : 'غير محدد'}
                  </div>
                </div>

                {/* Actions */}
                <div style={{
                  display:'flex',
                  gap:'10px',
                  justifyContent:'flex-end'
                }}>
                  <button
                    onClick={() => handleDeleteProduct(product.id)}
                    style={{
                      background:'#e53e3e',
                      color:'white',
                      border:'none',
                      padding:'8px 12px',
                      borderRadius:'4px',
                      cursor:'pointer',
                      fontSize:'0.85rem'
                    }}
                  >
                    حذف
                  </button>
                  <Link
                    to={`/edit-product/${product.id}`}
                    style={{
                      background:'#4f8cff',
                      color:'white',
                      border:'none',
                      padding:'8px 12px',
                      borderRadius:'4px',
                      cursor:'pointer',
                      fontSize:'0.85rem',
                      textDecoration:'none',
                      display:'inline-block'
                    }}
                  >
                    تعديل
                  </Link>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
};

export default ProductsList; 