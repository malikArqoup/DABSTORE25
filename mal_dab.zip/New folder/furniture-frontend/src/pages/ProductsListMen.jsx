import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { productsAPI } from '../services/api';
import './AdminDashboard.css';

const ProductsListMen = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      setLoading(true);
      const response = await productsAPI.filterByCategory('رجالي');
      setProducts(response.data);
    } catch (err) {
      setError('فشل في تحميل المنتجات');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteProduct = async (productId) => {
    if (window.confirm('هل أنت متأكد من حذف هذا المنتج؟')) {
      try {
        await productsAPI.delete(productId);
        setProducts(products.filter(p => p.id !== productId));
        alert('تم حذف المنتج بنجاح');
      } catch (err) {
        alert('فشل في حذف المنتج');
      }
    }
  };

  const formatPrice = (price) => `$${price.toFixed(2)}`;

  if (loading) {
    return (
      <div className="admin-dashboard-bg" style={{display:'flex',alignItems:'center',justifyContent:'center',minHeight:'100vh'}}>
        <div className="admin-card" style={{fontSize:'1.2rem'}}>جاري التحميل...</div>
      </div>
    );
  }

  return (
    <div className="admin-dashboard-bg">
      <header className="admin-header">
        <div className="admin-header-content">
          <div>
            <h1 className="admin-header-title">منتجات رجالي</h1>
            <p className="admin-header-welcome">عرض وتعديل وحذف المنتجات الرجالي فقط</p>
          </div>
          <Link to="/add-men-product" className="admin-logout-btn" style={{textDecoration:'none',color:'white'}}>
            إضافة منتج رجالي
          </Link>
        </div>
      </header>
      <nav className="admin-nav">
        <div className="admin-nav-content">
          <Link to="/admin/dashboard" className="admin-nav-link">Dashboard</Link>
          <Link to="/men-products" className="admin-nav-link active">منتجات رجالي</Link>
          <Link to="/admin/products" className="admin-nav-link">كل المنتجات</Link>
          <Link to="/women-products" className="admin-nav-link">منتجات نسائي</Link>
        </div>
      </nav>
      <main className="admin-main">
        {error && (
          <div style={{background:'#fee',color:'#c33',padding:'12px',borderRadius:'8px',marginBottom:'20px'}}>{error}</div>
        )}
        <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:'20px'}}>
          <h2 style={{margin:0}}>منتجات رجالي ({products.length})</h2>
          <Link to="/add-men-product" style={{background:'#4f8cff',color:'white',padding:'10px 20px',borderRadius:'6px',textDecoration:'none',fontSize:'14px'}}>
            ➕ إضافة منتج رجالي
          </Link>
        </div>
        {products.length === 0 ? (
          <div style={{background:'white',padding:'40px',borderRadius:'8px',textAlign:'center',color:'#666'}}>
            <div style={{fontSize:'3rem',marginBottom:'10px'}}>📦</div>
            <h3>لا توجد منتجات رجالي</h3>
            <p>ابدأ بإضافة منتج رجالي جديد</p>
            <Link to="/add-men-product" style={{background:'#4f8cff',color:'white',padding:'10px 20px',borderRadius:'6px',textDecoration:'none',display:'inline-block',marginTop:'10px'}}>
              إضافة منتج رجالي
            </Link>
          </div>
        ) : (
          <div style={{display:'grid',gap:'20px',gridTemplateColumns:'repeat(auto-fill, minmax(300px, 1fr))'}}>
            {products.map((product) => (
              <div key={product.id} style={{background:'white',borderRadius:'8px',padding:'20px',boxShadow:'0 2px 4px rgba(0,0,0,0.1)',border:'1px solid #eee'}}>
                <div style={{width:'100%',height:'200px',background:'#f5f5f5',borderRadius:'6px',marginBottom:'15px',display:'flex',alignItems:'center',justifyContent:'center',overflow:'hidden'}}>
                  {product.image_url ? (
                    (() => {
                      let imageUrl = 'https://via.placeholder.com/220x160?text=No+Image';
                      if (product.image_url) {
                        if (product.image_url.startsWith('http')) {
                          imageUrl = product.image_url;
                        } else if (product.image_url.startsWith('/')) {
                          imageUrl = `http://127.0.0.1:8000${product.image_url}`;
                        } else {
                          imageUrl = `http://127.0.0.1:8000/api/v1/images/products/${product.id}/${product.image_url}`;
                        }
                      }
                      return (
                        <img src={imageUrl} alt={product.name} style={{width:'100%',height:'100%',objectFit:'cover'}} />
                      );
                    })()
                  ) : null}
                </div>
                <h3 style={{margin:'0 0 10px 0'}}>{product.name}</h3>
                <div style={{color:'#888',marginBottom:'8px'}}>الفئة: {product.category}</div>
                <div style={{fontWeight:'bold',marginBottom:'8px'}}>{formatPrice(product.price)}</div>
                <div style={{display:'flex',gap:'8px'}}>
                  <Link to={`/edit-product/${product.id}`} style={{background:'#2563eb',color:'white',padding:'6px 14px',borderRadius:'4px',textDecoration:'none',fontSize:'13px'}}>تعديل</Link>
                  <button onClick={() => handleDeleteProduct(product.id)} style={{background:'#ef4444',color:'white',padding:'6px 14px',borderRadius:'4px',border:'none',fontSize:'13px',cursor:'pointer'}}>حذف</button>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
};

export default ProductsListMen; 