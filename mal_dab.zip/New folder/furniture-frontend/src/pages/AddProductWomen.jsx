import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import ProductForm from "../components/ProductForm";
import { addProduct } from "../services/api";

const AddProductWomen = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  // Handles form submission
  const handleAddProduct = async (formData) => {
    setLoading(true);
    setMessage("");
    setError("");
    try {
      const token = localStorage.getItem("token");
      await addProduct(formData, token);
      setMessage("تمت إضافة المنتج النسائي بنجاح!");
      setTimeout(() => navigate("/admin/products"), 1500);
    } catch (err) {
      setError("حدث خطأ أثناء إضافة المنتج.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <h2 style={{ textAlign: "center", margin: "32px 0 12px 0" }}>إضافة منتج نسائي</h2>
      <ProductForm
        initialValues={{ category: "نسائي" }}
        onSubmit={handleAddProduct}
        fixedCategory="نسائي"
        submitLabel="إضافة المنتج النسائي"
        loading={loading}
      />
      {message && <div style={{ color: "#1a7f37", textAlign: "center", marginTop: 16 }}>{message}</div>}
      {error && <div style={{ color: "#b00020", textAlign: "center", marginTop: 16 }}>{error}</div>}
    </div>
  );
};

export default AddProductWomen; 