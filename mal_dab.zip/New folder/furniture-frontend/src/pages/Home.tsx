import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { productsAPI, Product } from '../services/api';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import ProductsPublic from './ProductsPublic';
import Slider from 'react-slick';

const Home: React.FC = () => {
  const { user, logout } = useAuth();
  const [products, setProducts] = useState<Product[]>([]);
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [priceRange, setPriceRange] = useState({ min: '', max: '' });
  const [showDiscountsOnly, setShowDiscountsOnly] = useState(false);
  const location = useLocation();
  const [sliderImages, setSliderImages] = useState<{id:number, image_url:string}[]>([]);

  const categories = ['Sofa', 'Chair', 'Table', 'Bed', 'Cabinet', 'Lighting'];

  useEffect(() => {
    fetchProducts();
    fetchSliderImages();
  }, []);

  useEffect(() => {
    filterProducts();
  }, [products, searchTerm, selectedCategory, priceRange, showDiscountsOnly]);

  // تفعيل الفلتر تلقائياً إذا كان هناك باراميتر category في الرابط
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const categoryParam = params.get('category');
    if (categoryParam) {
      setSelectedCategory(categoryParam);
    }
  }, [location.search]);

  const fetchProducts = async () => {
    try {
      const response = await productsAPI.getAll();
      setProducts(response.data);
    } catch (error) {
      console.error('Failed to fetch products:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchSliderImages = async () => {
    try {
      const res = await fetch('http://localhost:8000/api/v1/slider-images/');
      const data = await res.json();
      setSliderImages(data);
    } catch (err) {
      setSliderImages([]);
    }
  };

  const filterProducts = () => {
    let filtered = [...products];

    // Search by name
    if (searchTerm) {
      filtered = filtered.filter(product =>
        product.name.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Filter by category
    if (selectedCategory) {
      filtered = filtered.filter(product =>
        product.category === selectedCategory
      );
    }

    // Filter by price range
    if (priceRange.min) {
      filtered = filtered.filter(product =>
        product.has_discount ? product.discounted_price >= parseFloat(priceRange.min) : product.price >= parseFloat(priceRange.min)
      );
    }
    if (priceRange.max) {
      filtered = filtered.filter(product =>
        product.has_discount ? product.discounted_price <= parseFloat(priceRange.max) : product.price <= parseFloat(priceRange.max)
      );
    }

    // Filter by discounts only
    if (showDiscountsOnly) {
      filtered = filtered.filter(product => product.has_discount);
    }

    setFilteredProducts(filtered);
  };

  const handleLogout = () => {
    logout();
  };

  // منطق السلة البسيط
  const addToCart = (product) => {
    let cart = JSON.parse(localStorage.getItem('cart') || '[]');
    const existing = cart.find(item => item.id === product.id);
    if (existing) {
      existing.quantity += 1;
    } else {
      cart.push({ ...product, quantity: 1 });
    }
    localStorage.setItem('cart', JSON.stringify(cart));
    alert('تمت إضافة المنتج إلى السلة!');
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-furniture-600"></div>
      </div>
    );
  }

  return (
    <div style={{ minHeight: '100vh', background: '#f5f7fa', padding: '0', fontFamily: 'Tajawal, Arial, sans-serif' }}>
      {/* Header */}
      <header style={{ background: '#fff', boxShadow: '0 2px 8px #eee', padding: '0 32px', marginBottom: 40 }}>
        <div style={{ maxWidth: 1200, margin: '0 auto', display: 'flex', justifyContent: 'space-between', alignItems: 'center', height: 80 }}>
          <div>
            <h1 style={{ fontSize: '2.2rem', fontWeight: 'bold', color: '#2563eb', margin: 0 }}>DAB STORE</h1>
            <p style={{ color: '#666', margin: 0 }}>اكتشف أجمل الساعات والإكسسوارات مع DAB STORE</p>
          </div>
          <div style={{ display: 'flex', gap: 16, alignItems: 'center' }}>
            {user ? (
              <>
                <span style={{ color: '#333', fontWeight: 500 }}>مرحباً، {user.username}</span>
                <Link to="/my-orders" style={{ color: '#2563eb', textDecoration: 'none', fontWeight: 600 }}>طلباتي</Link>
                <button onClick={handleLogout} style={{ background: '#eee', color: '#333', border: 'none', borderRadius: 6, padding: '8px 18px', cursor: 'pointer', fontWeight: 500 }}>تسجيل الخروج</button>
              </>
            ) : (
              <>
                <Link to="/login" style={{ background: '#2563eb', color: '#fff', borderRadius: 6, padding: '8px 18px', textDecoration: 'none', fontWeight: 600 }}>تسجيل الدخول</Link>
                <Link to="/register" style={{ background: '#eee', color: '#2563eb', borderRadius: 6, padding: '8px 18px', textDecoration: 'none', fontWeight: 600 }}>إنشاء حساب</Link>
              </>
            )}
          </div>
        </div>
      </header>

      {/* Hero Section with Background */}
      <div style={{
        width: '100%',
        minHeight: '260px',
        background: `linear-gradient(rgba(245,247,250,0.55), rgba(245,247,250,0.55)), url('https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1200&q=80') center/cover no-repeat`,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '56px 0 40px 0',
        marginBottom: 48,
        borderRadius: '0 0 18px 18px'
      }}>
        <div style={{maxWidth:'900px', width:'100%', display:'flex', flexDirection:'column', alignItems:'center', textAlign:'center', gap:'20px'}}>
          <h1 style={{fontSize:'2.5rem', fontWeight:'bold', color:'#22223b', marginBottom:'18px'}}>جودة مضمونة، تصميم عصري</h1>
          <p style={{fontSize:'1.2rem', color:'#444', marginBottom:'18px'}}>اكتشف أجمل الساعات والإكسسوارات مع DAB STORE. ضمان استرجاع سهل، أسعار منافسة، وتوصيل سريع.</p>
        </div>
      </div>

      {/* Category Cards Section */}
      <div style={{ display: 'flex', justifyContent: 'center', gap: 56, margin: '56px auto 56px auto', maxWidth: 1000 }}>
        {/* Card: ساعات نسائية */}
        <div style={{ background: '#fff', borderRadius: 20, boxShadow: '0 4px 24px rgba(37,99,235,0.08)', width: 400, minHeight: 280, display: 'flex', flexDirection: 'column', alignItems: 'center', padding: 32, transition: 'box-shadow 0.2s', position: 'relative' }}>
          <img src="https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=400&q=80" alt="ساعات نسائية" style={{ width: 160, height: 160, borderRadius: 16, objectFit: 'cover', marginBottom: 24, boxShadow: '0 2px 8px #eee' }} />
          <h3 style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#222', marginBottom: 12, textAlign: 'center' }}>ساعات نسائية</h3>
          <Link to="/women-products" style={{ marginTop: 14, background: '#2563eb', color: '#fff', borderRadius: 10, padding: '12px 32px', textDecoration: 'none', fontWeight: 600, fontSize: 17, boxShadow: '0 1px 4px #e0eaff', transition: 'background 0.2s' }}>اكتشف المزيد</Link>
        </div>
        {/* Card: ساعات رجالية */}
        <div style={{ background: '#fff', borderRadius: 20, boxShadow: '0 4px 24px rgba(37,99,235,0.08)', width: 400, minHeight: 280, display: 'flex', flexDirection: 'column', alignItems: 'center', padding: 32, transition: 'box-shadow 0.2s', position: 'relative' }}>
          <img src="https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=400&q=80" alt="ساعات رجالية" style={{ width: 160, height: 160, borderRadius: 16, objectFit: 'cover', marginBottom: 24, boxShadow: '0 2px 8px #eee' }} />
          <h3 style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#222', marginBottom: 12, textAlign: 'center' }}>ساعات رجالية</h3>
          <Link to="/men-products-public" style={{ marginTop: 14, background: '#2563eb', color: '#fff', borderRadius: 10, padding: '12px 32px', textDecoration: 'none', fontWeight: 600, fontSize: 17, boxShadow: '0 1px 4px #e0eaff', transition: 'background 0.2s' }}>اكتشف المزيد</Link>
        </div>
      </div>
      {/* زيادة المسافة بعد الكاردات */}
      <div style={{ height: 40 }} />

      {/* Category Filter Buttons */}
      <div style={{ display: 'flex', gap: 12, justifyContent: 'center', marginBottom: 36 }}>
        <button className="main-btn" onClick={() => setSelectedCategory('نسائي')}>منتجات نسائي</button>
        <button className="main-btn" onClick={() => setSelectedCategory('رجالي')}>منتجات رجالي</button>
        <button className="main-btn" onClick={() => setSelectedCategory('')}>كل المنتجات</button>
      </div>

      {/* Filters */}
      <div style={{ background: '#fff', borderBottom: '1px solid #eee', marginBottom: 48, marginTop: 16 }}>
        <div style={{ maxWidth: 1200, margin: '0 auto', padding: '32px 16px', display: 'flex', flexWrap: 'wrap', gap: 20, alignItems: 'center' }}>
          <input type="text" placeholder="بحث بالاسم..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} style={{ flex: '1 1 180px', padding: 10, borderRadius: 6, border: '1px solid #ddd', fontSize: 15 }} />
          <select value={selectedCategory} onChange={e => setSelectedCategory(e.target.value)} style={{ flex: '1 1 140px', padding: 10, borderRadius: 6, border: '1px solid #ddd', fontSize: 15 }}>
            <option value="">كل الفئات</option>
            {categories.map(category => <option key={category} value={category}>{category}</option>)}
          </select>
          <input type="number" placeholder="أقل سعر" value={priceRange.min} onChange={e => setPriceRange({ ...priceRange, min: e.target.value })} style={{ flex: '1 1 100px', padding: 10, borderRadius: 6, border: '1px solid #ddd', fontSize: 15 }} />
          <input type="number" placeholder="أعلى سعر" value={priceRange.max} onChange={e => setPriceRange({ ...priceRange, max: e.target.value })} style={{ flex: '1 1 100px', padding: 10, borderRadius: 6, border: '1px solid #ddd', fontSize: 15 }} />
          <label style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 15, color: '#444' }}>
            <input type="checkbox" checked={showDiscountsOnly} onChange={e => setShowDiscountsOnly(e.target.checked)} style={{ accentColor: '#2563eb' }} /> خصومات فقط
          </label>
          <button className="main-btn" onClick={() => { setSearchTerm(''); setSelectedCategory(''); setPriceRange({ min: '', max: '' }); setShowDiscountsOnly(false); }}>مسح الفلاتر</button>
        </div>
      </div>

      {/* Products Grid */}
      <main style={{ maxWidth: 1200, margin: '0 auto', padding: '0 16px 64px 16px' }}>
        <div style={{ marginBottom: 32 }}>
          <h2 style={{ fontSize: '1.7rem', fontWeight: 'bold', color: '#222', margin: 0 }}>جميع المنتجات ({filteredProducts.length})</h2>
        </div>
        {filteredProducts.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '60px 0', color: '#888' }}>
            <div style={{ fontSize: '3rem', marginBottom: 10 }}>📦</div>
            <h3 style={{ fontWeight: 600 }}>لا توجد منتجات</h3>
            <p>جرّب تغيير الفلاتر أو البحث باسم آخر.</p>
          </div>
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: 28 }}>
            {filteredProducts.map((product) => (
              <div key={product.id} style={{ background: '#fff', borderRadius: 14, boxShadow: '0 2px 12px #eee', padding: 18, display: 'flex', flexDirection: 'column', alignItems: 'center', border: '1px solid #f0f0f0', transition: 'box-shadow 0.2s', minHeight: 380 }}>
                <div style={{ width: '220px', height: '160px', overflow: 'hidden', borderRadius: '10px', background: '#f5f5f5', marginBottom: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  {product.image_url ? (
                    (() => {
                      let imageUrl = 'https://via.placeholder.com/220x160?text=No+Image';
                      if (product.image_url) {
                        if (product.image_url.startsWith('http')) {
                          imageUrl = product.image_url;
                        } else if (product.image_url.startsWith('/')) {
                          imageUrl = `http://127.0.0.1:8000${product.image_url}`;
                        } else {
                          imageUrl = `http://127.0.0.1:8000/api/v1/images/products/${product.id}/${product.image_url}`;
                        }
                      }
                      return (
                        <img src={imageUrl} alt={product.name} style={{ width: '100%', height: '100%', objectFit: 'cover', borderRadius: '10px' }} />
                      );
                    })()
                  ) : (
                    <div style={{ color: '#999', fontSize: '2.2rem' }}>🖼️</div>
                  )}
                </div>
                <h3 style={{ fontSize: '1.1rem', fontWeight: 'bold', color: '#222', marginBottom: 8, textAlign: 'center' }}>{product.name}</h3>
                <div style={{ color: '#888', fontSize: 15, marginBottom: 8 }}>{product.category}</div>
                <div style={{ color: '#555', fontSize: 14, marginBottom: 10, textAlign: 'center', minHeight: 36, lineHeight: 1.5 }}>{product.description}</div>
                <div style={{ color: '#2563eb', fontWeight: 'bold', fontSize: '1.1rem', marginBottom: 8 }}>{product.has_discount ? `${product.discounted_price} شيقل` : `${product.price} شيقل`}
                  {product.has_discount && <span style={{ color: '#e11d48', fontSize: 13, marginRight: 8, textDecoration: 'line-through' }}>{product.price} شيقل</span>}
                  {product.has_discount && <span style={{ background: '#fee2e2', color: '#e11d48', borderRadius: 4, padding: '2px 8px', fontSize: 12, marginRight: 8 }}>خصم {product.discount_percent}%</span>}
                </div>
                <div style={{ color: '#888', fontSize: 13, marginBottom: 10 }}>المخزون: {product.stock_quantity}</div>
                <div style={{ display: 'flex', gap: 8, width: '100%' }}>
                  <Link to={`/product/${product.id}`} style={{ flex: 1, background: '#2563eb', color: '#fff', borderRadius: 6, padding: '8px 0', textAlign: 'center', textDecoration: 'none', fontWeight: 600, fontSize: 15 }}>تفاصيل</Link>
                  {user && <button style={{ flex: 1, background: '#22c55e', color: '#fff', border: 'none', borderRadius: 6, padding: '8px 0', fontWeight: 600, fontSize: 15, cursor: 'pointer' }} onClick={() => addToCart(product)}>أضف للسلة</button>}
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      {/* زر تصفح المنتجات - هذا الزر يوجه المستخدم إلى صفحة جميع المنتجات العامة (products-public) */}
      <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 80 }}>
        <Link
          to="/products-public"
          style={{
            background: 'linear-gradient(90deg, #2563eb 0%, #1746a0 100%)',
            color: '#fff',
            borderRadius: '14px',
            padding: '16px 48px',
            fontWeight: 800,
            fontSize: '1.25rem',
            boxShadow: '0 4px 24px #2563eb33',
            textDecoration: 'none',
            letterSpacing: 1,
            textAlign: 'center',
            display: 'inline-flex',
            alignItems: 'center',
            gap: 12,
            border: 'none',
            cursor: 'pointer',
            transition: 'all 0.22s cubic-bezier(.4,2,.3,1)',
            margin: '0 auto'
          }}
          onMouseOver={e => {
            e.currentTarget.style.background = 'linear-gradient(90deg, #1746a0 0%, #2563eb 100%)';
            e.currentTarget.style.transform = 'scale(1.06)';
            e.currentTarget.style.boxShadow = '0 8px 32px #2563eb33';
          }}
          onMouseOut={e => {
            e.currentTarget.style.background = 'linear-gradient(90deg, #2563eb 0%, #1746a0 100%)';
            e.currentTarget.style.transform = 'scale(1)';
            e.currentTarget.style.boxShadow = '0 4px 24px #2563eb33';
          }}
        >
          تصفح المنتجات
          <span style={{display:'inline-flex',alignItems:'center',marginRight:4}}>
            <svg width="24" height="24" fill="none" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" viewBox="0 0 24 24"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
          </span>
        </Link>
      </div>
    </div>
  );
};

export default Home; 