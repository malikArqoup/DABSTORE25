import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { ordersAPI, authAPI } from '../services/api';
import './AdminDashboard.css';

interface DashboardStats {
  total_orders: number;
  pending_orders: number;
  completed_orders: number;
  cancelled_orders: number;
  total_revenue: number;
  average_order_value: number;
}

interface Admin {
  id: number;
  username: string;
  email: string;
  is_active: boolean;
}

const AdminDashboard: React.FC = () => {
  const { user, logout } = useAuth();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [newAdmin, setNewAdmin] = useState({ username: '', email: '', password: '' });
  const [adminMsg, setAdminMsg] = useState('');
  const [adminLoading, setAdminLoading] = useState(false);
  const [admins, setAdmins] = useState<Admin[]>([]);
  const [adminsLoading, setAdminsLoading] = useState(true);
  const [editId, setEditId] = useState<number|null>(null);
  const [editData, setEditData] = useState<{username:string,email:string,is_active:boolean}>({username:'',email:'',is_active:true});
  const [editMsg, setEditMsg] = useState('');
  const [editLoading, setEditLoading] = useState(false);
  const [deleteLoadingId, setDeleteLoadingId] = useState<number|null>(null);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const response = await ordersAPI.getStatistics();
        setStats(response.data);
      } catch (error) {
        console.error('Failed to fetch statistics:', error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchStats();
    // تحديث الإحصائيات عند حدوث أي تغيير في الطلبات
    const handleOrdersUpdated = () => {
      setIsLoading(true);
      fetchStats();
    };
    window.addEventListener('orders-updated', handleOrdersUpdated);
    return () => {
      window.removeEventListener('orders-updated', handleOrdersUpdated);
    };
  }, []);

  useEffect(() => {
    // جلب جميع الأدمنات
    const fetchAdmins = async () => {
      setAdminsLoading(true);
      try {
        const res = await authAPI.getAllAdmins();
        setAdmins(res.data);
      } catch {
        setAdmins([]);
      } finally {
        setAdminsLoading(false);
      }
    };
    fetchAdmins();
  }, []);

  const handleLogout = () => {
    logout();
  };

  const handleAddAdmin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAdminMsg('');
    setAdminLoading(true);
    try {
      await authAPI.registerAdmin(newAdmin);
      setAdminMsg('تم إنشاء حساب الأدمن بنجاح!');
      setNewAdmin({ username: '', email: '', password: '' });
    } catch (err: any) {
      setAdminMsg('فشل في إنشاء حساب الأدمن. ربما الاسم أو الإيميل مستخدم بالفعل.');
    } finally {
      setAdminLoading(false);
    }
  };

  const refreshAdmins = async () => {
    setAdminsLoading(true);
    try {
      const res = await authAPI.getAllAdmins();
      setAdmins(res.data);
    } catch {
      setAdmins([]);
    } finally {
      setAdminsLoading(false);
    }
  };

  const startEdit = (admin: Admin) => {
    setEditId(admin.id);
    setEditData({username: admin.username, email: admin.email, is_active: admin.is_active});
    setEditMsg('');
  };
  const cancelEdit = () => {
    setEditId(null);
    setEditMsg('');
  };
  const handleEditSave = async (adminId: number) => {
    setEditLoading(true);
    setEditMsg('');
    try {
      await authAPI.updateAdmin(adminId, editData);
      setEditMsg('تم التعديل بنجاح!');
      setEditId(null);
      refreshAdmins();
    } catch {
      setEditMsg('فشل في التعديل. ربما الإيميل أو الاسم مستخدم بالفعل.');
    } finally {
      setEditLoading(false);
    }
  };
  const handleDelete = async (adminId: number) => {
    if (!window.confirm('هل أنت متأكد من حذف هذا الأدمن؟')) return;
    setDeleteLoadingId(adminId);
    try {
      await authAPI.deleteAdmin(adminId);
      refreshAdmins();
    } catch {
      alert('فشل في حذف الأدمن');
    } finally {
      setDeleteLoadingId(null);
    }
  };

  if (isLoading) {
    return (
      <div className="admin-dashboard-bg" style={{display:'flex',alignItems:'center',justifyContent:'center',minHeight:'100vh'}}>
        <div className="admin-card" style={{fontSize:'1.2rem'}}>Loading...</div>
      </div>
    );
  }

  return (
    <div className="admin-dashboard-bg">
      {/* Header */}
      <header className="admin-header">
        <div className="admin-header-content">
          <div>
            <h1 className="admin-header-title">Admin Dashboard</h1>
            <p className="admin-header-welcome">Welcome back, {user?.username}</p>
          </div>
          <button onClick={handleLogout} className="admin-logout-btn">Logout</button>
        </div>
      </header>

      {/* Navigation */}
      <nav className="admin-nav">
        <div className="admin-nav-content">
          <Link to="/admin/dashboard" className="admin-nav-link active">Dashboard</Link>
          <Link to="/admin/products" className="admin-nav-link">Products</Link>
          <Link to="/admin/orders" className="admin-nav-link">Orders</Link>
          <Link to="/admin/users" className="admin-nav-link">Users</Link>
        </div>
      </nav>

      {/* Main Content */}
      <main className="admin-main">
        {/* Statistics Cards */}
        <div className="admin-cards">
          <div className="admin-card">
            <div className="admin-card-icon" style={{background:'#4f8cff'}}>
              <svg className="w-5 h-5" fill="none" stroke="white" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" /></svg>
            </div>
            <div className="admin-card-info">
              <div className="admin-card-title">Total Orders</div>
              <div className="admin-card-value">{stats?.total_orders || 0}</div>
            </div>
          </div>
          <div className="admin-card">
            <div className="admin-card-icon" style={{background:'#facc15'}}>
              <svg className="w-5 h-5" fill="none" stroke="white" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
            </div>
            <div className="admin-card-info">
              <div className="admin-card-title">Pending Orders</div>
              <div className="admin-card-value">{stats?.pending_orders || 0}</div>
            </div>
          </div>
          <div className="admin-card">
            <div className="admin-card-icon" style={{background:'#22c55e'}}>
              <svg className="w-5 h-5" fill="none" stroke="white" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
            </div>
            <div className="admin-card-info">
              <div className="admin-card-title">Completed Orders</div>
              <div className="admin-card-value">{stats?.completed_orders || 0}</div>
            </div>
          </div>
          <div className="admin-card">
            <div className="admin-card-icon" style={{background:'#ef4444'}}>
              <svg className="w-5 h-5" fill="none" stroke="white" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
            </div>
            <div className="admin-card-info">
              <div className="admin-card-title">Cancelled Orders</div>
              <div className="admin-card-value">{stats?.cancelled_orders || 0}</div>
            </div>
          </div>
        </div>

        {/* Revenue Cards */}
        <div className="admin-revenue-cards">
          <div className="admin-revenue-card">
            <div className="admin-revenue-title">Total Revenue</div>
            <div className="admin-revenue-value">${stats?.total_revenue?.toFixed(2) || '0.00'}</div>
          </div>
          <div className="admin-revenue-card">
            <div className="admin-revenue-title">Average Order Value</div>
            <div className="admin-revenue-value blue">${stats?.average_order_value?.toFixed(2) || '0.00'}</div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="admin-quick-actions">
          <div className="admin-quick-actions-title">Quick Actions</div>
          <div className="admin-quick-actions-grid">
            <Link to="/admin/products" className="admin-quick-action-link">
              <span style={{fontSize:'1.5rem'}}>🛒</span>
              <span>كل المنتجات</span>
            </Link>
            <Link to="/admin/men-products" className="admin-quick-action-link">
              <span style={{fontSize:'1.5rem'}}>♂️</span>
              <span>منتجات رجالي</span>
            </Link>
            <Link to="/admin/women-products" className="admin-quick-action-link">
              <span style={{fontSize:'1.5rem'}}>♀️</span>
              <span>منتجات نسائي</span>
            </Link>
            <Link to="/add-product" className="admin-quick-action-link">
              <span style={{fontSize:'1.5rem'}}>➕</span>
              <span>إضافة منتج</span>
            </Link>
            <Link to="/add-women-product" className="admin-quick-action-link">
              <span style={{fontSize:'1.5rem'}}>➕</span>
              <span>إضافة منتج نسائي</span>
            </Link>
            <Link to="/add-men-product" className="admin-quick-action-link">
              <span style={{fontSize:'1.5rem'}}>➕</span>
              <span>إضافة منتج رجالي</span>
            </Link>
            <Link to="/admin/orders" className="admin-quick-action-link">
              <span style={{fontSize:'1.5rem'}}>📦</span>
              <span>View Orders</span>
            </Link>
            <Link to="/admin/users" className="admin-quick-action-link">
              <span style={{fontSize:'1.5rem'}}>👤</span>
              <span>Manage Users</span>
            </Link>
            <Link to="/admin/slider" className="admin-quick-action-link">
              <span style={{fontSize:'1.5rem'}}>🖼️</span>
              <span>إدارة السلايدر</span>
            </Link>
          </div>
        </div>
      </main>
      {/* نموذج إضافة أدمن جديد */}
      <div style={{maxWidth:400,margin:'32px auto 0 auto',background:'#f9fafb',borderRadius:12,boxShadow:'0 2px 12px #e0eaff',padding:'24px 18px'}}>
        <h3 style={{textAlign:'center',color:'#2563eb',marginBottom:16}}>إضافة أدمن جديد</h3>
        <form onSubmit={handleAddAdmin} style={{display:'flex',flexDirection:'column',gap:10}}>
          <input type="text" placeholder="اسم المستخدم" value={newAdmin.username} onChange={e=>setNewAdmin(a=>({...a,username:e.target.value}))} required style={{padding:10,borderRadius:6,border:'1px solid #ddd',fontSize:'1rem'}} />
          <input type="email" placeholder="الإيميل" value={newAdmin.email} onChange={e=>setNewAdmin(a=>({...a,email:e.target.value}))} required style={{padding:10,borderRadius:6,border:'1px solid #ddd',fontSize:'1rem'}} />
          <input type="password" placeholder="كلمة المرور" value={newAdmin.password} onChange={e=>setNewAdmin(a=>({...a,password:e.target.value}))} required style={{padding:10,borderRadius:6,border:'1px solid #ddd',fontSize:'1rem'}} />
          {adminMsg && <div style={{color:adminMsg.includes('نجاح')?'#22c55e':'#e11d48',fontWeight:700,textAlign:'center',margin:'8px 0'}}>{adminMsg}</div>}
          <button type="submit" disabled={adminLoading} style={{background:'#2563eb',color:'#fff',border:'none',borderRadius:8,padding:'12px 0',fontWeight:700,fontSize:'1.1rem',marginTop:8,cursor:adminLoading?'not-allowed':'pointer'}}>
            {adminLoading ? 'جاري الإضافة...' : 'إضافة أدمن'}
          </button>
        </form>
      </div>
      {/* جدول حسابات الأدمن */}
      <div style={{maxWidth:600,margin:'32px auto 0 auto',background:'#fff',borderRadius:12,boxShadow:'0 2px 12px #e0eaff',padding:'24px 18px'}}>
        <h3 style={{textAlign:'center',color:'#2563eb',marginBottom:16}}>حسابات الأدمن</h3>
        {adminsLoading ? (
          <div style={{textAlign:'center',color:'#888',padding:'18px'}}>جاري التحميل...</div>
        ) : admins.length === 0 ? (
          <div style={{textAlign:'center',color:'#e11d48',padding:'18px'}}>لا يوجد حسابات أدمن.</div>
        ) : (
          <table style={{width:'100%',borderCollapse:'collapse',fontSize:'1rem'}}>
            <thead>
              <tr style={{background:'#f3f6fa'}}>
                <th style={{padding:'10px'}}>اسم المستخدم</th>
                <th style={{padding:'10px'}}>الإيميل</th>
                <th style={{padding:'10px'}}>الحالة</th>
                <th style={{padding:'10px'}}>إجراءات</th>
              </tr>
            </thead>
            <tbody>
              {admins.map(a => (
                <tr key={a.id} style={{borderBottom:'1px solid #f0f0f0'}}>
                  {editId === a.id ? (
                    <>
                      <td style={{padding:'10px',textAlign:'center'}}>
                        <input value={editData.username} onChange={e=>setEditData(d=>({...d,username:e.target.value}))} style={{padding:6,borderRadius:5,border:'1px solid #ddd',width:'90%'}} />
                      </td>
                      <td style={{padding:'10px',textAlign:'center'}}>
                        <input value={editData.email} onChange={e=>setEditData(d=>({...d,email:e.target.value}))} style={{padding:6,borderRadius:5,border:'1px solid #ddd',width:'90%'}} />
                      </td>
                      <td style={{padding:'10px',textAlign:'center'}}>
                        <select value={editData.is_active ? '1' : '0'} onChange={e=>setEditData(d=>({...d,is_active:e.target.value==='1'}))} style={{padding:6,borderRadius:5,border:'1px solid #ddd'}}>
                          <option value="1">نشط</option>
                          <option value="0">غير نشط</option>
                        </select>
                      </td>
                      <td style={{padding:'10px',textAlign:'center'}}>
                        <button onClick={()=>handleEditSave(a.id)} disabled={editLoading} style={{background:'#22c55e',color:'#fff',border:'none',borderRadius:6,padding:'6px 14px',fontWeight:600,marginRight:6,cursor:'pointer'}}>حفظ</button>
                        <button onClick={cancelEdit} style={{background:'#eee',color:'#222',border:'none',borderRadius:6,padding:'6px 14px',fontWeight:600,cursor:'pointer'}}>إلغاء</button>
                      </td>
                    </>
                  ) : (
                    <>
                      <td style={{padding:'10px',textAlign:'center'}}>{a.username}</td>
                      <td style={{padding:'10px',textAlign:'center'}}>{a.email}</td>
                      <td style={{padding:'10px',textAlign:'center'}}>{a.is_active ? <span style={{color:'#22c55e',fontWeight:700}}>نشط</span> : <span style={{color:'#e11d48',fontWeight:700}}>غير نشط</span>}</td>
                      <td style={{padding:'10px',textAlign:'center'}}>
                        <button onClick={()=>startEdit(a)} style={{background:'#2563eb',color:'#fff',border:'none',borderRadius:6,padding:'6px 14px',fontWeight:600,marginRight:6,cursor:'pointer'}}>تعديل</button>
                        <button onClick={()=>handleDelete(a.id)} disabled={deleteLoadingId===a.id} style={{background:'#e11d48',color:'#fff',border:'none',borderRadius:6,padding:'6px 14px',fontWeight:600,cursor:deleteLoadingId===a.id?'not-allowed':'pointer'}}>{deleteLoadingId===a.id?'...':'حذف'}</button>
                      </td>
                    </>
                  )}
                </tr>
              ))}
              {editMsg && <tr><td colSpan={4} style={{color:editMsg.includes('نجاح')?'#22c55e':'#e11d48',fontWeight:700,textAlign:'center',padding:'8px'}}>{editMsg}</td></tr>}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};

export default AdminDashboard; 