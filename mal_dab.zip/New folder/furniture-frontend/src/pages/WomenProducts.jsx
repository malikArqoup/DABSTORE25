import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import './WomenProductsPublic.css';

const username = localStorage.getItem('username');

const WomenProducts = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState('');
  const [minPrice, setMinPrice] = useState('');
  const [maxPrice, setMaxPrice] = useState('');
  const [discountOnly, setDiscountOnly] = useState(false);

  useEffect(() => {
    fetch('http://127.0.0.1:8000/api/v1/products/filter/category?category=نسائي')
      .then((res) => {
        if (!res.ok) throw new Error('Network response was not ok');
        return res.json();
      })
      .then((data) => {
        setProducts(data);
        setLoading(false);
      })
      .catch((err) => {
        setError(err.message);
        setLoading(false);
      });
  }, []);

  const filtered = products.filter(product => {
    const matchesName = product.name.toLowerCase().includes(search.toLowerCase());
    const matchesMin = minPrice === '' || product.price >= parseFloat(minPrice);
    const matchesMax = maxPrice === '' || product.price <= parseFloat(maxPrice);
    const matchesDiscount = !discountOnly || product.has_discount;
    return matchesName && matchesMin && matchesMax && matchesDiscount;
  });

  return (
    <div className="wp-bg">
      {/* Navbar */}
      <nav className="wp-navbar-pro">
        <div className="wp-navbar-left">
          <Link to="/" className="wp-navlink">الرئيسية</Link>
          <Link to="/my-cart" className="wp-navlink">منتجاتي</Link>
        </div>
        <div className="wp-navbar-center">
          <span className="wp-logo">DAB STORE</span>
        </div>
        <div className="wp-navbar-right">
          {username ? (
            <span className="wp-username">Welcome, {username}</span>
          ) : (
            <span className="wp-username">مرحباً زائر</span>
          )}
        </div>
      </nav>
      {/* Filters */}
      <div className="wp-filters-pro">
        <input type="text" placeholder="بحث بالاسم..." value={search} onChange={e => setSearch(e.target.value)} className="wp-filter-input" />
        <input type="number" placeholder="أقل سعر" value={minPrice} onChange={e => setMinPrice(e.target.value)} className="wp-filter-input" />
        <input type="number" placeholder="أعلى سعر" value={maxPrice} onChange={e => setMaxPrice(e.target.value)} className="wp-filter-input" />
        <label className="wp-filter-label"><input type="checkbox" checked={discountOnly} onChange={e => setDiscountOnly(e.target.checked)} /> خصومات فقط</label>
      </div>
      {/* Products */}
      <h2 className="wp-title">منتجات نسائية</h2>
      {loading ? (
        <div className="wp-center">جاري التحميل...</div>
      ) : error ? (
        <div className="wp-center wp-error">حدث خطأ: {error}</div>
      ) : filtered.length === 0 ? (
        <div className="wp-center">لا توجد منتجات مطابقة.</div>
      ) : (
        <div className="wp-grid">
          {filtered.map(product => (
            <div className="wp-card" key={product.id}>
              <div className="wp-img-wrap">
                <img
                  src={product.image_url?.startsWith('http') ? product.image_url : `http://127.0.0.1:8000/api/v1/images/products/${product.id}/${product.image_url}`}
                  alt={product.name}
                  className="wp-img"
                  onError={e => e.target.src = 'https://via.placeholder.com/220x160?text=No+Image'}
                />
              </div>
              <div className="wp-info">
                <h3 className="wp-name">{product.name}</h3>
                <div className="wp-price">{product.price} ريال</div>
                <div className="wp-desc">{product.description}</div>
                {product.has_discount && <span className="wp-discount">خصم {product.discount_percent}%</span>}
                <div style={{display:'flex', gap:8, marginTop:10, width:'100%'}}>
                  <Link to={`/product/${product.id}`} className="wp-navlink" style={{flex:1, textAlign:'center', background:'#2563eb', color:'#fff'}}>تفاصيل</Link>
                  <button className="wp-navlink" style={{flex:1, textAlign:'center', background:'#22c55e', color:'#fff', border:'none', cursor:'pointer'}} onClick={()=>{
                    let cart = JSON.parse(localStorage.getItem('cart') || '[]');
                    const existing = cart.find(item => item.id === product.id);
                    if (existing) {
                      existing.quantity += 1;
                    } else {
                      cart.push({...product, quantity: 1});
                    }
                    localStorage.setItem('cart', JSON.stringify(cart));
                    alert('تمت إضافة المنتج إلى السلة!');
                  }}>أضف للسلة</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default WomenProducts; 