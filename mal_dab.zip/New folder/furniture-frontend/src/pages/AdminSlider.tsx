import React, { useEffect, useState } from "react";
import { sliderAPI } from "../services/api";
import { useNavigate } from 'react-router-dom';

const AdminSlider: React.FC = () => {
  const [images, setImages] = useState<{ id: number; image_url: string }[]>([]);
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const fetchImages = async () => {
    const res = await sliderAPI.getAll();
    setImages(res.data);
  };

  useEffect(() => {
    fetchImages();
  }, []);

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) return;
    setLoading(true);
    await sliderAPI.upload(file);
    setFile(null);
    await fetchImages();
    setLoading(false);
  };

  const handleDelete = async (id: number) => {
    if (!window.confirm("هل أنت متأكد من حذف الصورة؟")) return;
    await sliderAPI.delete(id);
    await fetchImages();
  };

  return (
    <div style={{ maxWidth: 600, margin: "40px auto", background: "#fff", borderRadius: 12, boxShadow: "0 2px 12px #eee", padding: 32 }}>
      <button onClick={()=>navigate(-1)} style={{background:'#eee',color:'#2563eb',border:'none',borderRadius:8,padding:'8px 22px',fontWeight:700,fontSize:'1.05rem',marginBottom:18,cursor:'pointer',marginRight:12}}>رجوع</button>
      <h2 style={{ fontSize: "1.5rem", fontWeight: "bold", color: "#2563eb", marginBottom: 24 }}>إدارة صور السلايدر</h2>
      <form onSubmit={handleUpload} style={{ marginBottom: 32 }}>
        <input
          type="file"
          accept="image/*"
          onChange={e => setFile(e.target.files?.[0] || null)}
          style={{ marginBottom: 12 }}
        />
        <button className="main-btn" type="submit" disabled={loading || !file}>
          {loading ? "جاري الرفع..." : "رفع صورة جديدة"}
        </button>
      </form>
      <div style={{ display: "flex", flexWrap: "wrap", gap: 16 }}>
        {images.map(img => (
          <div key={img.id} style={{ position: "relative", width: 180, height: 120, borderRadius: 8, overflow: "hidden", boxShadow: "0 2px 8px #e0eaff" }}>
            <img src={`http://localhost:8000${img.image_url}`} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
            <button
              className="main-btn"
              style={{ position: "absolute", top: 8, right: 8, padding: "4px 10px", fontSize: 13, borderRadius: 6, background: "#e53e3e" }}
              onClick={() => handleDelete(img.id)}
            >
              حذف
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AdminSlider; 