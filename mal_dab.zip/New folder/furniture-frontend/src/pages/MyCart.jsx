import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import './WomenProductsPublic.css';
import './MyCart.css';

const username = localStorage.getItem('username');

const MyCart = () => {
  const [cart, setCart] = useState([]);
  const [address, setAddress] = useState('');
  const [phone, setPhone] = useState('');
  const [notes, setNotes] = useState('');
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const storedCart = JSON.parse(localStorage.getItem('cart') || '[]');
    setCart(storedCart);
  }, []);

  const handleRemove = (id) => {
    const newCart = cart.filter(item => item.id !== id);
    setCart(newCart);
    localStorage.setItem('cart', JSON.stringify(newCart));
  };

  const handleQtyChange = (id, qty) => {
    const newCart = cart.map(item => item.id === id ? { ...item, quantity: Math.max(1, Number(qty)) } : item);
    setCart(newCart);
    localStorage.setItem('cart', JSON.stringify(newCart));
  };

  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const handleOrder = async (e) => {
    e.preventDefault();
    setSuccess('');
    setError('');
    const insufficient = cart.find(item => item.quantity > (item.stock_quantity || 0));
    if (insufficient) {
      setError('الكمية منتهية أو غير كافية في المخزون لهذا المنتج: ' + insufficient.name);
      return;
    }
    const token = localStorage.getItem('token');
    if (!token) {
      setError('يجب تسجيل الدخول أولاً لتأكيد الطلب.');
      return;
    }
    const orderData = {
      shipping_address: address,
      phone_number: phone,
      notes: notes,
      items: cart.map(item => ({ product_id: item.id, quantity: item.quantity }))
    };
    try {
      const res = await fetch('http://127.0.0.1:8000/api/v1/orders/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(orderData)
      });
      if (!res.ok) {
        let errorMsg = 'حدث خطأ أثناء إرسال الطلب.';
        try {
          const data = await res.json();
          console.log('Server error response:', data);
          let msg = data.detail || errorMsg;
          if (msg.includes('Insufficient stock')) {
            msg = 'الكمية منتهية أو غير كافية في المخزون لهذا المنتج: ' + msg.split('product ')[1];
          }
          errorMsg = msg;
        } catch (e) {
          const text = await res.text();
          console.log('Server error text:', text);
          errorMsg = text || errorMsg;
        }
        setError(errorMsg);
        return;
      }
      setSuccess('تم تأكيد الطلب! سيتم التواصل معك قريباً.');
      setCart([]);
      localStorage.removeItem('cart');
      setAddress('');
      setPhone('');
      setNotes('');
    } catch (err) {
      setError('حدث خطأ أثناء إرسال الطلب. حاول مرة أخرى.');
    }
  };

  return (
    <div className="cart-bg">
      <div className="cart-container">
        <button onClick={()=>navigate(-1)} className="cart-back-btn">رجوع</button>
        <h2 className="cart-title">سلة المشتريات</h2>
        {username && <div className="cart-welcome">مرحباً <bdi>{username}</bdi> 👋</div>}
        {cart.length === 0 ? (
          <div className="cart-center">سلتك فارغة حالياً.</div>
        ) : (
          <>
            <div className="cart-list">
              {cart.map(item => (
                <div className="cart-card" key={item.id}>
                  {item.image && <img src={item.image} alt={item.name} className="cart-img" />}
                  <div className="cart-info">
                    <div className="cart-prod-name">{item.name}</div>
                    <div className="cart-prod-price">{item.price} شيقل</div>
                    <div className="cart-qty-row">
                      <button type="button" className="cart-qty-btn" onClick={()=>handleQtyChange(item.id, item.quantity-1)} disabled={item.quantity<=1}>-</button>
                      <input type="number" min="1" value={item.quantity} onChange={e=>handleQtyChange(item.id, e.target.value)} className="cart-qty-input" />
                      <button type="button" className="cart-qty-btn" onClick={()=>handleQtyChange(item.id, item.quantity+1)}>+</button>
                    </div>
                    <div className="cart-prod-total">الإجمالي: <b>{item.price * item.quantity} شيقل</b></div>
                  </div>
                  <button onClick={()=>handleRemove(item.id)} className="cart-remove-btn">حذف</button>
                </div>
              ))}
            </div>
            <div className="cart-summary-card">
              <span>المجموع الكلي:</span>
              <span className="cart-summary-total">{total} شيقل</span>
            </div>
            <form onSubmit={handleOrder} className="cart-form">
              <div className="cart-input-row">
                <span className="cart-input-icon">🏠</span>
                <input type="text" placeholder="عنوان الشحن" value={address} onChange={e=>setAddress(e.target.value)} required className="cart-input" />
              </div>
              <div className="cart-input-row">
                <span className="cart-input-icon">📱</span>
                <input type="text" placeholder="رقم الهاتف" value={phone} onChange={e=>setPhone(e.target.value)} required className="cart-input" />
              </div>
              <div className="cart-input-row">
                <span className="cart-input-icon">📝</span>
                <textarea placeholder="ملاحظتك (اختياري)" value={notes} onChange={e=>setNotes(e.target.value)} className="cart-textarea" />
              </div>
              {error && <div className="cart-error">{error}</div>}
              <button type="submit" className="cart-submit-btn">تأكيد الطلب</button>
            </form>
            {success && <div className="cart-success">{success}</div>}
          </>
        )}
      </div>
    </div>
  );
};

export default MyCart; 