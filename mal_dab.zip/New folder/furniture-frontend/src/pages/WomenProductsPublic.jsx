import './WomenProductsPublic.css';
import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import PublicFilter from '../components/PublicFilter';

const username = localStorage.getItem('username') || 'زائر';

const WomenProductsPublic = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState('');
  const [minPrice, setMinPrice] = useState('');
  const [maxPrice, setMaxPrice] = useState('');
  const [discountOnly, setDiscountOnly] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth <= 768);
    };
    checkMobile();
    window.addEventListener('resize', checkMobile);
    setTimeout(() => setIsLoaded(true), 100);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  useEffect(() => {
    fetch('http://127.0.0.1:8000/api/v1/products/filter/category?category=نسائي')
      .then((res) => {
        if (!res.ok) throw new Error('Network response was not ok');
        return res.json();
      })
      .then((data) => {
        setProducts(data);
        setLoading(false);
      })
      .catch((err) => {
        setError(err.message);
        setLoading(false);
      });
  }, []);

  const filtered = products.filter(product => {
    const matchesName = product.name.toLowerCase().includes(search.toLowerCase());
    const matchesMin = minPrice === '' || product.price >= parseFloat(minPrice);
    const matchesMax = maxPrice === '' || product.price <= parseFloat(maxPrice);
    const matchesDiscount = !discountOnly || product.has_discount;
    return matchesName && matchesMin && matchesMax && matchesDiscount;
  });

  const containerStyle = {
    opacity: isLoaded ? 1 : 0,
    transform: isLoaded ? 'translateY(0)' : 'translateY(20px)',
    transition: 'opacity 1.8s ease-out, transform 1.8s ease-out',
    background: 'linear-gradient(135deg, #d7deea 0%, #c3cfe2 100%)',
    minHeight: '100vh'
  };

  return (
    <div style={containerStyle}>
      {/* Navbar */}
      <nav
        style={{
          background: 'linear-gradient(90deg, #232526 0%, #414345 100%)',
          boxShadow: '0 4px 24px 0 #00000018',
          padding: isMobile ? '0 4px' : '0 40px',
          display: 'flex',
          flexDirection: isMobile ? 'column' : 'row',
          alignItems: isMobile ? 'stretch' : 'center',
          justifyContent: 'space-between',
          height: isMobile ? 'auto' : '70px',
          position: 'sticky',
          top: 0,
          zIndex: 100,
          overflowX: isMobile ? 'hidden' : 'unset',
          whiteSpace: isMobile ? 'normal' : 'unset',
        }}
      >
        {/* شعار DAB STORE في الأعلى على الموبايل */}
        {isMobile && (
          <div style={{ textAlign: 'center', fontWeight: 'bold', fontSize: '1.2rem', color: '#fff', letterSpacing: '2px', margin: '8px 0 4px 0' }}>
            <span style={{ color: '#fff', background: '#232526', borderRadius: '6px', padding: '1px 8px', marginRight: 4 }}>DAB</span>
            <span style={{ color: '#fff' }}>STORE</span>
          </div>
        )}
        <div style={{ display: 'flex', alignItems: 'center', gap: isMobile ? 8 : 32, justifyContent: isMobile ? 'center' : 'flex-start', width: isMobile ? '100%' : 'auto' }}>
          {/* الشعار على اللابتوب فقط */}
          {!isMobile && (
            <div style={{ fontWeight: 'bold', fontSize: '2rem', color: '#fff', letterSpacing: '2px', margin: 0, minWidth: 90 }}>
              <span style={{ color: '#fff', background: '#232526', borderRadius: '6px', padding: '2px 8px', marginRight: 4 }}>DAB</span>
              <span style={{ color: '#fff' }}>STORE</span>
            </div>
          )}
          <Link
            to="/"
            style={{
              color: '#fff',
              textDecoration: 'none',
              fontWeight: 500,
              fontSize: isMobile ? '0.95rem' : '1.1rem',
              padding: isMobile ? '4px 8px' : '6px 16px',
              borderRadius: '6px',
              transition: 'all 0.3s ease',
              textAlign: 'center',
              minWidth: 60,
              position: 'relative',
              overflow: 'hidden'
            }}
            onMouseOver={e => {
              e.currentTarget.style.background = 'rgba(255,255,255,0.15)';
              e.currentTarget.style.transform = 'translateY(-2px)';
              e.currentTarget.style.boxShadow = '0 4px 12px rgba(0,0,0,0.2)';
            }}
            onMouseOut={e => {
              e.currentTarget.style.background = 'transparent';
              e.currentTarget.style.transform = 'translateY(0)';
              e.currentTarget.style.boxShadow = 'none';
            }}
          >
            الرئيسية
          </Link>
          <Link
            to="/products-public"
            style={{
              color: '#fff',
              textDecoration: 'none',
              fontWeight: 500,
              fontSize: isMobile ? '0.95rem' : '1.1rem',
              padding: isMobile ? '4px 8px' : '6px 16px',
              borderRadius: '6px',
              transition: 'all 0.3s ease',
              textAlign: 'center',
              minWidth: 90,
              position: 'relative',
              overflow: 'hidden'
            }}
            onMouseOver={e => {
              e.currentTarget.style.background = 'rgba(255,255,255,0.15)';
              e.currentTarget.style.transform = 'translateY(-2px)';
              e.currentTarget.style.boxShadow = '0 4px 12px rgba(0,0,0,0.2)';
            }}
            onMouseOut={e => {
              e.currentTarget.style.background = 'transparent';
              e.currentTarget.style.transform = 'translateY(0)';
              e.currentTarget.style.boxShadow = 'none';
            }}
          >
            جميع المنتجات
          </Link>
          <Link
            to="/cart"
            style={{
              color: '#fff',
              textDecoration: 'none',
              fontWeight: 500,
              fontSize: isMobile ? '0.95rem' : '1.1rem',
              padding: isMobile ? '4px 8px' : '6px 16px',
              borderRadius: '6px',
              transition: 'all 0.3s ease',
              textAlign: 'center',
              minWidth: 60,
              position: 'relative',
              overflow: 'hidden'
            }}
            onMouseOver={e => {
              e.currentTarget.style.background = 'rgba(255,255,255,0.15)';
              e.currentTarget.style.transform = 'translateY(-2px)';
              e.currentTarget.style.boxShadow = '0 4px 12px rgba(0,0,0,0.2)';
            }}
            onMouseOut={e => {
              e.currentTarget.style.background = 'transparent';
              e.currentTarget.style.transform = 'translateY(0)';
              e.currentTarget.style.boxShadow = 'none';
            }}
          >
            السلة
          </Link>
        </div>
        {/* اسم المستخدم يظهر فقط في منتصف النافبار أسفل العناصر على الموبايل */}
        {isMobile && (
          <div style={{ textAlign: 'center', color: '#fff', fontWeight: 500, fontSize: '0.95rem', margin: '4px 0 6px 0' }}>
            {username && `Welcome, ${username}`}
          </div>
        )}
        {/* اسم المستخدم على اللابتوب فقط */}
        {!isMobile && (
          <div style={{ color: '#fff', fontWeight: 500, fontSize: '1.1rem', marginRight: 24, minWidth: 80, textAlign: 'end' }}>
            {username && `Welcome, ${username}`}
          </div>
        )}
      </nav>
      {/* Filters */}
      <PublicFilter
        search={search} setSearch={setSearch}
        minPrice={minPrice} setMinPrice={setMinPrice}
        maxPrice={maxPrice} setMaxPrice={setMaxPrice}
        discountOnly={discountOnly} setDiscountOnly={setDiscountOnly}
        showCategory={false}
      />
      {/* Products */}
      <h2 className="wp-title">منتجات نسائية</h2>
      {loading ? (
        <div className="wp-center">جاري التحميل...</div>
      ) : error ? (
        <div className="wp-center wp-error">حدث خطأ: {error}</div>
      ) : filtered.length === 0 ? (
        <div className="wp-center">لا توجد منتجات مطابقة.</div>
      ) : (
        <div className="wp-grid">
          {filtered.map(product => (
            <div
              className="wp-card"
              key={product.id}
              style={{
                background: '#d7deea',
                borderRadius: '16px',
                boxShadow: '0 4px 16px rgba(55, 100, 150, 0.10)',
                padding: '16px',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                transition: 'all 0.4s ease',
                transform: 'translateY(0)',
                cursor: 'pointer',
                position: 'relative',
                overflow: 'hidden',
                width: '100%',
                maxWidth: '210px',
                minWidth: '140px',
                margin: '0 auto'
              }}
              onMouseOver={e => {
                e.currentTarget.style.transform = 'translateY(-6px)';
                e.currentTarget.style.boxShadow = '0 16px 48px rgba(55, 100, 150, 0.15)';
              }}
              onMouseOut={e => {
                e.currentTarget.style.transform = 'translateY(0)';
                e.currentTarget.style.boxShadow = '0 4px 16px rgba(55, 100, 150, 0.10)';
              }}
            >
              <div className="wp-img-wrap">
                <img
                  src={product.image_url?.startsWith('http') ? product.image_url : `http://127.0.0.1:8000/api/v1/images/products/${product.id}/${product.image_url}`}
                  alt={product.name}
                  className="wp-img"
                  onError={e => e.target.src = 'https://via.placeholder.com/220x160?text=No+Image'}
                  style={{
                    width: '100%',
                    height: '140px',
                    objectFit: 'cover',
                    borderRadius: '12px',
                    marginBottom: '12px',
                    background: '#d7deea'
                  }}
                />
              </div>
              <div className="wp-info">
                <h3 className="wp-name" style={{fontWeight:'bold', fontSize:'1.1rem', color:'#222', marginBottom:'8px', textAlign:'center'}}>{product.name}</h3>
                <div className="wp-price" style={{color:'#2563eb', fontWeight:'bold', fontSize:'1.1rem', marginBottom:'8px'}}>{product.price} شيقل</div>
                <div className="wp-desc">{product.description}</div>
                {product.has_discount && <span className="wp-discount">خصم {product.discount_percent}%</span>}
                <div style={{display:'flex', gap:8, marginTop:10, width:'100%'}}>
                  <button className="wp-navlink" style={{flex:1, textAlign:'center', background:'linear-gradient(135deg, #22c55e 0%, #16a34a 100%)', color:'#fff', border:'none', borderRadius:'8px', fontWeight:'bold', fontSize:'1rem', cursor:'pointer', transition:'all 0.3s'}} onMouseOver={e => {e.currentTarget.style.transform='translateY(-2px)';e.currentTarget.style.boxShadow='0 6px 20px rgba(34, 197, 94, 0.4)';}} onMouseOut={e => {e.currentTarget.style.transform='translateY(0)';e.currentTarget.style.boxShadow='none';}} onClick={() => {
                    let cart = JSON.parse(localStorage.getItem('cart') || '[]');
                    const existing = cart.find(item => item.id === product.id);
                    if (existing) {
                      existing.quantity += 1;
                    } else {
                      cart.push({...product, quantity: 1});
                    }
                    localStorage.setItem('cart', JSON.stringify(cart));
                    alert('تمت إضافة المنتج إلى السلة!');
                  }}>أضف للسلة</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default WomenProductsPublic; 