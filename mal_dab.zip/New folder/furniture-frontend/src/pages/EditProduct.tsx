import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { productsAPI } from "../services/api";
import { useAuth } from "../contexts/AuthContext";

const EditProduct = () => {
  const { productId } = useParams<{ productId: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const token = localStorage.getItem("token");
  
  const [form, setForm] = useState({
    name: "",
    description: "",
    price: "",
    category: "",
    stock_quantity: "",
    image: null as File | null,
  });
  const [currentImage, setCurrentImage] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    if (productId) {
      fetchProduct();
    }
  }, [productId]);

  const fetchProduct = async () => {
    try {
      setLoading(true);
      const response = await productsAPI.getById(parseInt(productId!));
      const product = response.data;
      
      setForm({
        name: product.name,
        description: product.description || "",
        price: product.price.toString(),
        category: product.category || "",
        stock_quantity: product.stock_quantity.toString(),
        image: null,
      });
      
      if (product.image_url) {
        setCurrentImage(product.image_url);
      }
    } catch (err: any) {
      setError("فشل في تحميل بيانات المنتج");
      console.error("Error fetching product:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setForm((prev) => ({ ...prev, image: e.target.files![0] }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setMessage("");
    setError("");
    
    try {
      const formData = new FormData();
      formData.append("name", form.name);
      formData.append("description", form.description);
      formData.append("price", form.price);
      formData.append("category", form.category);
      formData.append("stock_quantity", form.stock_quantity);
      if (form.image) {
        formData.append("image", form.image);
      }

      await productsAPI.update(parseInt(productId!), formData as any);
      setMessage("تم تحديث المنتج بنجاح!");
      
      setTimeout(() => {
        navigate("/admin/products");
      }, 1500);
    } catch (err: any) {
      setError("حدث خطأ أثناء تحديث المنتج.");
      console.error("Error updating product:", err);
    } finally {
      setLoading(false);
    }
  };

  if (loading && !form.name) {
    return (
      <div style={{ maxWidth: 500, margin: "40px auto", background: "#fff", padding: 24, borderRadius: 8, boxShadow: "0 2px 8px #eee", textAlign: "center" }}>
        جاري التحميل...
      </div>
    );
  }

  return (
    <div style={{ maxWidth: 500, margin: "40px auto", background: "#fff", padding: 24, borderRadius: 8, boxShadow: "0 2px 8px #eee" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
        <h2>تعديل المنتج</h2>
        <button 
          onClick={() => navigate("/admin/products")}
          style={{ 
            background: "#666", 
            color: "#fff", 
            border: "none", 
            padding: "8px 16px", 
            borderRadius: 4,
            cursor: "pointer"
          }}
        >
          رجوع
        </button>
      </div>
      
      <form onSubmit={handleSubmit}>
        <div style={{ marginBottom: 12 }}>
          <label>اسم المنتج</label>
          <input 
            type="text" 
            name="name" 
            value={form.name} 
            onChange={handleChange} 
            required 
            style={{ width: "100%", padding: 8, marginTop: 4 }} 
          />
        </div>
        
        <div style={{ marginBottom: 12 }}>
          <label>الوصف</label>
          <textarea 
            name="description" 
            value={form.description} 
            onChange={handleChange} 
            style={{ width: "100%", padding: 8, marginTop: 4, minHeight: "80px" }} 
          />
        </div>
        
        <div style={{ marginBottom: 12 }}>
          <label>السعر</label>
          <input 
            type="number" 
            name="price" 
            value={form.price} 
            onChange={handleChange} 
            required 
            step="0.01"
            style={{ width: "100%", padding: 8, marginTop: 4 }} 
          />
        </div>
        
        <div style={{ marginBottom: 12 }}>
          <label>الفئة</label>
          <input 
            type="text" 
            name="category" 
            value={form.category} 
            onChange={handleChange} 
            style={{ width: "100%", padding: 8, marginTop: 4 }} 
          />
        </div>
        
        <div style={{ marginBottom: 12 }}>
          <label>كمية المخزون</label>
          <input 
            type="number" 
            name="stock_quantity" 
            value={form.stock_quantity} 
            onChange={handleChange} 
            required 
            style={{ width: "100%", padding: 8, marginTop: 4 }} 
          />
        </div>
        
        <div style={{ marginBottom: 12 }}>
          <label>الصورة الحالية</label>
          {currentImage ? (
            <div style={{ marginTop: 8 }}>
              <img 
                src={`http://127.0.0.1:8000${currentImage}`} 
                alt="Current product" 
                style={{ 
                  width: "100px", 
                  height: "100px", 
                  objectFit: "cover", 
                  borderRadius: "4px",
                  border: "1px solid #ddd"
                }} 
              />
            </div>
          ) : (
            <div style={{ marginTop: 8, color: "#666" }}>لا توجد صورة</div>
          )}
        </div>
        
        <div style={{ marginBottom: 12 }}>
          <label>صورة جديدة (اختياري)</label>
          <input 
            type="file" 
            name="image" 
            accept="image/*" 
            onChange={handleFileChange} 
            style={{ width: "100%", marginTop: 4 }} 
          />
        </div>
        
        <div style={{ display: "flex", gap: "10px" }}>
          <button 
            type="submit" 
            disabled={loading} 
            style={{ 
              padding: "10px 24px", 
              background: "#2d6cdf", 
              color: "#fff", 
              border: "none", 
              borderRadius: 4,
              cursor: loading ? "not-allowed" : "pointer",
              opacity: loading ? 0.7 : 1
            }}
          >
            {loading ? "جاري التحديث..." : "تحديث المنتج"}
          </button>
          
          <button 
            type="button"
            onClick={() => navigate("/admin/products")}
            style={{ 
              padding: "10px 24px", 
              background: "#666", 
              color: "#fff", 
              border: "none", 
              borderRadius: 4,
              cursor: "pointer"
            }}
          >
            إلغاء
          </button>
        </div>
      </form>
      
      {message && <div style={{ color: "green", marginTop: 16 }}>{message}</div>}
      {error && <div style={{ color: "red", marginTop: 16 }}>{error}</div>}
    </div>
  );
};

export default EditProduct; 