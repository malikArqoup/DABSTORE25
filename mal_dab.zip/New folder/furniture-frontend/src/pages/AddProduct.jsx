import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import ProductForm from "../components/ProductForm";
import { addProduct } from "../services/api";

const AddProduct = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  // Handles form submission
  const handleAddProduct = async (formData) => {
    setLoading(true);
    setMessage("");
    setError("");
    try {
      const token = localStorage.getItem("token");
      await addProduct(formData, token);
      setMessage("تمت إضافة المنتج بنجاح!");
      setTimeout(() => navigate("/admin/products"), 1500);
    } catch (err) {
      setError("حدث خطأ أثناء إضافة المنتج.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <h2 style={{ textAlign: "center", margin: "32px 0 12px 0" }}>إضافة منتج جديد</h2>
      <ProductForm
        initialValues={{}}
        onSubmit={handleAddProduct}
        submitLabel="إضافة المنتج"
        loading={loading}
      />
      {message && <div style={{ color: "#1a7f37", textAlign: "center", marginTop: 16 }}>{message}</div>}
      {error && <div style={{ color: "#b00020", textAlign: "center", marginTop: 16 }}>{error}</div>}
    </div>
  );
};

export default AddProduct; 