import React, { useEffect, useState } from 'react';
import { ordersAPI, OrderSummary } from '../services/api';
import { useNavigate } from 'react-router-dom';

const MyOrders = () => {
  const [orders, setOrders] = useState<OrderSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const response = await ordersAPI.getMyOrders();
        setOrders(response.data);
      } catch (err) {
        setError('فشل في تحميل الطلبات');
      } finally {
        setLoading(false);
      }
    };
    fetchOrders();
  }, []);

  return (
    <div style={{maxWidth:900, margin:'40px auto', background:'#fff', borderRadius:12, boxShadow:'0 2px 12px #eee', padding:32}}>
      <div style={{display:'flex', alignItems:'center', marginBottom:24}}>
        <button onClick={()=>navigate(-1)} style={{background:'#eee', color:'#2563eb', border:'none', borderRadius:6, padding:'8px 18px', fontWeight:600, cursor:'pointer', marginRight:12}}>رجوع</button>
        <h2 style={{fontSize:'2rem', fontWeight:'bold', color:'#2563eb', margin:0}}>طلباتي</h2>
      </div>
      {loading ? (
        <div style={{textAlign:'center', color:'#888', fontSize:'1.1rem'}}>جاري التحميل...</div>
      ) : error ? (
        <div style={{textAlign:'center', color:'red', fontSize:'1.1rem'}}>{error}</div>
      ) : orders.length === 0 ? (
        <div style={{textAlign:'center', color:'#888', fontSize:'1.1rem'}}>لا يوجد طلبات بعد</div>
      ) : (
        <table style={{width:'100%', borderCollapse:'collapse', boxShadow:'0 1px 8px #f0f0f0', fontSize:15}}>
          <thead>
            <tr style={{background:'#f5f7fa'}}>
              <th style={{padding:8}}>رقم الطلب</th>
              <th style={{padding:8}}>التاريخ</th>
              <th style={{padding:8}}>المجموع</th>
              <th style={{padding:8}}>الحالة</th>
              <th style={{padding:8}}>عدد المنتجات</th>
            </tr>
          </thead>
          <tbody>
            {orders.map(order => (
              <tr key={order.id} style={{borderBottom:'1px solid #eee'}}>
                <td style={{padding:8, fontWeight:600}}>{order.order_number}</td>
                <td style={{padding:8}}>{new Date(order.created_at).toLocaleString('ar-EG')}</td>
                <td style={{padding:8}}>{order.total_amount} شيقل</td>
                <td style={{padding:8}}>{order.status}</td>
                <td style={{padding:8}}>{order.items_count}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default MyOrders; 