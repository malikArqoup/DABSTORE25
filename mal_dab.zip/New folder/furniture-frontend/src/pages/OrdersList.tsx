import React, { useEffect, useState } from 'react';
import { ordersAPI } from '../services/api';
import type { OrderSummary } from '../services/api';
import { useNavigate } from 'react-router-dom';

const OrdersList: React.FC = () => {
  const [orders, setOrders] = useState<OrderSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const response = await ordersAPI.getAll();
        setOrders(response.data);
      } catch (err) {
        setError('فشل في جلب الطلبات');
      } finally {
        setLoading(false);
      }
    };
    fetchOrders();
  }, []);

  const handleAccept = async (orderId: number) => {
    try {
      await ordersAPI.updateStatus(orderId, 'confirmed');
      setOrders(orders => orders.map(order => order.id === orderId ? { ...order, status: 'confirmed' } : order));
      window.dispatchEvent(new Event('orders-updated'));
    } catch (err) {
      alert('فشل في تأكيد الطلب');
    }
  };

  const handleCancel = async (orderId: number) => {
    if (!window.confirm('هل أنت متأكد من إلغاء الطلب؟')) return;
    try {
      await ordersAPI.updateStatus(orderId, 'cancelled');
      setOrders(orders => orders.map(order => order.id === orderId ? { ...order, status: 'cancelled' } : order));
      window.dispatchEvent(new Event('orders-updated'));
    } catch (err) {
      alert('فشل في إلغاء الطلب');
    }
  };

  const handleDelete = async (orderId: number) => {
    if (!window.confirm('هل أنت متأكد من حذف الطلب نهائياً؟')) return;
    try {
      await ordersAPI.delete(orderId);
      setOrders(orders => orders.filter(order => order.id !== orderId));
      window.dispatchEvent(new Event('orders-updated'));
    } catch (err) {
      alert('فشل في حذف الطلب');
    }
  };

  if (loading) return <div>جاري التحميل...</div>;
  if (error) return <div style={{color:'red'}}>{error}</div>;

  return (
    <div style={{padding:'30px'}}>
      <button onClick={()=>navigate(-1)} style={{background:'#eee',color:'#2563eb',border:'none',borderRadius:8,padding:'8px 22px',fontWeight:700,fontSize:'1.05rem',marginBottom:18,cursor:'pointer',marginRight:12}}>رجوع</button>
      <button
        onClick={async () => {
          if (!window.confirm('هل أنت متأكد من حذف جميع الطلبات نهائياً؟')) return;
          try {
            await ordersAPI.deleteAll();
            setOrders([]);
            window.dispatchEvent(new Event('orders-updated'));
          } catch (err) {
            alert('فشل في حذف جميع الطلبات');
          }
        }}
        style={{background:'#e11d48',color:'#fff',border:'none',borderRadius:8,padding:'10px 28px',fontWeight:700,fontSize:'1.1rem',marginBottom:18,cursor:'pointer',float:'left'}}
      >
        حذف الكل بشكل نهائي
      </button>
      <h2 style={{textAlign:'center', marginBottom:'24px', fontWeight:'bold', fontSize:'2rem', letterSpacing:'1px'}}>جميع الطلبات</h2>
      <div style={{overflowX:'auto', borderRadius:'12px', boxShadow:'0 2px 8px #eee', background:'#fff'}}>
        <table style={{width:'100%',borderCollapse:'separate', borderSpacing:0, minWidth:'1100px'}}>
          <thead style={{position:'sticky', top:0, zIndex:2, background:'#f0f4f8'}}>
            <tr>
              <th style={{padding:'12px',borderBottom:'2px solid #e0e0e0'}}>رقم الطلب</th>
              <th style={{padding:'12px',borderBottom:'2px solid #e0e0e0'}}>اسم المستخدم</th>
              <th style={{padding:'12px',borderBottom:'2px solid #e0e0e0'}}>البريد الإلكتروني</th>
              <th style={{padding:'12px',borderBottom:'2px solid #e0e0e0'}}>رقم الهاتف</th>
              <th style={{padding:'12px',borderBottom:'2px solid #e0e0e0'}}>العنوان</th>
              <th style={{padding:'12px',borderBottom:'2px solid #e0e0e0'}}>الحالة</th>
              <th style={{padding:'12px',borderBottom:'2px solid #e0e0e0'}}>المجموع</th>
              <th style={{padding:'12px',borderBottom:'2px solid #e0e0e0'}}>عدد المنتجات</th>
              <th style={{padding:'12px',borderBottom:'2px solid #e0e0e0'}}>تاريخ الإنشاء</th>
              <th style={{padding:'12px',borderBottom:'2px solid #e0e0e0'}}>إجراءات</th>
            </tr>
          </thead>
          <tbody>
            {orders.map((order, idx) => (
              <tr key={order.id} style={{background: idx%2===0 ? '#fafbfc' : '#f5f7fa', transition:'background 0.2s'}}>
                <td style={{padding:'10px 8px',borderBottom:'1px solid #f0f0f0', textAlign:'center'}}>{order.order_number}</td>
                <td style={{padding:'10px 8px',borderBottom:'1px solid #f0f0f0', textAlign:'center'}}>{order.username}</td>
                <td style={{padding:'10px 8px',borderBottom:'1px solid #f0f0f0', textAlign:'center'}}>{order.email}</td>
                <td style={{padding:'10px 8px',borderBottom:'1px solid #f0f0f0', textAlign:'center'}}>{order.phone_number}</td>
                <td style={{padding:'10px 8px',borderBottom:'1px solid #f0f0f0', textAlign:'center'}}>{order.shipping_address}</td>
                <td style={{padding:'10px 8px',borderBottom:'1px solid #f0f0f0', textAlign:'center'}}>
                  {order.status === 'pending' && <span title="قيد الانتظار">⏳</span>}
                  {order.status === 'confirmed' && <span title="مؤكد">✅</span>}
                  {order.status === 'shipped' && <span title="تم الشحن">🚚</span>}
                  {order.status === 'delivered' && <span title="تم التوصيل">📦</span>}
                  {order.status === 'cancelled' && <span title="ملغي">❌</span>}
                  <span style={{marginRight:'6px'}}>{order.status}</span>
                </td>
                <td style={{padding:'10px 8px',borderBottom:'1px solid #f0f0f0', textAlign:'center'}}>{order.total_amount}</td>
                <td style={{padding:'10px 8px',borderBottom:'1px solid #f0f0f0', textAlign:'center'}}>{order.items_count}</td>
                <td style={{padding:'10px 8px',borderBottom:'1px solid #f0f0f0', textAlign:'center'}}>{new Date(order.created_at).toLocaleString()}</td>
                <td style={{padding:'10px 8px',borderBottom:'1px solid #f0f0f0', textAlign:'center'}}>
                  {order.status === 'pending' && (
                    <button onClick={() => handleAccept(order.id)} style={{background:'#22c55e',color:'#fff',border:'none',borderRadius:6,padding:'6px 14px',fontWeight:600,marginRight:8,cursor:'pointer'}}>قبول</button>
                  )}
                  {order.status !== 'cancelled' && (
                    <button onClick={() => handleCancel(order.id)} style={{background:'#facc15',color:'#222',border:'none',borderRadius:6,padding:'6px 14px',fontWeight:600,marginRight:8,cursor:'pointer'}}>إلغاء</button>
                  )}
                  <button onClick={() => handleDelete(order.id)} style={{background:'#e11d48',color:'#fff',border:'none',borderRadius:6,padding:'6px 14px',fontWeight:600,cursor:'pointer'}}>حذف نهائي</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default OrdersList; 