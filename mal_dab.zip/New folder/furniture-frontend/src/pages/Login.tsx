import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import './login.css';

const Login: React.FC = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const { login, register } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      if (isLogin) {
        try {
          await login(username, password, false);
          localStorage.setItem('username', username);
          navigate('/');
          return;
        } catch (userErr) {
          try {
            await login(username, password, true);
            navigate('/admin/dashboard');
            return;
          } catch (adminErr) {
            setError('فشل في تسجيل الدخول. تحقق من البيانات وحاول مجددًا.');
          }
        }
      } else {
        await register(username, email, password);
        navigate('/');
      }
    } catch (err: any) {
      setError('فشل في العملية. تحقق من البيانات وحاول مجددًا.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-bg">
      <div className="login-card">
        <div className="login-header">
          <div className="login-title-tabs">
            <button onClick={()=>setIsLogin(true)} className={isLogin ? 'login-tab active' : 'login-tab'}>تسجيل الدخول</button>
            <button onClick={()=>setIsLogin(false)} className={!isLogin ? 'login-tab active' : 'login-tab'}>إنشاء حساب</button>
          </div>
          <div className="login-welcome">مرحباً بك في <bdi>DAB STORE</bdi> 👋</div>
        </div>
        <form onSubmit={handleSubmit} className="login-form">
          {isLogin ? (
            <>
              <div className="login-input-wrap">
                <span className="login-icon">👤</span>
                <input
                  type="text"
                  placeholder="اسم المستخدم"
                  value={username}
                  onChange={e=>setUsername(e.target.value)}
                  required
                  className="login-input"
                />
              </div>
              <div className="login-hint">يرجى إدخال اسم المستخدم وليس الإيميل</div>
              <div className="login-input-wrap">
                <span className="login-icon">🔒</span>
                <input
                  type="password"
                  placeholder="كلمة المرور"
                  value={password}
                  onChange={e=>setPassword(e.target.value)}
                  required
                  className="login-input"
                />
              </div>
            </>
          ) : (
            <>
              <div className="login-input-wrap">
                <span className="login-icon">👤</span>
                <input
                  type="text"
                  placeholder="اسم المستخدم"
                  value={username}
                  onChange={e=>setUsername(e.target.value)}
                  required
                  className="login-input"
                />
              </div>
              <div className="login-input-wrap">
                <span className="login-icon">✉️</span>
                <input
                  type="email"
                  placeholder="الإيميل"
                  value={email}
                  onChange={e=>setEmail(e.target.value)}
                  required
                  className="login-input"
                />
              </div>
              <div className="login-input-wrap">
                <span className="login-icon">🔒</span>
                <input
                  type="password"
                  placeholder="كلمة المرور"
                  value={password}
                  onChange={e=>setPassword(e.target.value)}
                  required
                  className="login-input"
                />
              </div>
            </>
          )}
          {error && <div className="login-error">{error}</div>}
          <button type="submit" disabled={loading} className="login-btn">
            {loading ? '...جاري المعالجة' : isLogin ? 'تسجيل الدخول' : 'إنشاء حساب'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default Login; 