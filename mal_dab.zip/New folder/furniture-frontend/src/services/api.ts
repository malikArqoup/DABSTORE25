import axios from 'axios';

const API_BASE_URL = 'http://127.0.0.1:8000';

// Create axios instance
const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add auth token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor to handle errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      if (window.location.pathname !== '/login') {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        window.location.href = '/login';
      }
    }
    return Promise.reject(error);
  }
);

// Types
export interface LoginCredentials {
  username: string;
  password: string;
}

export interface User {
  id: number;
  username: string;
  email: string;
  is_active: boolean;
  created_at: string;
}

export interface Admin {
  id: number;
  username: string;
  email: string;
  is_active: boolean;
  created_at: string;
}

export interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  category: string;
  image_url: string;
  stock_quantity: number;
  discount_percent: number;
  discounted_price: number;
  has_discount: boolean;
  created_at: string;
  updated_at: string;
}

export interface Order {
  id: number;
  order_number: string;
  user_id: number;
  status: string;
  total_amount: number;
  created_at: string;
  updated_at: string;
  items: OrderItem[];
}

export interface OrderItem {
  id: number;
  order_id: number;
  product_id: number;
  quantity: number;
  unit_price: number;
  total_price: number;
  product: Product;
}

export interface OrderSummary {
  id: number;
  order_number: string;
  status: string;
  total_amount: number;
  created_at: string;
  items_count: number;
  username: string;
  email: string;
  phone_number: string;
  shipping_address: string;
}

// Auth API
export const authAPI = {
  adminLogin: (credentials: LoginCredentials) =>
    api.post<{ access_token: string; token_type: string }>('/api/v1/admin/login', credentials),
  
  userLogin: (credentials: LoginCredentials) =>
    api.post<{ access_token: string; token_type: string; user_id: number; username: string }>('/api/v1/user/login', credentials),
  
  userRegister: (userData: { username: string; email: string; password: string }) =>
    api.post<User>('/api/v1/user/register', userData),
  
  getAdminMe: () => api.get<Admin>('/api/v1/admin/me'),
  
  getUserMe: () => api.get<User>('/api/v1/user/me'),
  
  registerAdmin: (adminData: { username: string; email: string; password: string }) =>
    api.post<Admin>('/api/v1/admin/register', adminData),
  
  getAllAdmins: () => api.get<Admin[]>('/api/v1/admin/'),
  
  updateAdmin: (adminId: number, data: Partial<Admin>) =>
    api.put<Admin>(`/api/v1/admin/${adminId}`, data),
  
  deleteAdmin: (adminId: number) =>
    api.delete(`/api/v1/admin/${adminId}`),
  
  updateUser: (userId: number, data: Partial<User>) =>
    api.put<User>(`/api/v1/user/${userId}`, data),
};

// Products API
export const productsAPI = {
  getAll: (skip = 0, limit = 100) =>
    api.get<Product[]>(`/api/v1/products/?skip=${skip}&limit=${limit}`),
  
  getById: (id: number) => api.get<Product>(`/api/v1/products/${id}`),
  
  create: (product: Omit<Product, 'id' | 'created_at' | 'updated_at'>) =>
    api.post<Product>('/api/v1/products/', product),
  
  update: (id: number, productData: FormData | Partial<Product>) => {
    if (productData instanceof FormData) {
      return axios.put<Product>(
        `${API_BASE_URL}/api/v1/products/${id}`,
        productData,
        {
          headers: {
            'Content-Type': 'multipart/form-data',
            Authorization: `Bearer ${localStorage.getItem('token')}`,
          },
        }
      );
    } else {
      return api.put<Product>(`/api/v1/products/${id}`, productData);
    }
  },
  
  delete: (id: number) => api.delete(`/api/v1/products/${id}`),
  
  searchByName: (name: string) =>
    api.get<Product[]>(`/api/v1/products/search/name?name=${encodeURIComponent(name)}`),
  
  filterByCategory: (category: string) =>
    api.get<Product[]>(`/api/v1/products/filter/category?category=${encodeURIComponent(category)}`),
  
  filterByPriceRange: (minPrice: number, maxPrice: number) =>
    api.get<Product[]>(`/api/v1/products/filter/price?min_price=${minPrice}&max_price=${maxPrice}`),
  
  getWithDiscounts: (skip = 0, limit = 100) =>
    api.get<Product[]>(`/api/v1/products/discounts/all?skip=${skip}&limit=${limit}`),
  
  setDiscount: (id: number, discountPercent: number) =>
    api.put<Product>(`/api/v1/products/${id}/discount?discount_percent=${discountPercent}`),
  
  removeDiscount: (id: number) =>
    api.delete<Product>(`/api/v1/products/${id}/discount`),
  
  getByDiscountRange: (minDiscount: number, maxDiscount: number) =>
    api.get<Product[]>(`/api/v1/products/discounts/range?min_discount=${minDiscount}&max_discount=${maxDiscount}`),
};

// Orders API
export const ordersAPI = {
  create: (order: any) => api.post<Order>('/api/v1/orders/', order),
  
  getMyOrders: (skip = 0, limit = 100) =>
    api.get<OrderSummary[]>(`/api/v1/orders/my-orders?skip=${skip}&limit=${limit}`),
  
  getMyOrder: (id: number) => api.get<Order>(`/api/v1/orders/my-orders/${id}`),
  
  getMyOrderByNumber: (orderNumber: string) =>
    api.get<Order>(`/api/v1/orders/my-orders/number/${orderNumber}`),
  
  cancelMyOrder: (id: number) => api.post<Order>(`/api/v1/orders/my-orders/${id}/cancel`),
  
  // Admin endpoints
  getAll: (skip = 0, limit = 100) =>
    api.get<OrderSummary[]>(`/api/v1/orders/?skip=${skip}&limit=${limit}`),
  
  getById: (id: number) => api.get<Order>(`/api/v1/orders/${id}`),
  
  getByNumber: (orderNumber: string) =>
    api.get<Order>(`/api/v1/orders/number/${orderNumber}`),
  
  updateStatus: (id: number, status: string) =>
    api.put(`/api/v1/orders/${id}/status?status=${status}`),
  
  update: (id: number, orderData: any) =>
    api.put<Order>(`/api/v1/orders/${id}`, orderData),
  
  getByStatus: (status: string, skip = 0, limit = 100) =>
    api.get<OrderSummary[]>(`/api/v1/orders/status/${status}?skip=${skip}&limit=${limit}`),
  
  getStatistics: () => api.get('/api/v1/orders/statistics/dashboard'),
  
  delete: (id: number) => api.delete(`/api/v1/orders/${id}`),
  
  deleteAll: () => api.delete('/api/v1/orders/all'),
};

// Images API
export const imagesAPI = {
  upload: (productId: number, file: File, isPrimary = false) => {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('is_primary', isPrimary.toString());
    
    return api.post('/api/v1/images/upload/' + productId, formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
  },
  
  getProductImages: (productId: number) =>
    api.get(`/api/v1/images/product/${productId}`),
  
  getPrimaryImage: (productId: number) =>
    api.get(`/api/v1/images/product/${productId}/primary`),
  
  setPrimaryImage: (imageId: number) =>
    api.put(`/api/v1/images/${imageId}/primary`),
  
  deleteImage: (imageId: number) =>
    api.delete(`/api/v1/images/${imageId}`),
};

// Add Product with FormData (for image upload)
export const addProduct = async (formData: FormData, token?: string) => {
  return axios.post(
    `${API_BASE_URL}/api/v1/products/`,
    formData,
    {
      headers: {
        'Content-Type': 'multipart/form-data',
        Authorization: `Bearer ${token || localStorage.getItem('token')}`,
      },
    }
  );
};

// Slider Images API
export const sliderAPI = {
  getAll: () => api.get<{ id: number, image_url: string, order: number }[]>("/api/v1/slider-images/"),
  upload: (file: File) => {
    const formData = new FormData();
    formData.append("file", file);
    return api.post("/api/v1/slider-images/", formData, {
      headers: { "Content-Type": "multipart/form-data" },
    });
  },
  delete: (id: number) => api.delete(`/api/v1/slider-images/${id}`),
};

export default api; 